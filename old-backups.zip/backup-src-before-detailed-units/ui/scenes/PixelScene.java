package ui.scenes;

import audio.Sfx;
import java.awt.Cursor;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.List;
import javax.swing.AbstractAction;
import javax.swing.JComponent;
import javax.swing.JPanel;
import javax.swing.KeyStroke;
import javax.swing.Timer;
import ui.GameWindow;
import ui.pixel.Palette;
import ui.pixel.PixelArt;
import ui.pixel.PixelButton;
import ui.pixel.PixelFont;
import ui.pixel.PixelWidget;

/**
 * Parent class of every screen (Main Menu, Tower Select, Options, Credits...).
 *
 * How it works:
 *  1. Each frame, the screen is drawn on a tiny 320 x 180 image (the "canvas").
 *  2. The canvas is scaled up by a whole number (x3, x4...) without smoothing,
 *     so every game pixel becomes a crisp square block.
 *  3. A Swing Timer repaints about 30 times per second for animations.
 *  4. Mouse and keyboard input are converted to canvas coordinates and sent to the widgets.
 *
 * Abstraction: subclasses only have to say WHAT to draw (paintScene) and which buttons exist.
 */
public abstract class PixelScene extends JPanel {

    protected static final int W = PixelArt.WIDTH;
    protected static final int H = PixelArt.HEIGHT;
    private static final int TOAST_FRAMES = 60; // about 2 seconds

    protected final GameWindow window;
    protected int tick; // animation frame counter

    private final BufferedImage canvas = new BufferedImage(W, H, BufferedImage.TYPE_INT_RGB);
    private final List<PixelWidget> widgets = new ArrayList<>();
    private final List<PixelWidget> dialogWidgets = new ArrayList<>();
    private final Timer timer;
    private PixelWidget focused;
    private PixelWidget pressed;
    private PixelWidget hovered;     // widget under the mouse right now (null = none)
    private boolean keyboardMode;    // true after arrow keys, false after the mouse moves

    private String toastText;
    private int toastUntil;

    /** One button in a pop-up dialog. */
    public record DialogButton(String label, Runnable action) {
    }

    private boolean dialogOpen;
    private boolean dialogClosable;
    private String dialogTitle;
    private String[] dialogLines;
    private int dialogX;
    private int dialogY;
    private int dialogW;
    private int dialogH;

    protected PixelScene(GameWindow window) {
        this.window = window;
        setBackground(Palette.LETTERBOX);
        timer = new Timer(33, e -> {
            tick++;
            update();
            repaint();
        });
        installMouse();
        installKeys();
    }

    // ------------------------------------------------------------------
    //  What subclasses fill in
    // ------------------------------------------------------------------

    /** Draw the background and anything that is not a widget. */
    protected abstract void paintScene(Graphics2D g);

    /** Called every frame before drawing (for animations). */
    protected void update() {
    }

    /** What the Esc key does. Default: go back to the main menu. */
    protected void onEscape() {
        window.showMainMenu();
    }

    protected <T extends PixelWidget> T addWidget(T widget) {
        widgets.add(widget);
        return widget;
    }

    /** Milliseconds between frames (33 = about 30 FPS, 16 = about 60 FPS). */
    protected void setFrameDelay(int milliseconds) {
        timer.setDelay(milliseconds);
    }

    protected boolean isDialogOpen() {
        return dialogOpen;
    }

    /** The widget the player is pointing at (mouse hover, or arrow-key selection). Used for tooltips. */
    protected PixelWidget getTooltipTarget() {
        if (dialogOpen) {
            return null;
        }
        return keyboardMode ? focused : hovered;
    }

    /**
     * Called before any click / Enter / Space is handled.
     * Return true to "eat" the input (e.g. to skip an intro screen). Default: false.
     */
    protected boolean interceptInput() {
        return false;
    }

    /** Called when the player switches to another window (alt-tab) or minimizes the game. */
    public void onWindowFocusLost() {
    }

    /** Called by GameWindow when this screen appears. */
    public void onShow() {
        focused = firstSelectable(widgets);
        timer.start();
        requestFocusInWindow();
    }

    /** Called by GameWindow when this screen is hidden. */
    public void onHide() {
        timer.stop();
        dialogOpen = false;
        dialogWidgets.clear();
        toastText = null;
        pressed = null;
        hovered = null;
    }

    // ------------------------------------------------------------------
    //  Messages and dialogs (drawn in pixel style instead of JOptionPane)
    // ------------------------------------------------------------------

    /** A short message at the bottom of the screen for about 2 seconds. */
    protected void showToast(String text) {
        toastText = text;
        toastUntil = tick + TOAST_FRAMES;
    }

    /**
     * A wooden pop-up with a title, some lines of text, and one or two buttons.
     * @param cancelText null = only the OK button
     */
    protected void showDialog(String title, String[] lines, String okText, Runnable onOk, String cancelText) {
        if (cancelText == null) {
            showDialog(title, lines, 0, true, new DialogButton(okText, onOk));
        } else {
            // focus the cancel button: pressing Enter by accident does nothing harmful
            showDialog(title, lines, 1, true, new DialogButton(okText, onOk), new DialogButton(cancelText, null));
        }
    }

    /**
     * A wooden pop-up with any number of buttons. Every button closes the dialog, then runs its action.
     * @param focusIndex which button is selected first
     * @param closable   true = the Esc key closes it
     */
    protected void showDialog(String title, String[] lines, int focusIndex, boolean closable, DialogButton... buttons) {
        dialogTitle = title;
        dialogLines = lines;
        dialogClosable = closable;

        int buttonW = 56;
        int gap = 6;
        int buttonsWidth = buttons.length * buttonW + (buttons.length - 1) * gap;
        int widest = Math.max(PixelFont.width(title, 2), buttonsWidth);
        for (String line : lines) {
            widest = Math.max(widest, PixelFont.width(line, 1));
        }
        dialogW = Math.max(180, widest + 28);
        dialogH = 28 + lines.length * 10 + 24;
        dialogX = (W - dialogW) / 2;
        dialogY = (H - dialogH) / 2;

        dialogWidgets.clear();
        int buttonY = dialogY + dialogH - 20;
        int bx = (W - buttonsWidth) / 2;
        for (DialogButton b : buttons) {
            dialogWidgets.add(new PixelButton(b.label(), bx, buttonY, buttonW, 14, () -> {
                closeDialog();
                if (b.action() != null) {
                    b.action().run();
                }
            }));
            bx += buttonW + gap;
        }
        focused = dialogWidgets.get(Math.max(0, Math.min(focusIndex, dialogWidgets.size() - 1)));
        dialogOpen = true;
    }

    protected void closeDialog() {
        dialogOpen = false;
        dialogWidgets.clear();
        focused = firstSelectable(widgets);
    }

    // ------------------------------------------------------------------
    //  Drawing
    // ------------------------------------------------------------------

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g); // fills the black bars around the game screen

        Graphics2D c = canvas.createGraphics();
        paintScene(c);
        for (PixelWidget w : widgets) {
            if (w.isVisible()) {
                w.draw(c, !dialogOpen && w == focused, w == pressed, tick);
            }
        }
        if (dialogOpen) {
            paintDialog(c);
        }
        if (toastText != null && tick < toastUntil) {
            paintToast(c);
        }
        c.dispose();

        double s = scale();
        Graphics2D g2 = (Graphics2D) g;
        g2.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_NEAREST_NEIGHBOR);
        g2.drawImage(canvas, offsetX(), offsetY(), (int) Math.round(W * s), (int) Math.round(H * s), null);
    }

    private void paintDialog(Graphics2D g) {
        g.setColor(Palette.DIM);
        g.fillRect(0, 0, W, H);
        PixelArt.board(g, dialogX, dialogY, dialogW, dialogH);
        PixelFont.drawCentered(g, dialogTitle, W / 2, dialogY + 7, 2, Palette.TEXT_GOLD, Palette.TEXT_DARK);
        for (int i = 0; i < dialogLines.length; i++) {
            PixelFont.drawCentered(g, dialogLines[i], W / 2, dialogY + 27 + i * 10, 1, Palette.TEXT_DARK, null);
        }
        for (PixelWidget w : dialogWidgets) {
            w.draw(g, w == focused, w == pressed, tick);
        }
    }

    private void paintToast(Graphics2D g) {
        int tw = PixelFont.width(toastText, 1) + 18;
        int tx = (W - tw) / 2;
        int ty = H - 26;
        PixelArt.board(g, tx, ty, tw, 15);
        PixelFont.drawOutlined(g, toastText, tx + 9, ty + 4, 1, Palette.TEXT_GOLD, Palette.TEXT_DARK);
    }

    /**
     * How big each game pixel is on screen.
     * Pixel Perfect ON: whole numbers only (x2, x3...) - sharpest, may leave black borders.
     * Pixel Perfect OFF: fills as much of the window as possible (keeps the 16:9 shape).
     */
    private double scale() {
        double fit = Math.min((double) getWidth() / W, (double) getHeight() / H);
        if (window.getSettings().isPixelPerfect()) {
            return Math.max(1, Math.floor(fit));
        }
        return Math.max(0.5, fit);
    }

    private int offsetX() {
        return (int) ((getWidth() - W * scale()) / 2);
    }

    private int offsetY() {
        return (int) ((getHeight() - H * scale()) / 2);
    }

    // ------------------------------------------------------------------
    //  Input
    // ------------------------------------------------------------------

    private List<PixelWidget> activeWidgets() {
        return dialogOpen ? dialogWidgets : widgets;
    }

    private static PixelWidget firstSelectable(List<PixelWidget> list) {
        for (PixelWidget w : list) {
            if (w.isVisible() && w.isEnabled()) {
                return w;
            }
        }
        return null;
    }

    private PixelWidget widgetAt(MouseEvent e) {
        double s = scale();
        int vx = (int) Math.floor((e.getX() - offsetX()) / s);
        int vy = (int) Math.floor((e.getY() - offsetY()) / s);
        List<PixelWidget> list = activeWidgets();
        for (int i = list.size() - 1; i >= 0; i--) {
            PixelWidget w = list.get(i);
            if (w.isVisible() && w.isEnabled() && w.contains(vx, vy)) {
                return w;
            }
        }
        return null;
    }

    private void installMouse() {
        MouseAdapter mouse = new MouseAdapter() {
            @Override
            public void mouseMoved(MouseEvent e) {
                PixelWidget w = widgetAt(e);
                hovered = w;
                keyboardMode = false;
                if (w != null) {
                    focused = w;
                }
                setCursor(Cursor.getPredefinedCursor(w != null ? Cursor.HAND_CURSOR : Cursor.DEFAULT_CURSOR));
            }

            @Override
            public void mouseExited(MouseEvent e) {
                hovered = null;
            }

            @Override
            public void mouseDragged(MouseEvent e) {
                mouseMoved(e);
            }

            @Override
            public void mousePressed(MouseEvent e) {
                pressed = widgetAt(e);
            }

            @Override
            public void mouseReleased(MouseEvent e) {
                PixelWidget w = widgetAt(e);
                PixelWidget wasPressed = pressed;
                pressed = null;
                if (interceptInput()) {
                    return;
                }
                if (w != null && w == wasPressed) {
                    activate(w);
                }
            }
        };
        addMouseListener(mouse);
        addMouseMotionListener(mouse);
    }

    private void installKeys() {
        bindKey("UP", () -> moveFocus(-1));
        bindKey("LEFT", () -> moveFocus(-1));
        bindKey("DOWN", () -> moveFocus(1));
        bindKey("RIGHT", () -> moveFocus(1));
        bindKey("ENTER", this::clickFocused);
        bindKey("SPACE", this::clickFocused);
        bindKey("ESCAPE", () -> {
            if (!dialogOpen) {
                onEscape();
            } else if (dialogClosable) {
                closeDialog();
            }
        });
    }

    /** Connects a keyboard key (e.g. "1", "U", "ESCAPE") to an action on this screen. */
    protected void bindKey(String key, Runnable action) {
        getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(KeyStroke.getKeyStroke(key), key);
        getActionMap().put(key, new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (isShowing()) { // only the screen that is currently visible reacts
                    action.run();
                }
            }
        });
    }

    private void moveFocus(int direction) {
        List<PixelWidget> selectable = new ArrayList<>();
        for (PixelWidget w : activeWidgets()) {
            if (w.isVisible() && w.isEnabled()) {
                selectable.add(w);
            }
        }
        if (selectable.isEmpty()) {
            return;
        }
        int index = selectable.indexOf(focused);
        index = index < 0 ? 0 : Math.floorMod(index + direction, selectable.size());
        focused = selectable.get(index);
        keyboardMode = true;
    }

    private void clickFocused() {
        if (interceptInput()) {
            return;
        }
        if (focused != null && activeWidgets().contains(focused)) {
            activate(focused);
        }
    }

    /** Clicks a widget and plays the click sound. */
    private void activate(PixelWidget widget) {
        if (widget.isEnabled()) {
            window.getSound().play(Sfx.CLICK);
        }
        widget.click();
    }
}
