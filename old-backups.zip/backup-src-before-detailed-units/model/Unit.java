package model;

import game.Battle;
import java.awt.Color;
import java.awt.Graphics2D;
import ui.pixel.SpritePen;

/**
 * A soldier that walks toward the enemy tower (abstract).
 *
 * The walking, targeting, and attacking logic is the same for every unit, so it lives here.
 * Each subclass only decides:
 *   - its role (FAST / RANGED / TANK) and stats (passed to the constructor)
 *   - how it looks: drawBody()
 *   - its ABILITY, using these "hooks" (methods the Battle calls at the right moment):
 *       onSpawn()        right after it enters the field     (Coach's whistle)
 *       updateAbility()  every game step while it is alive    (Barista heals, Librarian slows)
 *       onHit()          after each of its attacks lands      (Chef burns, Hacker steals energy)
 *       onDeath()        when it is destroyed                 (Robot explodes)
 *       targetsUnits()   false = ignores units, only hits towers (Drone)
 *     and getAbilityName() / getAbilityText() to explain it on the Lineup screen and tooltips.
 *   - optional projectile look for ranged units: projectileKind()
 *
 * Polymorphism: the Battle just calls unit.onHit(...), unit.onDeath(...) and so on;
 * each subclass decides what really happens.
 *
 * Units walk in one of 3 lanes. A unit waits if a teammate in the same lane is right in front
 * of it, so armies form lines instead of one big blob.
 */
public abstract class Unit extends Combatant {

    public static final int LANES = 3;
    public static final int LANE_SPACING = 9; // pixels between units in the same lane
    public static final double SIEGE_BONUS = 1.5; // units deal extra damage to towers
    private static final SpritePen PEN = new SpritePen();
    private static int nextId;

    private final int id = nextId++;
    private final String name;
    private final Role role;
    protected double damage;
    protected final double attackInterval;
    protected final double range;
    protected double speed;
    private double attackCooldown;
    private double attackAnimation;
    private double walked;
    private double aliveTime;
    private int attacksMade;
    private int lane;
    private boolean moving;

    protected Unit(String name, Role role, Side side, double hp, double damage, double attackInterval,
                   double range, double speed) {
        super(side, 0, hp);
        this.name = name;
        this.role = role;
        this.damage = damage;
        this.attackInterval = attackInterval;
        this.range = range;
        this.speed = speed;
    }

    /** How the unit looks (facing right). The pen mirrors it automatically for the enemy. */
    protected abstract void drawBody(SpritePen pen, int frame, int tick);

    /** Sprite height in pixels (for the HP bar and where projectiles hit). */
    public abstract int getHeight();

    // ---- Ability hooks (subclasses override the ones they need) ----

    /** Called once, right after the unit is spawned. Default: nothing. */
    public void onSpawn(Battle battle) {
    }

    /** Called every game step while the unit is alive and not frozen. Default: nothing. */
    protected void updateAbility(Battle battle, double dt) {
    }

    /** Special effect after a hit. Default: nothing. */
    protected void onHit(Battle battle, Combatant target) {
    }

    /** Called once when this unit is destroyed. Default: nothing. */
    public void onDeath(Battle battle) {
    }

    /** false = walks past enemy units and only attacks the tower (Drone). */
    public boolean targetsUnits() {
        return true;
    }

    /** Name of the special ability, e.g. "KITCHEN FIRE". */
    public abstract String getAbilityName();

    /** Short explanation of the ability, e.g. "HOT PANS BURN THE TARGET". */
    public abstract String getAbilityText();

    /** What ranged units throw. */
    protected Projectile.Kind projectileKind() {
        return Projectile.Kind.CHALK;
    }

    public void placeAt(double x, int lane) {
        this.x = x;
        this.lane = lane;
    }

    /** Applies stage modifiers when the unit is spawned. */
    public void applyModifiers(double speedMultiplier, double hpMultiplier) {
        speed *= speedMultiplier;
        scaleHp(hpMultiplier);
    }

    public boolean isRanged() {
        return range > 20;
    }

    /** 1.5 if this unit counters the target, 0.7 if the target counters it, otherwise 1. */
    public double counterMultiplier(Combatant target) {
        Role targetRole = target instanceof Unit u ? u.role : null;
        return role.multiplierAgainst(targetRole);
    }

    /** Damage against a target, including the role counter bonus and the siege bonus vs towers. */
    public double damageAgainst(Combatant target) {
        double siege = target instanceof Tower ? SIEGE_BONUS : 1.0;
        return damage * counterMultiplier(target) * siege;
    }

    /** Called every game step: attack if something is in range, otherwise walk forward. */
    public void update(Battle battle, double dt) {
        moving = false;
        if (!isAlive() || isFrozen()) {
            return;
        }
        aliveTime += dt;
        attackCooldown -= dt * attackSpeedFactor();
        attackAnimation -= dt;
        updateAbility(battle, dt);

        Combatant target = battle.findTargetFor(this);
        if (target != null) {
            if (attackCooldown <= 0) {
                attacksMade++;
                attack(battle, target);
                attackCooldown = attackInterval;
                attackAnimation = 0.15;
            }
        } else if (!battle.isBlockedByTeammate(this)) {
            double step = speed * speedFactor() * dt;
            x += side.direction() * step;
            walked += step;
            moving = true;
        }
    }

    protected void attack(Battle battle, Combatant target) {
        if (isRanged()) {
            battle.addProjectile(new Projectile(projectileKind(), side,
                    x + side.direction() * 4, Battle.GROUND_Y + laneY() - getHeight() + 4,
                    target, 110, damageAgainst(target), 6, hit -> onHit(battle, hit))
                    .withCounterMultiplier(counterMultiplier(target)));
        } else {
            battle.hit(target, damageAgainst(target), side, counterMultiplier(target));
            onHit(battle, target);
        }
    }

    /** Raises damage and max HP (Student graduation). */
    protected void powerUp(double damageMultiplier, double hpMultiplier) {
        damage *= damageMultiplier;
        maxHp *= hpMultiplier;
        hp = maxHp;
    }

    /** Seconds since the unit was spawned. */
    public double getAliveTime() {
        return aliveTime;
    }

    /** How many attacks it has started (used for "every 4th hit" abilities). */
    protected int getAttacksMade() {
        return attacksMade;
    }

    // ---- Drawing ----

    public void draw(Graphics2D g, int groundY, int tick) {
        int frame = (int) (walked / 3) % 2;
        int lunge = attackAnimation > 0 ? side.direction() * 2 : 0;
        int footX = (int) Math.round(x) + lunge;
        int gy = groundY + laneY();
        PEN.setTint(isFlashing() ? Color.WHITE : null);
        drawSprite(g, footX, gy, side.direction(), frame, tick);
        PEN.setTint(null);

        int h = getHeight();
        if (isFrozen()) {
            g.setColor(new Color(180, 230, 255, 150));
            g.fillRect(footX - 6, gy - h - 1, 12, h + 1);
            g.setColor(new Color(235, 250, 255));
            g.fillRect(footX - 6, gy - h - 1, 12, 1);
        }
        if (isBurning()) {
            g.setColor(new Color(0xFF7A1A));
            g.fillRect(footX - 2 + (tick / 3) % 3, gy - h - 3, 1, 2);
            g.setColor(new Color(0xFFD23F));
            g.fillRect(footX + 1 - (tick / 4) % 2, gy - h - 2, 1, 2);
        }
        if (isHasted() && !isFrozen()) {
            // little speed lines behind the unit
            g.setColor(new Color(0xFFE066));
            int back = footX - side.direction() * 6;
            g.fillRect(back - 1, gy - h / 2 - 2, 3, 1);
            g.fillRect(back - side.direction() * 2 - 1, gy - h / 2 + 1, 3, 1);
        }
        if (isSlowed() && !isFrozen()) {
            g.setColor(new Color(0x7DD3FC));
            g.fillRect(footX - 4, gy, 1, 1);
            g.fillRect(footX + 3, gy, 1, 1);
        }
        if (hp < maxHp) {
            int barY = gy - h - 5;
            g.setColor(new Color(0x2A1A1A));
            g.fillRect(footX - 6, barY, 12, 3);
            g.setColor(side == Side.PLAYER ? new Color(0x6BE36B) : new Color(0xFF5A4E));
            g.fillRect(footX - 5, barY + 1, (int) Math.ceil(10 * hpRatio()), 1);
        }
    }

    /** Draws only the body (also used for the icons on the spawn buttons). */
    public void drawSprite(Graphics2D g, int footX, int groundY, int facing, int frame, int tick) {
        PEN.begin(g, footX, groundY, facing);
        PEN.setOutline(true);
        drawBody(PEN, frame, tick);
        PEN.setOutline(false);
        drawBody(PEN, frame, tick);
    }

    /** Lanes further back are drawn higher up, so the three lanes look like depth. */
    public int laneY() {
        return lane * 2;
    }

    // ---- Common body parts (used by the subclasses) ----

    protected static final Color SKIN = new Color(0xF2C28E);
    protected static final Color SKIN_DARK = new Color(0xC98E5A);
    protected static final Color EYE = new Color(0x1E140C);

    /** Two legs that step while walking. */
    protected static void legs(SpritePen p, int frame, int height, Color color) {
        if (frame == 0) {
            p.rect(-2, height, 1, height, color);
            p.rect(1, height, 1, height, color);
        } else {
            p.rect(-1, height, 1, height, color);
            p.rect(0, height, 1, height, color);
        }
    }

    /** Head (4x4) whose top is 'top' pixels above the ground, with an eye looking forward. */
    protected static void head(SpritePen p, int top, Color skin, Color hair) {
        p.rect(-2, top, 4, 4, skin);
        p.rect(-2, top, 4, 1, hair);
        p.rect(-2, top - 1, 1, 1, hair);
        p.rect(1, top - 2, 1, 1, EYE);
    }

    @Override
    public int getHitHeight() {
        return getHeight() / 2 - laneY();
    }

    // ---- Getters ----

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public Role getRole() {
        return role;
    }

    public int getLane() {
        return lane;
    }

    public boolean isMoving() {
        return moving;
    }

    public double getRange() {
        return range;
    }

    public double getDamage() {
        return damage;
    }

    public double getSpeed() {
        return speed;
    }

    public double getAttackInterval() {
        return attackInterval;
    }
}
