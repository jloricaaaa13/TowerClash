package model.units;

import game.Battle;
import game.effects.FloatText;
import java.awt.Color;
import model.Role;
import model.Side;
import model.Unit;
import ui.pixel.SpritePen;

/**
 * Education - fast fighter, the P.E. coach.
 * Ability PEP TALK: when spawned, blows the whistle and ALL your units
 * move and attack 30% faster for 5 seconds.
 */
public class Coach extends Unit {

    private static final double HASTE = 0.3;
    private static final double HASTE_SECONDS = 5;

    public Coach(Side side) {
        //      name    role       side  hp  dmg atkInterval range speed
        super("Coach", Role.FAST, side, 90, 12, 0.8, 10, 30);
    }

    @Override
    public void onSpawn(Battle battle) {
        for (Unit ally : battle.unitsOf(side)) {
            ally.applyHaste(HASTE, HASTE_SECONDS);
        }
        battle.addEffect(new FloatText(x, Battle.GROUND_Y - getHeight() - 8, "TWEET!", new Color(0xFFE066)));
    }

    @Override
    public String getAbilityName() {
        return "PEP TALK";
    }

    @Override
    public String getAbilityText() {
        return "ON SPAWN: ALL UNITS 30% FASTER";
    }

    @Override
    protected void drawBody(SpritePen p, int frame, int tick) {
        legs(p, frame, 3, SKIN);
        p.rect(-2, 5, 4, 2, new Color(0x1E3A8A));       // shorts
        p.rect(-2, 8, 4, 4, new Color(0x2563EB));       // blue jersey
        p.rect(-2, 6, 4, 1, Color.WHITE);               // white stripe
        p.rect(2, 7, 1, 2, SKIN);                       // arm
        p.rect(1, 9, 1, 1, new Color(0xD1D5DB));        // whistle
        head(p, 12, SKIN, new Color(0x3B2314));
        p.rect(-2, 13, 4, 2, new Color(0x1D4ED8));      // cap
        p.rect(2, 12, 2, 1, new Color(0x1D4ED8));       // cap brim
    }

    @Override
    public int getHeight() {
        return 14;
    }
}
