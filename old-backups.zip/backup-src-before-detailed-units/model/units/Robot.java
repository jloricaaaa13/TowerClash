package model.units;

import game.Battle;
import game.effects.Puff;
import java.awt.Color;
import model.Role;
import model.Side;
import model.Unit;
import ui.pixel.SpritePen;

/**
 * Computer Science - the tank. A slow metal robot.
 * Ability SELF-DESTRUCT: explodes when destroyed, hurting nearby enemy units.
 */
public class Robot extends Unit {

    private static final double BLAST_RANGE = 24;
    private static final double BLAST_DAMAGE = 30;

    public Robot(Side side) {
        super("Robot", Role.TANK, side, 310, 17, 1.4, 12, 10);
    }

    @Override
    public void onDeath(Battle battle) {
        for (Unit enemy : battle.unitsNear(side.opponent(), x, BLAST_RANGE)) {
            battle.damage(enemy, BLAST_DAMAGE, side);
        }
        for (int i = 0; i < 3; i++) {
            battle.addEffect(new Puff(x - 8 + i * 8, Battle.GROUND_Y - 6 - i % 2 * 4, new Color(0xFF8A3D)));
        }
        battle.shake(2);
    }

    @Override
    public String getAbilityName() {
        return "SELF-DESTRUCT";
    }

    @Override
    public String getAbilityText() {
        return "EXPLODES WHEN DESTROYED (30 DMG)";
    }

    @Override
    protected void drawBody(SpritePen p, int frame, int tick) {
        Color metal = new Color(0xB8C0CC);
        p.rect(-4, 3, 8, 3, new Color(0x374151));       // treads
        p.rect(-3 + frame, 2, 1, 1, new Color(0x9CA3AF));
        p.rect(1 + frame, 2, 1, 1, new Color(0x9CA3AF));
        p.rect(-3, 11, 7, 8, metal);                    // body
        p.rect(-3, 8, 7, 1, new Color(0xEAB308));       // yellow stripe
        p.rect(4, 9, 2, 4, new Color(0x8B95A5));        // arm
        p.rect(-2, 15, 5, 4, metal);                    // head
        boolean blink = (tick / 20) % 6 == 0;
        p.rect(1, 13, 2, 1, blink ? metal : new Color(0xFF3B30)); // red eye
        p.rect(0, 18, 1, 3, new Color(0x6B7280));       // antenna
        p.rect(0, 19, 1, 1, new Color(0xEAB308));       // antenna light
    }

    @Override
    public int getHeight() {
        return 19;
    }
}
