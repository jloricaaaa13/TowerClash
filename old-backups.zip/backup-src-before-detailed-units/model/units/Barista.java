package model.units;

import game.Battle;
import java.awt.Color;
import model.Projectile;
import model.Role;
import model.Side;
import model.Unit;
import ui.pixel.SpritePen;

/**
 * Hospitality - ranged support. Throws hot coffee (low damage).
 * Ability COFFEE BREAK: every 4 seconds heals itself and nearby teammates.
 */
public class Barista extends Unit {

    private static final double HEAL_EVERY = 4;
    private static final double HEAL_RANGE = 40;
    private static final double HEAL_AMOUNT = 16;

    private double healTimer = 1.5; // first heal comes a bit sooner

    public Barista(Side side) {
        //      name      role         side  hp  dmg atkInterval range speed
        super("Barista", Role.RANGED, side, 90, 8, 1.3, 45, 17);
    }

    @Override
    protected void updateAbility(Battle battle, double dt) {
        healTimer -= dt;
        if (healTimer > 0) {
            return;
        }
        healTimer = HEAL_EVERY;
        for (Unit ally : battle.unitsNear(side, x, HEAL_RANGE)) {
            battle.healTarget(ally, HEAL_AMOUNT);
        }
    }

    @Override
    protected Projectile.Kind projectileKind() {
        return Projectile.Kind.COFFEE;
    }

    @Override
    public String getAbilityName() {
        return "COFFEE BREAK";
    }

    @Override
    public String getAbilityText() {
        return "HEALS NEARBY TEAMMATES";
    }

    @Override
    protected void drawBody(SpritePen p, int frame, int tick) {
        legs(p, frame, 3, new Color(0x3F2A1E));
        p.rect(-2, 8, 4, 5, new Color(0xB91C1C));       // red shirt
        p.rect(-1, 7, 3, 4, new Color(0x7C4A2D));       // brown apron
        p.rect(2, 8, 1, 2, SKIN);                       // arm
        p.rect(3, 10, 2, 3, Color.WHITE);               // coffee cup
        p.rect(3, 10, 2, 1, new Color(0x6B3E1E));       // coffee
        p.rect(3 + (tick / 10) % 2, 12, 1, 1, new Color(0xD6D3D1)); // steam
        head(p, 12, SKIN, new Color(0x1E140C));
        p.rect(-2, 13, 4, 1, new Color(0x7F1D1D));      // cap
    }

    @Override
    public int getHeight() {
        return 14;
    }
}
