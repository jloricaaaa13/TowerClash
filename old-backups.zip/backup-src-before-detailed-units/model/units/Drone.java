package model.units;

import java.awt.Color;
import model.Role;
import model.Side;
import model.Unit;
import ui.pixel.SpritePen;

/**
 * Computer Science - a small flying drone.
 * Ability AIR STRIKE: flies over enemy units and ONLY attacks the enemy tower.
 * Enemy units and towers can still shoot it down, and it has low HP.
 */
public class Drone extends Unit {

    public Drone(Side side) {
        //      name    role       side  hp  dmg atkInterval range speed
        super("Drone", Role.FAST, side, 65, 9, 0.9, 10, 36);
    }

    @Override
    public boolean targetsUnits() {
        return false;
    }

    @Override
    public String getAbilityName() {
        return "AIR STRIKE";
    }

    @Override
    public String getAbilityText() {
        return "FLIES PAST UNITS, HITS ONLY TOWERS";
    }

    @Override
    protected void drawBody(SpritePen p, int frame, int tick) {
        int bob = (tick / 8) % 2;                        // hovers up and down
        Color metal = new Color(0x9CA3AF);
        p.rect(-3, 11 + bob, 7, 3, new Color(0xEAB308)); // yellow body
        p.rect(-2, 9 + bob, 5, 1, new Color(0x374151)); // bottom
        p.rect(2, 10 + bob, 1, 1, new Color(0xEF4444)); // camera eye
        p.rect(-5, 12 + bob, 2, 1, metal);               // arms
        p.rect(4, 12 + bob, 2, 1, metal);
        boolean spin = (tick / 2) % 2 == 0;              // spinning propellers
        Color blade = new Color(0xE5E7EB);
        if (spin) {
            p.rect(-7, 13 + bob, 5, 1, blade);
            p.rect(3, 13 + bob, 5, 1, blade);
        } else {
            p.rect(-5, 13 + bob, 2, 1, blade);
            p.rect(4, 13 + bob, 2, 1, blade);
        }
    }

    @Override
    public int getHeight() {
        return 14;
    }

    /** Projectiles aim at the flying body, not at the ground. */
    @Override
    public int getHitHeight() {
        return 11 - laneY();
    }
}
