package model.units;

import game.Battle;
import java.awt.Color;
import model.Combatant;
import model.Projectile;
import model.Role;
import model.Side;
import model.Unit;
import ui.pixel.SpritePen;

/**
 * Computer Science - ranged. A hacker in a dark hoodie who sends viruses.
 * Ability DATA THEFT: every hit steals 3 energy from the enemy and gives it to you.
 */
public class Hacker extends Unit {

    private static final double STEAL = 3;

    public Hacker(Side side) {
        //      name     role         side  hp  dmg atkInterval range speed
        super("Hacker", Role.RANGED, side, 80, 10, 1.5, 55, 16);
    }

    @Override
    protected void onHit(Battle battle, Combatant target) {
        double stolen = battle.drainEnergy(side.opponent(), STEAL);
        battle.addEnergy(side, stolen);
    }

    @Override
    protected Projectile.Kind projectileKind() {
        return Projectile.Kind.VIRUS;
    }

    @Override
    public String getAbilityName() {
        return "DATA THEFT";
    }

    @Override
    public String getAbilityText() {
        return "HITS STEAL 3 ENEMY ENERGY";
    }

    @Override
    protected void drawBody(SpritePen p, int frame, int tick) {
        legs(p, frame, 3, new Color(0x111827));
        p.rect(-2, 9, 4, 6, new Color(0x1F2937));       // dark hoodie
        p.rect(-2, 6, 4, 1, new Color(0xEAB308));       // yellow stripe
        p.rect(2, 6, 4, 1, new Color(0x6B7280));        // laptop base
        p.rect(4, 9, 1, 3, new Color(0x6B7280));        // laptop screen
        boolean blink = (tick / 8) % 2 == 0;
        p.rect(3, 8, 1, 1, blink ? new Color(0xEF4444) : new Color(0x7F1D1D)); // red glow
        head(p, 13, SKIN, new Color(0x111827));
        p.rect(-3, 14, 5, 1, new Color(0x1F2937));      // hood
        p.rect(-3, 13, 1, 4, new Color(0x1F2937));
    }

    @Override
    public int getHeight() {
        return 15;
    }
}
