package model.units;

import game.Battle;
import java.awt.Color;
import model.Projectile;
import model.Role;
import model.Side;
import model.Unit;
import ui.pixel.SpritePen;

/**
 * Education - ranged support. Carries a stack of books and throws them.
 * Ability QUIET PLEASE: enemy units near the Librarian are slowed by 30%.
 */
public class Librarian extends Unit {

    private static final double AURA_RANGE = 50;
    private static final double SLOW = 0.3;

    public Librarian(Side side) {
        //      name        role         side  hp  dmg atkInterval range speed
        super("Librarian", Role.RANGED, side, 110, 15, 1.4, 55, 16);
    }

    @Override
    protected void updateAbility(Battle battle, double dt) {
        for (Unit enemy : battle.unitsNear(side.opponent(), x, AURA_RANGE)) {
            enemy.applySlow(SLOW, 0.3); // refreshed every step while they stay close
        }
    }

    @Override
    protected Projectile.Kind projectileKind() {
        return Projectile.Kind.BOOK;
    }

    @Override
    public String getAbilityName() {
        return "QUIET PLEASE";
    }

    @Override
    public String getAbilityText() {
        return "SLOWS ALL ENEMIES NEARBY";
    }

    @Override
    protected void drawBody(SpritePen p, int frame, int tick) {
        legs(p, frame, 3, new Color(0x52525B));
        p.rect(-2, 7, 5, 4, new Color(0x1E3A8A));       // long skirt
        p.rect(-2, 10, 4, 4, new Color(0x60A5FA));      // light blue cardigan
        p.rect(2, 10, 3, 1, new Color(0xB33A3A));       // stack of books
        p.rect(2, 9, 3, 1, new Color(0x16A34A));
        p.rect(2, 8, 3, 1, new Color(0xEAB308));
        head(p, 14, SKIN, new Color(0x6B3E1E));
        p.rect(-4, 15, 2, 2, new Color(0x6B3E1E));      // hair bun
        p.rect(0, 12, 2, 1, EYE);                       // glasses
    }

    @Override
    public int getHeight() {
        return 15;
    }
}
