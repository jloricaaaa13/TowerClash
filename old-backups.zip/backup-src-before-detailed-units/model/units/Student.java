package model.units;

import game.Battle;
import game.effects.FloatText;
import java.awt.Color;
import model.Role;
import model.Side;
import model.Unit;
import ui.pixel.SpritePen;

/**
 * Education - the cheapest and fastest unit. Comes in big groups.
 * Ability GRADUATION: if it survives for 15 seconds it graduates:
 * full HP, +25% max HP and +30% damage (and it gets a graduation cap).
 */
public class Student extends Unit {

    private static final double GRADUATE_AFTER = 15;

    private boolean graduated;

    public Student(Side side) {
        super("Student", Role.FAST, side, 60, 10, 0.7, 10, 32);
    }

    @Override
    protected void updateAbility(Battle battle, double dt) {
        if (!graduated && getAliveTime() >= GRADUATE_AFTER) {
            graduated = true;
            powerUp(1.3, 1.25);
            battle.addEffect(new FloatText(x, Battle.GROUND_Y - getHeight() - 8, "GRADUATED!", new Color(0xFFD86E)));
        }
    }

    public boolean isGraduated() {
        return graduated;
    }

    @Override
    public String getAbilityName() {
        return "GRADUATION";
    }

    @Override
    public String getAbilityText() {
        return "SURVIVE 15 SEC: GETS STRONGER";
    }

    @Override
    protected void drawBody(SpritePen p, int frame, int tick) {
        legs(p, frame, 3, new Color(0x3B5B8C));
        p.rect(-2, 7, 4, 4, new Color(0x2563EB));       // blue uniform
        p.rect(-4, 8, 2, 5, new Color(0xF2B33D));       // backpack
        p.rect(2, 6, 1, 2, SKIN);                       // arm
        head(p, 11, SKIN, new Color(0x1E140C));
        if (graduated) {
            p.rect(-3, 13, 7, 1, new Color(0x111827)); // graduation cap
            p.rect(-1, 12, 3, 1, new Color(0x111827));
            p.rect(3, 12, 1, 2, new Color(0xFACC15));  // gold tassel
        }
    }

    @Override
    public int getHeight() {
        return graduated ? 14 : 12;
    }
}
