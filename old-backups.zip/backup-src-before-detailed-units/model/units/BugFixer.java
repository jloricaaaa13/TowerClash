package model.units;

import game.Battle;
import java.awt.Color;
import model.Combatant;
import model.Role;
import model.Side;
import model.Unit;
import ui.pixel.SpritePen;

/**
 * Computer Science - fast unit with very quick wrench hits.
 * Ability PATCH: repairs itself for half of the damage it deals.
 */
public class BugFixer extends Unit {

    public BugFixer(Side side) {
        super("Bug Fixer", Role.FAST, side, 60, 6, 0.45, 10, 34);
    }

    @Override
    protected void onHit(Battle battle, Combatant target) {
        heal(damage * 0.5);
    }

    @Override
    public String getAbilityName() {
        return "PATCH";
    }

    @Override
    public String getAbilityText() {
        return "HEALS ITSELF WHEN IT HITS";
    }

    @Override
    protected void drawBody(SpritePen p, int frame, int tick) {
        legs(p, frame, 3, new Color(0x374151));
        p.rect(-2, 7, 4, 4, new Color(0xEAB308));       // yellow shirt
        p.rect(2, 7, 1, 2, SKIN);                       // arm
        p.rect(3, 9, 1, 4, new Color(0x9CA3AF));        // wrench handle
        p.rect(3, 10, 2, 1, new Color(0x9CA3AF));       // wrench head
        head(p, 11, SKIN, new Color(0x3B2314));
        p.rect(-2, 12, 4, 2, new Color(0xCA8A04));      // cap
        p.rect(2, 11, 2, 1, new Color(0xCA8A04));       // cap brim
    }

    @Override
    public int getHeight() {
        return 13;
    }
}
