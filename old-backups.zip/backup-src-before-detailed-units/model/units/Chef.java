package model.units;

import game.Battle;
import java.awt.Color;
import model.Combatant;
import model.Projectile;
import model.Role;
import model.Side;
import model.Unit;
import ui.pixel.SpritePen;

/**
 * Hospitality - ranged. Throws sizzling hot pans.
 * Ability KITCHEN FIRE: hits BURN the target (damage over time).
 */
public class Chef extends Unit {

    private static final double BURN_DPS = 4;
    private static final double BURN_SECONDS = 3;

    public Chef(Side side) {
        super("Chef", Role.RANGED, side, 100, 13, 1.3, 45, 17);
    }

    @Override
    protected void onHit(Battle battle, Combatant target) {
        target.applyBurn(BURN_DPS, BURN_SECONDS, side);
    }

    @Override
    protected Projectile.Kind projectileKind() {
        return Projectile.Kind.PLATE;
    }

    @Override
    public String getAbilityName() {
        return "KITCHEN FIRE";
    }

    @Override
    public String getAbilityText() {
        return "HOT PANS BURN THE TARGET";
    }

    @Override
    protected void drawBody(SpritePen p, int frame, int tick) {
        legs(p, frame, 3, new Color(0x4B4B4B));
        p.rect(-2, 8, 4, 5, new Color(0xFAFAFA));       // white jacket
        p.rect(-2, 8, 4, 1, new Color(0xDC2626));       // red neckerchief
        p.rect(2, 7, 1, 2, SKIN);                       // arm
        p.rect(3, 7, 4, 1, new Color(0x3F3F46));        // frying pan
        head(p, 12, SKIN, new Color(0x3B2314));
        p.rect(-2, 14, 4, 2, Color.WHITE);              // hat band
        p.rect(-3, 17, 6, 3, Color.WHITE);              // puffy chef hat
    }

    @Override
    public int getHeight() {
        return 18;
    }
}
