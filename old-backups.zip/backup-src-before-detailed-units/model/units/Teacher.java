package model.units;

import game.Battle;
import java.awt.Color;
import model.Combatant;
import model.Projectile;
import model.Role;
import model.Side;
import model.Unit;
import ui.pixel.SpritePen;

/**
 * Education - ranged attacker.
 * Ability CHALK TOSS: hits SLOW the target by 25%.
 */
public class Teacher extends Unit {

    public Teacher(Side side) {
        super("Teacher", Role.RANGED, side, 95, 20, 1.4, 60, 16);
    }

    @Override
    public String getAbilityName() {
        return "CHALK TOSS";
    }

    @Override
    public String getAbilityText() {
        return "CHALK SLOWS THE TARGET";
    }

    @Override
    protected void onHit(Battle battle, Combatant target) {
        target.applySlow(0.25, 1.5);
    }

    @Override
    protected Projectile.Kind projectileKind() {
        return Projectile.Kind.CHALK;
    }

    @Override
    protected void drawBody(SpritePen p, int frame, int tick) {
        legs(p, frame, 3, new Color(0x52525B));
        p.rect(-2, 9, 4, 6, new Color(0x1D4ED8));       // long blue coat
        p.rect(2, 8, 3, 4, new Color(0xB33A3A));        // book
        p.rect(2, 8, 3, 1, Color.WHITE);                // pages
        head(p, 13, SKIN, new Color(0x6B3E1E));
        p.rect(0, 11, 2, 1, EYE);                       // glasses
    }

    @Override
    public int getHeight() {
        return 14;
    }
}
