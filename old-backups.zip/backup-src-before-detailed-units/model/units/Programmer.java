package model.units;

import game.Battle;
import game.effects.Zap;
import java.awt.Color;
import model.Combatant;
import model.Projectile;
import model.Role;
import model.Side;
import model.Unit;
import ui.pixel.SpritePen;

/**
 * Computer Science - ranged attacker that shoots lines of code from a laptop.
 * Ability OVERCLOCK: every 4th shot also zaps the nearest other enemy.
 */
public class Programmer extends Unit {

    private static final int EVERY = 4;
    private static final double ZAP_RANGE = 35;
    private static final double ZAP_DAMAGE = 0.6;

    public Programmer(Side side) {
        super("Programmer", Role.RANGED, side, 85, 12, 0.8, 55, 17);
    }

    @Override
    protected void onHit(Battle battle, Combatant target) {
        if (getAttacksMade() % EVERY != 0) {
            return;
        }
        Unit next = null;
        double best = ZAP_RANGE;
        for (Unit u : battle.unitsOf(side.opponent())) {
            double d = Math.abs(u.getX() - target.getX());
            if (u != target && d <= best) {
                best = d;
                next = u;
            }
        }
        if (next != null) {
            battle.addEffect(new Zap(battle.hitX(target), battle.hitY(target), battle.hitX(next), battle.hitY(next)));
            battle.damage(next, damage * ZAP_DAMAGE, side);
        }
    }

    @Override
    public String getAbilityName() {
        return "OVERCLOCK";
    }

    @Override
    public String getAbilityText() {
        return "EVERY 4TH SHOT ZAPS ONE MORE ENEMY";
    }

    @Override
    protected Projectile.Kind projectileKind() {
        return Projectile.Kind.CODE;
    }

    @Override
    protected void drawBody(SpritePen p, int frame, int tick) {
        legs(p, frame, 3, new Color(0x1F2937));
        p.rect(-2, 9, 4, 6, new Color(0xEAB308));       // yellow hoodie
        p.rect(-3, 12, 1, 4, new Color(0xCA8A04));      // hood
        p.rect(2, 6, 4, 1, new Color(0x6B7280));        // laptop base
        p.rect(4, 9, 1, 3, new Color(0x6B7280));        // laptop screen
        p.rect(3, 8, 1, 1, new Color(0x4ADE80));        // screen glow
        head(p, 13, SKIN_DARK, new Color(0x1E140C));
        p.rect(-2, 14, 4, 1, new Color(0x111827));      // headphones band
        p.rect(-2, 12, 1, 2, new Color(0x111827));      // headphone
    }

    @Override
    public int getHeight() {
        return 15;
    }
}
