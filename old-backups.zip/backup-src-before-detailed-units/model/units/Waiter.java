package model.units;

import game.Battle;
import java.awt.Color;
import model.Combatant;
import model.Role;
import model.Side;
import model.Unit;
import ui.pixel.SpritePen;

/**
 * Hospitality - fast and cheap, but low HP. Carries a tray.
 * Ability TIP JAR: every hit earns you +2 energy.
 */
public class Waiter extends Unit {

    private static final double TIP = 2;

    public Waiter(Side side) {
        //      name     role       side  hp   dmg  atkInterval range speed
        super("Waiter", Role.FAST, side, 80, 11, 0.7, 10, 30);
    }

    @Override
    protected void onHit(Battle battle, Combatant target) {
        battle.addEnergy(side, TIP);
    }

    @Override
    public String getAbilityName() {
        return "TIP JAR";
    }

    @Override
    public String getAbilityText() {
        return "EVERY HIT GIVES YOU +2 ENERGY";
    }

    @Override
    protected void drawBody(SpritePen p, int frame, int tick) {
        legs(p, frame, 3, new Color(0x222222));
        p.rect(-2, 8, 4, 5, new Color(0xDC2626));       // red vest
        p.rect(0, 8, 1, 5, new Color(0xF5F5F5));        // white shirt
        p.rect(2, 11, 1, 4, SKIN);                      // arm up
        p.rect(0, 12, 6, 1, new Color(0xCFD6DD));       // tray
        p.rect(3, 14, 2, 2, Color.WHITE);               // cup
        head(p, 12, SKIN, new Color(0x3B2314));
    }

    @Override
    public int getHeight() {
        return 14;
    }
}
