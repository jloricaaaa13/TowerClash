package model.units;

import java.awt.Color;
import model.Role;
import model.Side;
import model.Unit;
import ui.pixel.SpritePen;

/**
 * Hospitality - the tank. Lots of HP, slow, carries a big suitcase.
 * Ability LUGGAGE SHIELD: the big suitcase blocks 20% of all damage it takes.
 */
public class Bellboy extends Unit {

    private static final double BLOCK = 0.20;

    public Bellboy(Side side) {
        super("Bellboy", Role.TANK, side, 320, 14, 1.2, 12, 12);
    }

    /** Overrides how damage is received: only 80% gets through the suitcase. */
    @Override
    public double receiveDamage(double amount) {
        return super.receiveDamage(amount * (1 - BLOCK));
    }

    @Override
    public String getAbilityName() {
        return "LUGGAGE SHIELD";
    }

    @Override
    public String getAbilityText() {
        return "SUITCASE BLOCKS 20% OF DAMAGE";
    }

    @Override
    protected void drawBody(SpritePen p, int frame, int tick) {
        Color red = new Color(0xB91C1C);
        Color gold = new Color(0xFACC15);
        if (frame == 0) {
            p.rect(-2, 4, 2, 4, new Color(0x7F1D1D));
            p.rect(1, 4, 2, 4, new Color(0x7F1D1D));
        } else {
            p.rect(-1, 4, 2, 4, new Color(0x7F1D1D));
            p.rect(0, 4, 2, 4, new Color(0x7F1D1D));
        }
        p.rect(-3, 10, 7, 6, red);                      // uniform
        p.rect(0, 9, 1, 1, gold);                       // buttons
        p.rect(0, 7, 1, 1, gold);
        p.rect(-2, 15, 5, 5, SKIN);                     // head
        p.rect(2, 13, 1, 1, EYE);
        p.rect(-2, 16, 5, 2, red);                      // cap
        p.rect(-2, 15, 5, 1, gold);                     // cap band
        p.rect(4, 8, 5, 5, new Color(0x8B5A2B));        // suitcase
        p.rect(5, 9, 3, 1, new Color(0xD9A066));        // suitcase handle
    }

    @Override
    public int getHeight() {
        return 17;
    }
}
