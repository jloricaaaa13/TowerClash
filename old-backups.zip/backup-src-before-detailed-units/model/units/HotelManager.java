package model.units;

import game.Battle;
import java.awt.Color;
import model.Role;
import model.Side;
import model.Unit;
import ui.pixel.SpritePen;

/**
 * Hospitality - tank and leader. Slow, tough, in a dark red suit with a clipboard.
 * Ability FIVE-STAR SERVICE: teammates near the Manager move and attack 25% faster.
 */
public class HotelManager extends Unit {

    private static final double AURA_RANGE = 50;
    private static final double HASTE = 0.25;

    public HotelManager(Side side) {
        //      name      role       side  hp  dmg atkInterval range speed
        super("Manager", Role.TANK, side, 290, 13, 1.2, 12, 12);
    }

    @Override
    protected void updateAbility(Battle battle, double dt) {
        for (Unit ally : battle.unitsNear(side, x, AURA_RANGE)) {
            if (ally != this) {
                ally.applyHaste(HASTE, 0.3); // refreshed every step while they stay close
            }
        }
    }

    @Override
    public String getAbilityName() {
        return "FIVE-STAR SERVICE";
    }

    @Override
    public String getAbilityText() {
        return "NEARBY TEAMMATES ARE 25% FASTER";
    }

    @Override
    protected void drawBody(SpritePen p, int frame, int tick) {
        Color suit = new Color(0x7F1D1D);
        Color pants = new Color(0x3B0D0D);
        if (frame == 0) {
            p.rect(-2, 4, 2, 4, pants);
            p.rect(1, 4, 2, 4, pants);
        } else {
            p.rect(-1, 4, 2, 4, pants);
            p.rect(0, 4, 2, 4, pants);
        }
        p.rect(-3, 10, 7, 6, suit);                     // suit
        p.rect(0, 10, 1, 4, Color.WHITE);               // shirt
        p.rect(0, 9, 1, 2, new Color(0xFACC15));        // gold tie
        p.rect(-2, 15, 5, 5, SKIN);                     // head
        p.rect(-2, 15, 5, 1, new Color(0x1E140C));      // slick hair
        p.rect(-2, 16, 4, 1, new Color(0x1E140C));
        p.rect(2, 13, 1, 1, EYE);
        p.rect(4, 10, 3, 5, new Color(0xA16207));       // clipboard
        p.rect(4, 9, 3, 3, new Color(0xFFF7E6));        // paper
    }

    @Override
    public int getHeight() {
        return 17;
    }
}
