package ui.scenes;

import java.awt.Color;
import java.awt.Graphics2D;
import model.Department;
import model.PlayerProgress;
import model.Stage;
import ui.GameWindow;
import ui.pixel.Landscape;
import ui.pixel.Palette;
import ui.pixel.PixelArt;
import ui.pixel.PixelButton;
import ui.pixel.PixelFont;

/** The title screen: CONTINUE, NEW GAME, UPGRADES, HOW TO PLAY, OPTIONS, CREDITS, EXIT. */
public class MainMenuScene extends PixelScene {

    private static final int GROUND_Y = 150;

    private final Landscape landscape = new Landscape(GROUND_Y,
            new int[]{12, 30, 286, 304}, new int[]{21, 295});
    private final PixelButton continueButton;

    public MainMenuScene(GameWindow window) {
        super(window);

        int bw = 80;
        int bh = 13;
        int bx = (W - bw) / 2;
        int by = 41;
        int step = 15;
        continueButton = addWidget(new PixelButton("CONTINUE", bx, by, bw, bh, window::showTowerSelect));
        addWidget(new PixelButton("NEW GAME", bx, by + step, bw, bh, this::newGame));
        addWidget(new PixelButton("UPGRADES", bx, by + step * 2, bw, bh, window::showUpgrades));
        addWidget(new PixelButton("HOW TO PLAY", bx, by + step * 3, bw, bh, window::showHowToPlay));
        addWidget(new PixelButton("OPTIONS", bx, by + step * 4, bw, bh, window::showOptions));
        addWidget(new PixelButton("CREDITS", bx, by + step * 5, bw, bh, window::showCredits));
        addWidget(new PixelButton("EXIT", bx, by + step * 6, bw, bh, this::confirmExit));
    }

    @Override
    public void onShow() {
        continueButton.setEnabled(window.hasSavedGame()); // greyed out when there is nothing to continue
        super.onShow(); // selects the first enabled button (CONTINUE if there is a save)
    }

    /** If there is saved progress, ask first because it will be erased. */
    private void newGame() {
        if (window.hasSavedGame()) {
            showDialog("NEW GAME?", new String[]{"YOUR SAVED PROGRESS WILL BE ERASED.", "USE CONTINUE TO KEEP IT."},
                    "YES", window::startNewGame, "NO");
        } else {
            window.startNewGame();
        }
    }

    private void confirmExit() {
        showDialog("QUIT GAME?", new String[]{"ARE YOU SURE YOU WANT TO QUIT?"}, "YES", () -> System.exit(0), "NO");
    }

    @Override
    protected void onEscape() {
        confirmExit();
    }

    @Override
    protected void paintScene(Graphics2D g) {
        landscape.draw(g, tick);

        // The three department towers standing in the world
        PixelArt.tower(g, 52, GROUND_Y, 16, 34, Department.HOSPITALITY.getColor(), tick);
        PixelArt.tower(g, 80, GROUND_Y, 18, 44, Department.EDUCATION.getColor(), tick + 5);
        PixelArt.tower(g, 228, GROUND_Y, 18, 38, Department.COMPUTER_SCIENCE.getColor(), tick + 3);
        PixelArt.signpost(g, 262, GROUND_Y);

        // Title
        PixelFont.drawCentered(g, "DEPARTMENT", W / 2, 8, 1, Palette.TEXT_GOLD, Palette.TEXT_DARK);
        String title = "TOWER CLASH";
        int tx = (W - PixelFont.width(title, 2)) / 2;
        PixelFont.draw(g, title, tx + 2, 21, 2, new Color(0, 0, 0, 90)); // drop shadow
        PixelFont.drawOutlined(g, title, tx, 19, 2, Palette.TEXT_WHITE, Palette.TEXT_DARK);

        // Bottom line: progress if there is a save, otherwise the controls
        Color faint = Palette.lighter(Palette.BEDROCK, 0.45f);
        if (window.hasSavedGame()) {
            PlayerProgress p = window.getProgress();
            String info = "STARS " + p.getTotalStars() + "/" + Stage.ALL.size() * 3
                    + "    COINS " + p.getCoins() + "    WINS " + p.getWins();
            PixelFont.drawCentered(g, info, W / 2, 170, 1, faint, null);
        } else {
            PixelFont.drawCentered(g, "MOUSE OR ARROW KEYS + ENTER", W / 2, 170, 1, faint, null);
        }
    }
}
