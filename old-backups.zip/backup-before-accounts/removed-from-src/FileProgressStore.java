package db;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import model.Department;
import model.PlayerProgress;
import model.Stage;
import model.UnitType;

/**
 * Saves progress in a simple text file:
 *   C:\Users\<you>\.department-tower-clash\save.properties
 * If saving fails, the game keeps running (progress just is not remembered).
 */
public class FileProgressStore implements ProgressStore {

    private final Path file;

    public FileProgressStore() {
        this(Paths.get(System.getProperty("user.home"), ".department-tower-clash", "save.properties"));
    }

    public FileProgressStore(Path file) {
        this.file = file;
    }

    @Override
    public boolean exists() {
        return Files.exists(file);
    }

    @Override
    public PlayerProgress load() {
        PlayerProgress progress = new PlayerProgress();
        if (!exists()) {
            return progress;
        }
        Properties props = new Properties();
        try (Reader reader = Files.newBufferedReader(file)) {
            props.load(reader);
        } catch (IOException e) {
            System.err.println("Could not read save file: " + e.getMessage());
            return progress;
        }
        progress.setCoins(read(props, "coins", 0));
        progress.setUnlockedStage(read(props, "unlockedStage", 1));
        progress.setMatchesPlayed(read(props, "matchesPlayed", 0));
        progress.setWins(read(props, "wins", 0));
        progress.setLosses(read(props, "losses", 0));
        progress.setHighScore(read(props, "highScore", 0));
        progress.setBestWinSeconds(read(props, "bestWinSeconds", 0));
        for (Department d : Department.values()) {
            progress.setTowerLevel(d, read(props, "towerLevel." + d.name(), 1));
        }
        for (Stage s : Stage.ALL) {
            progress.setStars(s.number(), read(props, "stars." + s.number(), 0));
        }
        progress.setBestEndlessSeconds(read(props, "bestEndlessSeconds", 0));
        progress.setBestEndlessScore(read(props, "bestEndlessScore", 0));
        for (Department d : Department.values()) {
            // e.g. lineup.EDUCATION=Student,Librarian,Principal (old save files have none: default lineup)
            String text = props.getProperty("lineup." + d.name());
            if (text != null) {
                List<UnitType> lineup = new ArrayList<>();
                for (String name : text.split(",")) {
                    lineup.add(d.findUnit(name));
                }
                progress.setLineup(d, lineup); // ignored if the saved text is broken
            }
        }
        return progress;
    }

    @Override
    public void save(PlayerProgress progress) {
        Properties props = new Properties();
        props.setProperty("coins", String.valueOf(progress.getCoins()));
        props.setProperty("unlockedStage", String.valueOf(progress.getUnlockedStage()));
        props.setProperty("matchesPlayed", String.valueOf(progress.getMatchesPlayed()));
        props.setProperty("wins", String.valueOf(progress.getWins()));
        props.setProperty("losses", String.valueOf(progress.getLosses()));
        props.setProperty("highScore", String.valueOf(progress.getHighScore()));
        props.setProperty("bestWinSeconds", String.valueOf(progress.getBestWinSeconds()));
        for (Department d : Department.values()) {
            props.setProperty("towerLevel." + d.name(), String.valueOf(progress.getTowerLevel(d)));
        }
        for (Stage s : Stage.ALL) {
            props.setProperty("stars." + s.number(), String.valueOf(progress.getStars(s.number())));
        }
        props.setProperty("bestEndlessSeconds", String.valueOf(progress.getBestEndlessSeconds()));
        props.setProperty("bestEndlessScore", String.valueOf(progress.getBestEndlessScore()));
        for (Department d : Department.values()) {
            List<String> names = new ArrayList<>();
            for (UnitType type : progress.getLineup(d)) {
                names.add(type.name());
            }
            props.setProperty("lineup." + d.name(), String.join(",", names));
        }
        try {
            Files.createDirectories(file.getParent());
            try (Writer writer = Files.newBufferedWriter(file)) {
                props.store(writer, "Department Tower Clash - save file");
            }
        } catch (IOException e) {
            System.err.println("Could not save progress: " + e.getMessage());
        }
    }

    @Override
    public void delete() {
        try {
            Files.deleteIfExists(file);
        } catch (IOException e) {
            System.err.println("Could not delete save file: " + e.getMessage());
        }
    }

    private static int read(Properties props, String key, int fallback) {
        try {
            return Integer.parseInt(props.getProperty(key, String.valueOf(fallback)).trim());
        } catch (NumberFormatException e) {
            return fallback;
        }
    }
}
