package db;

import model.PlayerProgress;

/**
 * Where the player's progress is saved.
 * Right now: FileProgressStore (a small file on this computer).
 * Later: a MySqlProgressStore can implement this same interface, and the game will not need other changes.
 */
public interface ProgressStore {

    boolean exists();

    PlayerProgress load();

    void save(PlayerProgress progress);

    void delete();
}
