package ui.pixel;

import java.awt.Color;
import java.awt.Graphics2D;
import java.util.HashMap;
import java.util.Map;

/**
 * Our own 5x7 pixel font, so the game needs no font files.
 * Each letter is 7 rows of 5 bits: 1 = draw a pixel, 0 = empty.
 * Only capital letters are defined; lowercase text is shown in capitals.
 */
public final class PixelFont {

    public static final int GLYPH_W = 5;
    public static final int GLYPH_H = 7;
    private static final int SPACING = 1;

    private static final Map<Character, int[]> GLYPHS = new HashMap<>();

    static {
        glyph('A', "01110 10001 10001 11111 10001 10001 10001");
        glyph('B', "11110 10001 10001 11110 10001 10001 11110");
        glyph('C', "01110 10001 10000 10000 10000 10001 01110");
        glyph('D', "11110 10001 10001 10001 10001 10001 11110");
        glyph('E', "11111 10000 10000 11110 10000 10000 11111");
        glyph('F', "11111 10000 10000 11110 10000 10000 10000");
        glyph('G', "01110 10001 10000 10111 10001 10001 01111");
        glyph('H', "10001 10001 10001 11111 10001 10001 10001");
        glyph('I', "01110 00100 00100 00100 00100 00100 01110");
        glyph('J', "00111 00010 00010 00010 00010 10010 01100");
        glyph('K', "10001 10010 10100 11000 10100 10010 10001");
        glyph('L', "10000 10000 10000 10000 10000 10000 11111");
        glyph('M', "10001 11011 10101 10101 10001 10001 10001");
        glyph('N', "10001 10001 11001 10101 10011 10001 10001");
        glyph('O', "01110 10001 10001 10001 10001 10001 01110");
        glyph('P', "11110 10001 10001 11110 10000 10000 10000");
        glyph('Q', "01110 10001 10001 10001 10101 10010 01101");
        glyph('R', "11110 10001 10001 11110 10100 10010 10001");
        glyph('S', "01111 10000 10000 01110 00001 00001 11110");
        glyph('T', "11111 00100 00100 00100 00100 00100 00100");
        glyph('U', "10001 10001 10001 10001 10001 10001 01110");
        glyph('V', "10001 10001 10001 10001 10001 01010 00100");
        glyph('W', "10001 10001 10001 10101 10101 10101 01010");
        glyph('X', "10001 10001 01010 00100 01010 10001 10001");
        glyph('Y', "10001 10001 10001 01010 00100 00100 00100");
        glyph('Z', "11111 00001 00010 00100 01000 10000 11111");
        glyph('0', "01110 10001 10011 10101 11001 10001 01110");
        glyph('1', "00100 01100 00100 00100 00100 00100 01110");
        glyph('2', "01110 10001 00001 00010 00100 01000 11111");
        glyph('3', "11111 00010 00100 00010 00001 10001 01110");
        glyph('4', "00010 00110 01010 10010 11111 00010 00010");
        glyph('5', "11111 10000 11110 00001 00001 10001 01110");
        glyph('6', "00110 01000 10000 11110 10001 10001 01110");
        glyph('7', "11111 00001 00010 00100 01000 01000 01000");
        glyph('8', "01110 10001 10001 01110 10001 10001 01110");
        glyph('9', "01110 10001 10001 01111 00001 00010 01100");
        glyph(' ', "00000 00000 00000 00000 00000 00000 00000");
        glyph('.', "00000 00000 00000 00000 00000 01100 01100");
        glyph(',', "00000 00000 00000 00000 01100 00100 01000");
        glyph('!', "00100 00100 00100 00100 00100 00000 00100");
        glyph('?', "01110 10001 00001 00010 00100 00000 00100");
        glyph('-', "00000 00000 00000 11111 00000 00000 00000");
        glyph('+', "00000 00100 00100 11111 00100 00100 00000");
        glyph(':', "00000 01100 01100 00000 01100 01100 00000");
        glyph('\'', "00100 00100 01000 00000 00000 00000 00000");
        glyph('/', "00001 00010 00010 00100 01000 01000 10000");
        glyph('(', "00010 00100 01000 01000 01000 00100 00010");
        glyph(')', "01000 00100 00010 00010 00010 00100 01000");
        glyph('>', "01000 00100 00010 00001 00010 00100 01000");
        glyph('<', "00010 00100 01000 10000 01000 00100 00010");
        glyph('&', "01100 10010 10100 01000 10101 10010 01101");
        glyph('%', "11000 11001 00010 00100 01000 10011 00011");
        glyph('|', "00100 00100 00100 00100 00100 00100 00100");
        glyph('*', "00100 00100 11111 01110 01110 11011 10001"); // star
    }

    private PixelFont() {
    }

    private static void glyph(char c, String rows) {
        String[] parts = rows.split(" ");
        int[] bits = new int[GLYPH_H];
        for (int i = 0; i < GLYPH_H; i++) {
            bits[i] = Integer.parseInt(parts[i], 2);
        }
        GLYPHS.put(c, bits);
    }

    /** Width of the text in pixels. */
    public static int width(String text, int scale) {
        if (text.isEmpty()) {
            return 0;
        }
        return (text.length() * (GLYPH_W + SPACING) - SPACING) * scale;
    }

    public static void draw(Graphics2D g, String text, int x, int y, int scale, Color color) {
        g.setColor(color);
        String upper = text.toUpperCase();
        for (int i = 0; i < upper.length(); i++) {
            int[] bits = GLYPHS.getOrDefault(upper.charAt(i), GLYPHS.get('?'));
            int gx = x + i * (GLYPH_W + SPACING) * scale;
            for (int row = 0; row < GLYPH_H; row++) {
                for (int col = 0; col < GLYPH_W; col++) {
                    if (((bits[row] >> (GLYPH_W - 1 - col)) & 1) == 1) {
                        g.fillRect(gx + col * scale, y + row * scale, scale, scale);
                    }
                }
            }
        }
    }

    /** Text with a 1-pixel border around every letter (easy to read on any background). */
    public static void drawOutlined(Graphics2D g, String text, int x, int y, int scale, Color fill, Color outline) {
        for (int dx = -1; dx <= 1; dx++) {
            for (int dy = -1; dy <= 1; dy++) {
                if (dx != 0 || dy != 0) {
                    draw(g, text, x + dx, y + dy, scale, outline);
                }
            }
        }
        draw(g, text, x, y, scale, fill);
    }

    /** Centers the text on centerX. Pass null as outline for plain text. */
    public static void drawCentered(Graphics2D g, String text, int centerX, int y, int scale,
                                    Color fill, Color outline) {
        int x = centerX - width(text, scale) / 2;
        if (outline == null) {
            draw(g, text, x, y, scale, fill);
        } else {
            drawOutlined(g, text, x, y, scale, fill, outline);
        }
    }
}
