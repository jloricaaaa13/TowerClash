-- =====================================================================
--  OPTIONAL demo data - run AFTER tower_battle_db.sql
--  Adds 3 demo players so the leaderboard is not empty while testing.
--  All demo passwords are:  demo1234
-- =====================================================================
USE tower_battle_db;

INSERT IGNORE INTO users (username, email, password_hash, salt) VALUES
    ('alex_hm',  'alex@demo.com',  '51c505cb9a2dd1c915906b1d207d916910ed461293594d941b25d9a0b289c2b1', 'c2FtcGxlU2FsdEFsZXgxMg=='),
    ('bea_educ', 'bea@demo.com',   '6aa524c3f40ff8e230a836f37d53916feffc85aaafec3251a951a4cd25c24f4c', 'c2FtcGxlU2FsdEJlYTM0NQ=='),
    ('carlo_cs', 'carlo@demo.com', '143b947fda1d0c3d0b0648ea76f2e17cd20e98f60dd492266c5ee356994d64a3', 'c2FtcGxlU2FsdENhcmxvNg==');

INSERT IGNORE INTO player_stats
    (user_id, matches_played, wins, losses, highest_score, highest_score_date,
     fastest_win_seconds, fastest_win_date, coins, unlocked_stage, last_played_at)
SELECT user_id, 14, 10, 4, 12850, NOW() - INTERVAL 3 DAY, 158, NOW() - INTERVAL 5 DAY, 640, 4, NOW() - INTERVAL 1 DAY
FROM users WHERE username = 'alex_hm'
UNION ALL
SELECT user_id, 9, 5, 4, 9400, NOW() - INTERVAL 2 DAY, 131, NOW() - INTERVAL 2 DAY, 380, 3, NOW() - INTERVAL 2 DAY
FROM users WHERE username = 'bea_educ'
UNION ALL
SELECT user_id, 20, 13, 7, 11200, NOW() - INTERVAL 6 DAY, 176, NOW() - INTERVAL 4 DAY, 910, 5, NOW()
FROM users WHERE username = 'carlo_cs';

INSERT IGNORE INTO tower_upgrades (user_id, tower_code)
SELECT u.user_id, t.tower_code
FROM users u CROSS JOIN towers t
WHERE u.username IN ('alex_hm', 'bea_educ', 'carlo_cs');

-- A few matches so "Most Used Tower" has data (run this file only ONCE, or these rows repeat)
INSERT INTO match_history (user_id, stage_number, player_tower, enemy_tower, result, score, duration_seconds, damage_dealt, units_defeated, tower_hp_left, coins_earned)
SELECT user_id, 3, 'HOSPITALITY', 'COMPSCI',   'WIN',  12850, 158, 5200, 34, 72, 100 FROM users WHERE username = 'alex_hm'
UNION ALL
SELECT user_id, 2, 'EDUCATION',   'HOSPITALITY','WIN',  9400, 131, 4100, 22, 65, 75  FROM users WHERE username = 'bea_educ'
UNION ALL
SELECT user_id, 4, 'COMPSCI',     'EDUCATION', 'LOSS', 3100, 240, 3900, 18,  0, 20  FROM users WHERE username = 'carlo_cs'
UNION ALL
SELECT user_id, 4, 'COMPSCI',     'HOSPITALITY','WIN', 11200, 176, 5600, 30, 58, 150 FROM users WHERE username = 'carlo_cs';
