-- =====================================================================
--  DEPARTMENT TOWER CLASH - Database Script
--  Run in phpMyAdmin (XAMPP):  open phpMyAdmin > SQL tab > paste > Go
--  Safe to run more than once (uses IF NOT EXISTS / INSERT IGNORE).
-- =====================================================================

CREATE DATABASE IF NOT EXISTS tower_battle_db
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

USE tower_battle_db;

-- ---------------------------------------------------------------------
-- 1. USERS  (account system)
--    Passwords are never stored in plain text: we store a SHA-256 hash
--    of (salt + password) and the random salt used for that user.
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS users (
    user_id        INT          NOT NULL AUTO_INCREMENT,
    username       VARCHAR(20)  NOT NULL,
    email          VARCHAR(100) NOT NULL,
    password_hash  CHAR(64)     NOT NULL COMMENT 'SHA-256 hash (hex)',
    salt           VARCHAR(44)  NOT NULL COMMENT 'random salt (Base64)',
    created_at     DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    last_login     DATETIME     NULL,
    PRIMARY KEY (user_id),
    UNIQUE KEY uq_users_username (username),
    UNIQUE KEY uq_users_email (email)
) ENGINE = InnoDB;

-- ---------------------------------------------------------------------
-- 2. TOWERS  (lookup table - add a row here to add a new department)
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS towers (
    tower_code   VARCHAR(20) NOT NULL,
    tower_name   VARCHAR(50) NOT NULL,
    department   VARCHAR(60) NOT NULL,
    short_name   VARCHAR(20) NOT NULL,
    color_hex    CHAR(7)     NOT NULL,
    PRIMARY KEY (tower_code)
) ENGINE = InnoDB;

INSERT IGNORE INTO towers (tower_code, tower_name, department, short_name, color_hex) VALUES
    ('HOSPITALITY', 'Grand Hotel Tower', 'Hospitality Management', 'Hospitality', '#DC2626'),
    ('EDUCATION',   'Academy Tower',     'Education',              'Education',   '#2563EB'),
    ('COMPSCI',     'Server Tower',      'Computer Science',       'Comp Sci',    '#EAB308');

-- ---------------------------------------------------------------------
-- 3. STAGES  (lookup table - add a row here to add a new stage)
--    ai_multiplier makes the enemy AI stronger each stage.
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS stages (
    stage_number   INT          NOT NULL,
    stage_name     VARCHAR(50)  NOT NULL,
    description    VARCHAR(150) NOT NULL,
    difficulty     TINYINT      NOT NULL COMMENT '1 (easy) to 5 (hard)',
    ai_multiplier  DECIMAL(4,2) NOT NULL DEFAULT 1.00,
    reward_coins   INT          NOT NULL DEFAULT 50,
    PRIMARY KEY (stage_number)
) ENGINE = InnoDB;

INSERT IGNORE INTO stages (stage_number, stage_name, description, difficulty, ai_multiplier, reward_coins) VALUES
    (1, 'Freshman Rush',    'A slow enemy that is still learning the ropes.',        1, 1.00,  50),
    (2, 'Sophomore Siege',  'The enemy spawns units faster.',                        2, 1.20,  75),
    (3, 'Junior Clash',     'The enemy starts upgrading its tower.',                 3, 1.45, 100),
    (4, 'Senior Showdown',  'A smart enemy that saves energy for big pushes.',       4, 1.75, 150),
    (5, 'Dean''s Gauntlet', 'The ultimate test. The enemy uses every trick it has.', 5, 2.10, 250);

-- ---------------------------------------------------------------------
-- 4. PLAYER_STATS  (one row per user, updated after every match)
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS player_stats (
    user_id              INT      NOT NULL,
    matches_played       INT      NOT NULL DEFAULT 0,
    wins                 INT      NOT NULL DEFAULT 0,
    losses               INT      NOT NULL DEFAULT 0,
    highest_score        INT      NOT NULL DEFAULT 0,
    highest_score_date   DATETIME NULL,
    fastest_win_seconds  INT      NULL,
    fastest_win_date     DATETIME NULL,
    coins                INT      NOT NULL DEFAULT 100,
    unlocked_stage       INT      NOT NULL DEFAULT 1,
    last_played_at       DATETIME NULL,
    PRIMARY KEY (user_id),
    CONSTRAINT fk_stats_user FOREIGN KEY (user_id)
        REFERENCES users (user_id) ON DELETE CASCADE
) ENGINE = InnoDB;

-- ---------------------------------------------------------------------
-- 5. TOWER_UPGRADES  (permanent upgrades, Level 1 to 3, per user per tower)
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS tower_upgrades (
    user_id     INT         NOT NULL,
    tower_code  VARCHAR(20) NOT NULL,
    level       TINYINT     NOT NULL DEFAULT 1,
    updated_at  DATETIME    NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (user_id, tower_code),
    CONSTRAINT chk_upgrade_level CHECK (level BETWEEN 1 AND 3),
    CONSTRAINT fk_upgrade_user  FOREIGN KEY (user_id)
        REFERENCES users (user_id) ON DELETE CASCADE,
    CONSTRAINT fk_upgrade_tower FOREIGN KEY (tower_code)
        REFERENCES towers (tower_code)
) ENGINE = InnoDB;

-- ---------------------------------------------------------------------
-- 6. MATCH_HISTORY  (one row per finished match)
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS match_history (
    match_id          INT         NOT NULL AUTO_INCREMENT,
    user_id           INT         NOT NULL,
    stage_number      INT         NOT NULL,
    player_tower      VARCHAR(20) NOT NULL,
    enemy_tower       VARCHAR(20) NOT NULL,
    result            ENUM('WIN', 'LOSS') NOT NULL,
    score             INT         NOT NULL DEFAULT 0,
    duration_seconds  INT         NOT NULL DEFAULT 0,
    damage_dealt      INT         NOT NULL DEFAULT 0,
    units_defeated    INT         NOT NULL DEFAULT 0,
    tower_hp_left     INT         NOT NULL DEFAULT 0 COMMENT 'percent 0-100',
    coins_earned      INT         NOT NULL DEFAULT 0,
    played_at         DATETIME    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (match_id),
    KEY idx_match_user (user_id, played_at),
    CONSTRAINT fk_match_user   FOREIGN KEY (user_id)
        REFERENCES users (user_id) ON DELETE CASCADE,
    CONSTRAINT fk_match_ptower FOREIGN KEY (player_tower)
        REFERENCES towers (tower_code),
    CONSTRAINT fk_match_etower FOREIGN KEY (enemy_tower)
        REFERENCES towers (tower_code),
    CONSTRAINT fk_match_stage  FOREIGN KEY (stage_number)
        REFERENCES stages (stage_number)
) ENGINE = InnoDB;
