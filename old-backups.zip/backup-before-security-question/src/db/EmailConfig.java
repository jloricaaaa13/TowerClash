package db;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Properties;

/**
 * The Gmail account that SENDS the password reset codes to the players.
 *
 * ONE-TIME SETUP (done once by the group, players never see this):
 *   1. Make a Gmail for the group, e.g. group8.towerclash@gmail.com
 *   2. Google Account > Security > turn on 2-Step Verification
 *   3. Google Account > search "App passwords" > create one > copy the 16 letters
 *   4. Put the Gmail address and those 16 letters in SENDER_ADDRESS and SENDER_APP_PASSWORD below.
 * (Gmail does not accept the normal password from programs - only an App Password.)
 *
 * Anyone who has this source code can read the app password, so use a Gmail made only for
 * this game, never a personal one.
 */
public class EmailConfig {

    // ======== FILL THESE IN (one time) ========
    public static final String SENDER_ADDRESS = "";       // e.g. "group8.towerclash@gmail.com"
    public static final String SENDER_APP_PASSWORD = "";  // e.g. "abcd efgh ijkl mnop"
    // ===========================================

    public static final String GMAIL_HOST = "smtp.gmail.com";
    public static final int SSL_PORT = 465;

    private static final Path FILE = Paths.get(System.getProperty("user.home"), ".department-tower-clash",
            "email.properties");

    private String host = GMAIL_HOST;
    private int port = SSL_PORT;
    private String address = SENDER_ADDRESS.trim();
    private String appPassword = SENDER_APP_PASSWORD.replace(" ", "");

    /**
     * The sender written above. (An optional file email.properties in the
     * .department-tower-clash folder can override it, e.g. for testing - normally there is none.)
     */
    public static EmailConfig load() {
        EmailConfig config = new EmailConfig();
        if (!Files.exists(FILE)) {
            return config;
        }
        Properties props = new Properties();
        try (Reader r = Files.newBufferedReader(FILE)) {
            props.load(r);
            config.host = props.getProperty("smtpHost", GMAIL_HOST).trim();
            config.port = Integer.parseInt(props.getProperty("smtpPort", String.valueOf(SSL_PORT)).trim());
            config.address = props.getProperty("address", config.address).trim();
            config.appPassword = props.getProperty("appPassword", config.appPassword).replace(" ", "");
        } catch (IOException | NumberFormatException e) {
            return new EmailConfig();
        }
        return config;
    }

    public void save() throws IOException {
        Properties props = new Properties();
        props.setProperty("smtpHost", host);
        props.setProperty("smtpPort", String.valueOf(port));
        props.setProperty("address", address);
        props.setProperty("appPassword", appPassword);
        Files.createDirectories(FILE.getParent());
        try (Writer w = Files.newBufferedWriter(FILE)) {
            props.store(w, "Department Tower Clash - the email account that sends password reset codes");
        }
    }

    /** true when an address and an app password are filled in. */
    public boolean isReady() {
        return !address.isBlank() && !appPassword.isBlank();
    }

    public String getHost() {
        return host;
    }

    public int getPort() {
        return port;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address == null ? "" : address.trim();
    }

    public String getAppPassword() {
        return appPassword;
    }

    /** Spaces are removed: Gmail shows app passwords in groups of 4 letters. */
    public void setAppPassword(String appPassword) {
        this.appPassword = appPassword == null ? "" : appPassword.replace(" ", "");
    }
}
