package db;

/**
 * A password reset code that was emailed to a player.
 * Only the HASH of the 6-digit code is kept (like a password), never the code itself.
 *
 * @param createdAt and expiresAt are in milliseconds (System.currentTimeMillis())
 * @param attempts  how many wrong codes were typed so far
 */
public record ResetCode(String codeHash, String salt, long createdAt, long expiresAt, int attempts) {
}
