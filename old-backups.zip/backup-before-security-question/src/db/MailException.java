package db;

/** Sending an email failed. The message is short and easy to understand for the player. */
public class MailException extends Exception {

    public MailException(String message) {
        super(message);
    }

    public MailException(String message, Throwable cause) {
        super(message, cause);
    }
}
