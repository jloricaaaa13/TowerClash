package db;

import java.security.SecureRandom;

/**
 * FORGOT PASSWORD with a code sent by email:
 *   1. The player types their username or email.  -> sendCode()
 *      A random 6-digit code is made, its hash is saved, and the code is emailed to the
 *      address of that account.
 *   2. The player types the code and a new password. -> resetPassword()
 *      The code must match, be less than 10 minutes old, and have fewer than 5 wrong tries.
 *      Then the password is replaced and the code is deleted (it works only once).
 */
public final class PasswordReset {

    public static final int CODE_MINUTES = 10;
    public static final int MAX_ATTEMPTS = 5;
    public static final int RESEND_SECONDS = 60;

    private static final SecureRandom RANDOM = new SecureRandom();

    private PasswordReset() {
    }

    /**
     * Makes a code, saves its hash and emails it. Slow (sends an email): call from a background thread.
     * @return the account the code was sent for
     */
    public static Account sendCode(AccountStore store, EmailConfig email, String usernameOrEmail)
            throws AccountException, MailException {
        if (!email.isReady()) {
            throw new MailException("RESET EMAILS ARE NOT SET UP YET (SEE EMAILCONFIG.JAVA)");
        }
        Account account = find(store, usernameOrEmail);
        ResetCode old = store.loadResetCode(account);
        long now = System.currentTimeMillis();
        if (old != null) {
            long wait = RESEND_SECONDS - (now - old.createdAt()) / 1000;
            if (wait > 0) {
                throw new AccountException("PLEASE WAIT " + wait + " SECONDS BEFORE ASKING AGAIN");
            }
        }
        String code = String.format("%06d", RANDOM.nextInt(1_000_000));
        String salt = PasswordUtil.generateSalt();
        store.saveResetCode(account, new ResetCode(PasswordUtil.hashPassword(code, salt), salt,
                now, now + CODE_MINUTES * 60_000L, 0));
        try {
            new Mailer(email).send(account.email(), "Your Department Tower Clash reset code: " + code,
                    emailText(account.username(), code));
        } catch (MailException e) {
            store.clearResetCode(account); // nobody received it, so it must not stay valid
            throw e;
        }
        return account;
    }

    /** Checks the code and saves the new password (the new password is checked by the screen first). */
    public static void resetPassword(AccountStore store, String usernameOrEmail, String code, String newPassword)
            throws AccountException {
        Account account = find(store, usernameOrEmail);
        ResetCode saved = store.loadResetCode(account);
        if (saved == null) {
            throw new AccountException("NO CODE WAS SENT. PRESS SEND CODE FIRST");
        }
        if (System.currentTimeMillis() > saved.expiresAt()) {
            store.clearResetCode(account);
            throw new AccountException("THE CODE HAS EXPIRED. SEND A NEW ONE");
        }
        if (saved.attempts() >= MAX_ATTEMPTS) {
            store.clearResetCode(account);
            throw new AccountException("TOO MANY WRONG CODES. SEND A NEW ONE");
        }
        if (!PasswordUtil.verifyPassword(code.trim(), saved.salt(), saved.codeHash())) {
            store.addResetAttempt(account);
            int left = MAX_ATTEMPTS - saved.attempts() - 1;
            if (left <= 0) {
                store.clearResetCode(account);
                throw new AccountException("TOO MANY WRONG CODES. SEND A NEW ONE");
            }
            throw new AccountException("WRONG CODE (" + left + (left == 1 ? " TRY" : " TRIES") + " LEFT)");
        }
        store.setPassword(account, newPassword);
        store.clearResetCode(account);
    }

    private static Account find(AccountStore store, String usernameOrEmail) throws AccountException {
        String key = usernameOrEmail == null ? "" : usernameOrEmail.trim();
        if (key.isEmpty()) {
            throw new AccountException("ENTER YOUR USERNAME OR EMAIL");
        }
        Account account = store.findAccount(key);
        if (account == null) {
            throw new AccountException("NO ACCOUNT WITH THAT USERNAME OR EMAIL");
        }
        return account;
    }

    /** "juan.dc@gmail.com" -> "j*****c@gmail.com", so the screen does not show the whole address. */
    public static String maskEmail(String email) {
        int at = email.indexOf('@');
        if (at <= 1) {
            return email;
        }
        String name = email.substring(0, at);
        String stars = "*".repeat(Math.max(1, Math.min(5, name.length() - 2)));
        return name.charAt(0) + stars + (name.length() > 2 ? name.charAt(name.length() - 1) : "") + email.substring(at);
    }

    private static String emailText(String username, String code) {
        return "Hi " + username + ",\n\n"
                + "Someone asked to reset the password of your Department Tower Clash account.\n\n"
                + "Your reset code is:\n\n"
                + "    " + code + "\n\n"
                + "Type it in the game within " + CODE_MINUTES + " minutes. The code works only once.\n\n"
                + "If you did not ask for this, you can ignore this email. Your password stays the same.\n\n"
                + "- Department Tower Clash";
    }
}
