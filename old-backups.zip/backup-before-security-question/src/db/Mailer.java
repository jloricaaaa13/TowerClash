package db;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.ConnectException;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.net.UnknownHostException;
import java.nio.charset.StandardCharsets;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Base64;
import java.util.UUID;
import javax.net.ssl.SSLException;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;

/**
 * Sends one plain-text email through an SMTP server (Gmail by default) - no extra library needed.
 *
 * SMTP is a simple text conversation. The game says a command, the server answers with a number:
 *   (connect)                  server: 220 ready
 *   EHLO towerclash            server: 250 hello
 *   AUTH LOGIN + user + pass   server: 235 logged in        (sent in Base64, inside SSL encryption)
 *   MAIL FROM:<sender>         server: 250 ok
 *   RCPT TO:<player>           server: 250 ok
 *   DATA                       server: 354 send the email
 *   (headers, text, ".")       server: 250 queued
 *   QUIT                       server: 221 bye
 *
 * Port 465 is encrypted from the start (SSL). Any other port (e.g. 587) starts plain and switches
 * on encryption with STARTTLS before logging in, so the password is never sent unencrypted.
 */
public final class Mailer {

    private static final int TIMEOUT_MS = 15000;

    private final EmailConfig config;
    private Socket socket;
    private BufferedReader in;
    private OutputStream out;

    public Mailer(EmailConfig config) {
        this.config = config;
    }

    /**
     * Sends the email. Takes a few seconds, so call it from a background thread, not the screen.
     * @throws MailException with a short reason the player can understand
     */
    public void send(String to, String subject, String body) throws MailException {
        if (!config.isReady()) {
            throw new MailException("RESET EMAILS ARE NOT SET UP YET (SEE EMAILCONFIG.JAVA)");
        }
        try {
            open();
            expect(220);
            command("EHLO towerclash", 250);
            if (!(socket instanceof SSLSocket)) {
                command("STARTTLS", 220);
                socket = ((SSLSocketFactory) SSLSocketFactory.getDefault())
                        .createSocket(socket, config.getHost(), config.getPort(), true);
                streams();
                command("EHLO towerclash", 250);
            }
            command("AUTH LOGIN", 334);
            command(base64(config.getAddress()), 334);
            int answer = commandCode(base64(config.getAppPassword()));
            if (answer != 235) {
                throw new MailException("GMAIL REJECTED THE LOGIN (USE A GMAIL APP PASSWORD)");
            }
            command("MAIL FROM:<" + config.getAddress() + ">", 250);
            int rcpt = commandCode("RCPT TO:<" + to + ">");
            if (rcpt != 250 && rcpt != 251) {
                throw new MailException("THE EMAIL ADDRESS " + to.toUpperCase() + " WAS REJECTED");
            }
            command("DATA", 354);
            write(message(to, subject, body));
            expect(250);
            commandCode("QUIT");
        } catch (UnknownHostException | ConnectException e) {
            throw new MailException("CANNOT REACH THE EMAIL SERVER (CHECK THE INTERNET)", e);
        } catch (SocketTimeoutException e) {
            throw new MailException("THE EMAIL SERVER DID NOT ANSWER (TRY AGAIN)", e);
        } catch (SSLException e) {
            throw new MailException("SECURE CONNECTION TO THE EMAIL SERVER FAILED", e);
        } catch (IOException e) {
            throw new MailException("EMAIL COULD NOT BE SENT (CHECK THE INTERNET)", e);
        } finally {
            close();
        }
    }

    private void open() throws IOException {
        if (config.getPort() == EmailConfig.SSL_PORT) {
            socket = SSLSocketFactory.getDefault().createSocket();
        } else {
            socket = new Socket();
        }
        socket.connect(new InetSocketAddress(config.getHost(), config.getPort()), TIMEOUT_MS);
        streams();
    }

    private void streams() throws IOException {
        socket.setSoTimeout(TIMEOUT_MS);
        in = new BufferedReader(new InputStreamReader(socket.getInputStream(), StandardCharsets.UTF_8));
        out = socket.getOutputStream();
    }

    private void close() {
        try {
            if (socket != null) {
                socket.close();
            }
        } catch (IOException e) {
            // already closed
        }
    }

    /** The headers + text of the email. Lines starting with "." get an extra "." (SMTP rule). */
    private String message(String to, String subject, String body) {
        StringBuilder m = new StringBuilder();
        m.append("From: Department Tower Clash <").append(config.getAddress()).append(">\r\n");
        m.append("To: <").append(to).append(">\r\n");
        m.append("Subject: ").append(subject).append("\r\n");
        m.append("Date: ").append(ZonedDateTime.now().format(DateTimeFormatter.RFC_1123_DATE_TIME)).append("\r\n");
        String domain = config.getAddress().substring(config.getAddress().indexOf('@') + 1);
        m.append("Message-ID: <").append(UUID.randomUUID()).append('@').append(domain).append(">\r\n");
        m.append("MIME-Version: 1.0\r\n");
        m.append("Content-Type: text/plain; charset=UTF-8\r\n");
        m.append("Content-Transfer-Encoding: 8bit\r\n\r\n");
        for (String line : body.split("\r?\n", -1)) {
            m.append(line.startsWith(".") ? "." + line : line).append("\r\n");
        }
        m.append(".\r\n");
        return m.toString();
    }

    private void command(String line, int wanted) throws IOException, MailException {
        int code = commandCode(line);
        if (code != wanted) {
            throw new MailException("THE EMAIL SERVER SAID NO (" + code + ")");
        }
    }

    private int commandCode(String line) throws IOException {
        write(line + "\r\n");
        return readCode();
    }

    private void expect(int wanted) throws IOException, MailException {
        int code = readCode();
        if (code != wanted) {
            throw new MailException("THE EMAIL SERVER SAID NO (" + code + ")");
        }
    }

    private void write(String text) throws IOException {
        out.write(text.getBytes(StandardCharsets.UTF_8));
        out.flush();
    }

    /** Reads an answer like "250-first line" ... "250 last line" and returns 250. */
    private int readCode() throws IOException {
        String line;
        do {
            line = in.readLine();
            if (line == null) {
                throw new IOException("The email server closed the connection");
            }
        } while (line.length() > 3 && line.charAt(3) == '-');
        try {
            return Integer.parseInt(line.substring(0, 3));
        } catch (RuntimeException e) {
            throw new IOException("Unexpected answer: " + line);
        }
    }

    private static String base64(String text) {
        return Base64.getEncoder().encodeToString(text.getBytes(StandardCharsets.UTF_8));
    }
}
