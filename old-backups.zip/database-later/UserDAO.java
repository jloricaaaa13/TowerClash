package db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import model.User;
import util.PasswordUtil;

/**
 * DAO = Data Access Object. All SQL for the users table lives here,
 * so the UI classes never write SQL themselves.
 * Every query uses PreparedStatement (the ? placeholders) to prevent SQL injection.
 */
public class UserDAO {

    public boolean usernameExists(String username) throws SQLException {
        return exists("SELECT 1 FROM users WHERE username = ?", username);
    }

    public boolean emailExists(String email) throws SQLException {
        return exists("SELECT 1 FROM users WHERE email = ?", email);
    }

    private boolean exists(String sql, String value) throws SQLException {
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, value);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next();
            }
        }
    }

    /**
     * Creates a new account plus its starting stats and tower upgrade rows.
     * Uses a transaction: either ALL three inserts succeed, or none of them are saved.
     */
    public User register(String username, String email, String password) throws SQLException {
        String salt = PasswordUtil.generateSalt();
        String hash = PasswordUtil.hashPassword(password, salt);

        String insertUser = "INSERT INTO users (username, email, password_hash, salt) VALUES (?, ?, ?, ?)";
        String insertStats = "INSERT INTO player_stats (user_id) VALUES (?)";
        String insertUpgrades = "INSERT INTO tower_upgrades (user_id, tower_code) "
                + "SELECT ?, tower_code FROM towers";

        try (Connection con = DBConnection.getConnection()) {
            con.setAutoCommit(false);
            try {
                int userId;
                try (PreparedStatement ps = con.prepareStatement(insertUser, Statement.RETURN_GENERATED_KEYS)) {
                    ps.setString(1, username);
                    ps.setString(2, email);
                    ps.setString(3, hash);
                    ps.setString(4, salt);
                    ps.executeUpdate();
                    try (ResultSet keys = ps.getGeneratedKeys()) {
                        keys.next();
                        userId = keys.getInt(1);
                    }
                }
                try (PreparedStatement ps = con.prepareStatement(insertStats)) {
                    ps.setInt(1, userId);
                    ps.executeUpdate();
                }
                try (PreparedStatement ps = con.prepareStatement(insertUpgrades)) {
                    ps.setInt(1, userId);
                    ps.executeUpdate();
                }
                con.commit();
                return new User(userId, username, email, LocalDateTime.now());
            } catch (SQLException e) {
                con.rollback();
                throw e;
            }
        }
    }

    /**
     * Checks the login. The player can type either their username or their email.
     * Returns the User if the password is correct, or null if not.
     */
    public User login(String usernameOrEmail, String password) throws SQLException {
        String sql = "SELECT user_id, username, email, password_hash, salt, created_at "
                + "FROM users WHERE username = ? OR email = ?";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, usernameOrEmail);
            ps.setString(2, usernameOrEmail);

            try (ResultSet rs = ps.executeQuery()) {
                if (!rs.next()) {
                    return null; // no such user
                }
                String storedHash = rs.getString("password_hash");
                String salt = rs.getString("salt");
                if (!PasswordUtil.verifyPassword(password, salt, storedHash)) {
                    return null; // wrong password
                }
                User user = mapUser(rs);
                updateLastLogin(con, user.getUserId());
                return user;
            }
        }
    }

    /** Returns true if the password was changed, false if the current password is wrong. */
    public boolean changePassword(int userId, String currentPassword, String newPassword) throws SQLException {
        String select = "SELECT password_hash, salt FROM users WHERE user_id = ?";
        String update = "UPDATE users SET password_hash = ?, salt = ? WHERE user_id = ?";

        try (Connection con = DBConnection.getConnection()) {
            try (PreparedStatement ps = con.prepareStatement(select)) {
                ps.setInt(1, userId);
                try (ResultSet rs = ps.executeQuery()) {
                    if (!rs.next() || !PasswordUtil.verifyPassword(
                            currentPassword, rs.getString("salt"), rs.getString("password_hash"))) {
                        return false;
                    }
                }
            }
            String newSalt = PasswordUtil.generateSalt();
            try (PreparedStatement ps = con.prepareStatement(update)) {
                ps.setString(1, PasswordUtil.hashPassword(newPassword, newSalt));
                ps.setString(2, newSalt);
                ps.setInt(3, userId);
                ps.executeUpdate();
            }
            return true;
        }
    }

    private void updateLastLogin(Connection con, int userId) throws SQLException {
        try (PreparedStatement ps = con.prepareStatement("UPDATE users SET last_login = NOW() WHERE user_id = ?")) {
            ps.setInt(1, userId);
            ps.executeUpdate();
        }
    }

    private User mapUser(ResultSet rs) throws SQLException {
        Timestamp created = rs.getTimestamp("created_at");
        return new User(
                rs.getInt("user_id"),
                rs.getString("username"),
                rs.getString("email"),
                created == null ? null : created.toLocalDateTime());
    }
}
