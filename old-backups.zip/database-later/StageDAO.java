package db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import model.Stage;

/** Loads the stage list. To add a stage, just insert a row into the stages table. */
public class StageDAO {

    public List<Stage> getAllStages() throws SQLException {
        String sql = "SELECT stage_number, stage_name, description, difficulty, ai_multiplier, reward_coins "
                + "FROM stages ORDER BY stage_number";

        List<Stage> stages = new ArrayList<>();
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                stages.add(new Stage(
                        rs.getInt("stage_number"),
                        rs.getString("stage_name"),
                        rs.getString("description"),
                        rs.getInt("difficulty"),
                        rs.getDouble("ai_multiplier"),
                        rs.getInt("reward_coins")));
            }
        }
        return stages;
    }
}
