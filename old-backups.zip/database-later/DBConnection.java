package db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * Opens connections to the XAMPP MySQL database.
 * Change the settings below if your MySQL uses a different port or password.
 */
public final class DBConnection {

    private static final String HOST = "localhost";
    private static final int PORT = 3306;                 // XAMPP default
    private static final String DATABASE = "tower_battle_db";
    private static final String USER = "root";            // XAMPP default
    private static final String PASSWORD = "";            // XAMPP default is empty

    private static final String URL = "jdbc:mysql://" + HOST + ":" + PORT + "/" + DATABASE
            + "?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=Asia/Manila";

    private static boolean driverLoaded;

    static {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            driverLoaded = true;
        } catch (ClassNotFoundException e) {
            driverLoaded = false;
        }
    }

    private DBConnection() {
    }

    /**
     * Returns a new connection. Always use it inside try-with-resources so it
     * is closed automatically:  try (Connection con = DBConnection.getConnection()) { ... }
     */
    public static Connection getConnection() throws SQLException {
        if (!driverLoaded) {
            throw new SQLException("MySQL JDBC driver not found. "
                    + "Add mysql-connector-j-x.x.x.jar to the project Libraries.");
        }
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }
}
