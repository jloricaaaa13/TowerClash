package db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import model.LeaderboardEntry;
import model.LeaderboardFilter;
import model.PlayerStats;

/** Reads player statistics and the leaderboard. */
public class StatsDAO {

    public PlayerStats getStats(int userId) throws SQLException {
        String sql = "SELECT matches_played, wins, losses, highest_score, fastest_win_seconds, "
                + "coins, unlocked_stage FROM player_stats WHERE user_id = ?";

        PlayerStats stats = new PlayerStats();
        try (Connection con = DBConnection.getConnection()) {
            try (PreparedStatement ps = con.prepareStatement(sql)) {
                ps.setInt(1, userId);
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) {
                        stats.setMatchesPlayed(rs.getInt("matches_played"));
                        stats.setWins(rs.getInt("wins"));
                        stats.setLosses(rs.getInt("losses"));
                        stats.setHighestScore(rs.getInt("highest_score"));
                        int fastest = rs.getInt("fastest_win_seconds");
                        stats.setFastestWinSeconds(rs.wasNull() ? null : fastest);
                        stats.setCoins(rs.getInt("coins"));
                        stats.setUnlockedStage(rs.getInt("unlocked_stage"));
                    }
                }
            }
            loadMostUsedTower(con, userId, stats);
        }
        return stats;
    }

    /** Finds the tower the player picked the most times in match_history. */
    private void loadMostUsedTower(Connection con, int userId, PlayerStats stats) throws SQLException {
        String sql = "SELECT t.short_name, t.color_hex, COUNT(*) AS times_used "
                + "FROM match_history m JOIN towers t ON t.tower_code = m.player_tower "
                + "WHERE m.user_id = ? "
                + "GROUP BY t.tower_code, t.short_name, t.color_hex "
                + "ORDER BY times_used DESC LIMIT 1";
        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, userId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    stats.setMostUsedTower(rs.getString("short_name"));
                    stats.setMostUsedTowerColor(rs.getString("color_hex"));
                }
            }
        }
    }

    /** Top players for the selected filter (e.g. limit = 10 for the Top 10). */
    public List<LeaderboardEntry> getLeaderboard(LeaderboardFilter filter, int limit) throws SQLException {
        List<LeaderboardEntry> entries = new ArrayList<>();
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(leaderboardSql(filter) + " LIMIT ?")) {
            ps.setInt(1, limit);
            try (ResultSet rs = ps.executeQuery()) {
                int rank = 1;
                while (rs.next()) {
                    int fastest = rs.getInt("fastest_win_seconds");
                    Integer fastestWin = rs.wasNull() ? null : fastest;
                    Timestamp achieved = rs.getTimestamp("achieved_at");
                    entries.add(new LeaderboardEntry(
                            rank++,
                            rs.getInt("user_id"),
                            rs.getString("username"),
                            rs.getInt("highest_score"),
                            rs.getInt("wins"),
                            fastestWin,
                            achieved == null ? null : achieved.toLocalDateTime()));
                }
            }
        }
        return entries;
    }

    /**
     * The player's rank for the selected filter, even if they are outside the Top 10.
     * Returns -1 if the player is not on the leaderboard yet.
     */
    public int getPlayerRank(int userId, LeaderboardFilter filter) throws SQLException {
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(leaderboardSql(filter));
             ResultSet rs = ps.executeQuery()) {
            int rank = 1;
            while (rs.next()) {
                if (rs.getInt("user_id") == userId) {
                    return rank;
                }
                rank++;
            }
        }
        return -1;
    }

    /**
     * Builds the leaderboard query. The same query is used for the Top 10 and
     * for finding the player's own rank, so both always agree.
     * (The filter values come from our own enum, never from user typing.)
     */
    private String leaderboardSql(LeaderboardFilter filter) {
        String dateColumn;
        String where;
        String orderBy;
        switch (filter) {
            case MOST_WINS -> {
                dateColumn = "s.last_played_at";
                where = "s.wins > 0";
                orderBy = "s.wins DESC, s.highest_score DESC, u.user_id ASC";
            }
            case FASTEST_WIN -> {
                dateColumn = "s.fastest_win_date";
                where = "s.fastest_win_seconds IS NOT NULL";
                orderBy = "s.fastest_win_seconds ASC, s.fastest_win_date ASC, u.user_id ASC";
            }
            default -> {
                dateColumn = "s.highest_score_date";
                where = "s.highest_score > 0";
                orderBy = "s.highest_score DESC, s.highest_score_date ASC, u.user_id ASC";
            }
        }
        return "SELECT u.user_id, u.username, s.highest_score, s.wins, s.fastest_win_seconds, "
                + dateColumn + " AS achieved_at "
                + "FROM player_stats s JOIN users u ON u.user_id = s.user_id "
                + "WHERE " + where + " ORDER BY " + orderBy;
    }
}
