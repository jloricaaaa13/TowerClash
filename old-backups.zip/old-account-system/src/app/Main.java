package app;

import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.plaf.metal.MetalLookAndFeel;
import ui.LoginFrame;
import ui.components.Theme;

/** Program entry point. Set this as the Main Class in NetBeans. */
public class Main {

    public static void main(String[] args) {
        try {
            // Metal lets us fully control colors; Theme then applies our dark palette
            UIManager.setLookAndFeel(new MetalLookAndFeel());
        } catch (Exception e) {
            e.printStackTrace();
        }
        Theme.installDefaults();

        // Swing screens must be created on the Event Dispatch Thread
        SwingUtilities.invokeLater(() -> new LoginFrame().setVisible(true));
    }
}
