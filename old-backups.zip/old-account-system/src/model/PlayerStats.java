package model;

/** A player's overall progress, loaded from the player_stats table. */
public class PlayerStats {

    private int matchesPlayed;
    private int wins;
    private int losses;
    private int highestScore;
    private Integer fastestWinSeconds;   // null = the player has not won yet
    private int coins;
    private int unlockedStage = 1;
    private String mostUsedTower;        // e.g. "Hospitality", null = no matches yet
    private String mostUsedTowerColor;   // e.g. "#DC2626"

    public int getMatchesPlayed() {
        return matchesPlayed;
    }

    public void setMatchesPlayed(int matchesPlayed) {
        this.matchesPlayed = matchesPlayed;
    }

    public int getWins() {
        return wins;
    }

    public void setWins(int wins) {
        this.wins = wins;
    }

    public int getLosses() {
        return losses;
    }

    public void setLosses(int losses) {
        this.losses = losses;
    }

    public int getHighestScore() {
        return highestScore;
    }

    public void setHighestScore(int highestScore) {
        this.highestScore = highestScore;
    }

    public Integer getFastestWinSeconds() {
        return fastestWinSeconds;
    }

    public void setFastestWinSeconds(Integer fastestWinSeconds) {
        this.fastestWinSeconds = fastestWinSeconds;
    }

    public int getCoins() {
        return coins;
    }

    public void setCoins(int coins) {
        this.coins = coins;
    }

    public int getUnlockedStage() {
        return unlockedStage;
    }

    public void setUnlockedStage(int unlockedStage) {
        this.unlockedStage = unlockedStage;
    }

    public String getMostUsedTower() {
        return mostUsedTower;
    }

    public void setMostUsedTower(String mostUsedTower) {
        this.mostUsedTower = mostUsedTower;
    }

    public String getMostUsedTowerColor() {
        return mostUsedTowerColor;
    }

    public void setMostUsedTowerColor(String mostUsedTowerColor) {
        this.mostUsedTowerColor = mostUsedTowerColor;
    }

    /** Win rate from 0.0 to 1.0 (computed, not stored in the database). */
    public double getWinRate() {
        return matchesPlayed == 0 ? 0.0 : (double) wins / matchesPlayed;
    }
}
