package model;

import java.time.LocalDateTime;

/**
 * A registered player account.
 * Encapsulation: fields are private and can only be read through getters.
 * The password hash is NOT kept in this object, so it never travels around the UI.
 */
public class User {

    private final int userId;
    private final String username;
    private final String email;
    private final LocalDateTime createdAt;

    public User(int userId, String username, String email, LocalDateTime createdAt) {
        this.userId = userId;
        this.username = username;
        this.email = email;
        this.createdAt = createdAt;
    }

    public int getUserId() {
        return userId;
    }

    public String getUsername() {
        return username;
    }

    public String getEmail() {
        return email;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    @Override
    public String toString() {
        return username;
    }
}
