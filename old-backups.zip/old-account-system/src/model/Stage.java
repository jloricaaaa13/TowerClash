package model;

/** One stage (level) of the campaign, loaded from the stages table. */
public class Stage {

    private final int number;
    private final String name;
    private final String description;
    private final int difficulty;        // 1 to 5
    private final double aiMultiplier;   // how much stronger the enemy AI is
    private final int rewardCoins;

    public Stage(int number, String name, String description,
                 int difficulty, double aiMultiplier, int rewardCoins) {
        this.number = number;
        this.name = name;
        this.description = description;
        this.difficulty = difficulty;
        this.aiMultiplier = aiMultiplier;
        this.rewardCoins = rewardCoins;
    }

    public int getNumber() {
        return number;
    }

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    public int getDifficulty() {
        return difficulty;
    }

    public double getAiMultiplier() {
        return aiMultiplier;
    }

    public int getRewardCoins() {
        return rewardCoins;
    }
}
