package model;

/** The choices in the leaderboard JComboBox. */
public enum LeaderboardFilter {

    OVERALL("Overall"),
    MOST_WINS("Most Wins"),
    FASTEST_WIN("Fastest Win");

    private final String label;

    LeaderboardFilter(String label) {
        this.label = label;
    }

    /** JComboBox calls toString() to show each item. */
    @Override
    public String toString() {
        return label;
    }
}
