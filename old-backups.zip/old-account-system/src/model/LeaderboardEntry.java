package model;

import java.time.LocalDateTime;

/** One row of the leaderboard table. */
public class LeaderboardEntry {

    private final int rank;
    private final int userId;
    private final String username;
    private final int score;
    private final int wins;
    private final Integer fastestWinSeconds;
    private final LocalDateTime achievedAt;

    public LeaderboardEntry(int rank, int userId, String username, int score, int wins,
                            Integer fastestWinSeconds, LocalDateTime achievedAt) {
        this.rank = rank;
        this.userId = userId;
        this.username = username;
        this.score = score;
        this.wins = wins;
        this.fastestWinSeconds = fastestWinSeconds;
        this.achievedAt = achievedAt;
    }

    public int getRank() {
        return rank;
    }

    public int getUserId() {
        return userId;
    }

    public String getUsername() {
        return username;
    }

    public int getScore() {
        return score;
    }

    public int getWins() {
        return wins;
    }

    public Integer getFastestWinSeconds() {
        return fastestWinSeconds;
    }

    public LocalDateTime getAchievedAt() {
        return achievedAt;
    }
}
