package util;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/** Small helpers for showing numbers, times, and dates on screen. */
public final class Format {

    private static final DateTimeFormatter DATE = DateTimeFormatter.ofPattern("MMM d, yyyy");

    private Format() {
    }

    /** 83 seconds -> "1:23". Returns "--" if there is no value yet. */
    public static String duration(Integer seconds) {
        if (seconds == null) {
            return "--";
        }
        return String.format("%d:%02d", seconds / 60, seconds % 60);
    }

    public static String date(LocalDateTime dateTime) {
        return dateTime == null ? "--" : dateTime.format(DATE);
    }

    /** 0.756 -> "75.6%" */
    public static String percent(double ratio) {
        return String.format("%.1f%%", ratio * 100);
    }

    /** 12500 -> "12,500" */
    public static String number(int value) {
        return String.format("%,d", value);
    }
}
