package util;

import model.User;

/**
 * Remembers who is currently logged in.
 * Any screen can call Session.isLoggedIn() to block users who did not log in.
 */
public final class Session {

    private static User currentUser;

    private Session() {
    }

    public static void login(User user) {
        currentUser = user;
    }

    public static void logout() {
        currentUser = null;
    }

    public static boolean isLoggedIn() {
        return currentUser != null;
    }

    public static User getCurrentUser() {
        return currentUser;
    }
}
