package util;

import java.util.regex.Pattern;

/**
 * Input validation rules for the account system.
 * Each validate method returns an error message, or null if the input is valid.
 */
public final class Validator {

    public static final int USERNAME_MIN = 3;
    public static final int USERNAME_MAX = 20;
    public static final int PASSWORD_MIN = 8;
    public static final int PASSWORD_MAX = 64;

    private static final Pattern USERNAME_PATTERN = Pattern.compile("^[A-Za-z0-9_]+$");
    private static final Pattern EMAIL_PATTERN =
            Pattern.compile("^[A-Za-z0-9._%+-]+@[A-Za-z0-9-]+(\\.[A-Za-z0-9-]+)*\\.[A-Za-z]{2,}$");

    private Validator() {
    }

    public static String validateUsername(String username) {
        if (username == null || username.isBlank()) {
            return "Username is required.";
        }
        if (username.length() < USERNAME_MIN || username.length() > USERNAME_MAX) {
            return "Username must be " + USERNAME_MIN + " to " + USERNAME_MAX + " characters long.";
        }
        if (!USERNAME_PATTERN.matcher(username).matches()) {
            return "Username can only contain letters, numbers, and underscores (_).";
        }
        return null;
    }

    public static String validateEmail(String email) {
        if (email == null || email.isBlank()) {
            return "Email is required.";
        }
        if (email.length() > 100 || !EMAIL_PATTERN.matcher(email).matches()) {
            return "Please enter a valid email address (example: juan@school.edu.ph).";
        }
        return null;
    }

    public static String validatePassword(String password) {
        if (password == null || password.isEmpty()) {
            return "Password is required.";
        }
        if (password.length() < PASSWORD_MIN || password.length() > PASSWORD_MAX) {
            return "Password must be " + PASSWORD_MIN + " to " + PASSWORD_MAX + " characters long.";
        }
        if (password.contains(" ")) {
            return "Password must not contain spaces.";
        }
        if (!password.matches(".*[A-Za-z].*") || !password.matches(".*[0-9].*")) {
            return "Password must contain at least one letter and one number.";
        }
        return null;
    }

    /** Returns 0 = too short, 1 = weak, 2 = medium, 3 = strong. */
    public static int passwordStrength(String password) {
        if (password == null || password.length() < PASSWORD_MIN) {
            return 0;
        }
        int score = 0;
        if (password.matches(".*[a-z].*")) score++;
        if (password.matches(".*[A-Z].*")) score++;
        if (password.matches(".*[0-9].*")) score++;
        if (password.matches(".*[^A-Za-z0-9].*")) score++;
        if (password.length() >= 12) score++;

        if (score >= 4) return 3;
        if (score >= 3) return 2;
        return 1;
    }
}
