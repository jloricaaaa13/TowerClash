package util;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.Base64;

/**
 * Hashes and verifies passwords using SHA-256 with a random salt.
 *
 * How it works:
 *   1. On register, a random 16-byte salt is generated for the user.
 *   2. hash = SHA-256(salt + password), saved as a 64-character hex string.
 *   3. On login, the same salt is read from the database and the typed
 *      password is hashed again. If both hashes match, the password is correct.
 *
 * The salt makes two users with the same password get different hashes.
 */
public final class PasswordUtil {

    private static final int SALT_LENGTH = 16;
    private static final SecureRandom RANDOM = new SecureRandom();

    private PasswordUtil() {
        // utility class - no objects needed
    }

    /** Creates a new random salt encoded in Base64 (24 characters). */
    public static String generateSalt() {
        byte[] salt = new byte[SALT_LENGTH];
        RANDOM.nextBytes(salt);
        return Base64.getEncoder().encodeToString(salt);
    }

    /** Returns SHA-256(salt + password) as a 64-character hex string. */
    public static String hashPassword(String password, String saltBase64) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            digest.update(Base64.getDecoder().decode(saltBase64));
            byte[] hash = digest.digest(password.getBytes(StandardCharsets.UTF_8));
            return toHex(hash);
        } catch (NoSuchAlgorithmException e) {
            // SHA-256 is built into every Java installation, so this should never happen
            throw new IllegalStateException("SHA-256 algorithm not available", e);
        }
    }

    /** Checks a typed password against the stored hash and salt. */
    public static boolean verifyPassword(String password, String saltBase64, String storedHash) {
        String typedHash = hashPassword(password, saltBase64);
        // MessageDigest.isEqual compares in constant time (safer than String.equals)
        return MessageDigest.isEqual(
                typedHash.getBytes(StandardCharsets.UTF_8),
                storedHash.getBytes(StandardCharsets.UTF_8));
    }

    private static String toHex(byte[] bytes) {
        StringBuilder sb = new StringBuilder(bytes.length * 2);
        for (byte b : bytes) {
            sb.append(String.format("%02x", b));
        }
        return sb.toString();
    }
}
