package util;

import java.awt.Component;
import javax.swing.JOptionPane;

/** Shortcut methods for JOptionPane message boxes. */
public final class Dialogs {

    private Dialogs() {
    }

    public static void showError(Component parent, String title, String message) {
        JOptionPane.showMessageDialog(parent, message, title, JOptionPane.ERROR_MESSAGE);
    }

    public static void showWarning(Component parent, String title, String message) {
        JOptionPane.showMessageDialog(parent, message, title, JOptionPane.WARNING_MESSAGE);
    }

    public static void showInfo(Component parent, String title, String message) {
        JOptionPane.showMessageDialog(parent, message, title, JOptionPane.INFORMATION_MESSAGE);
    }

    public static boolean confirm(Component parent, String title, String message) {
        int choice = JOptionPane.showConfirmDialog(parent, message, title,
                JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
        return choice == JOptionPane.YES_OPTION;
    }

    /** Used when loading or saving data fails (e.g. the database is not running). */
    public static void showDataError(Component parent, RuntimeException e) {
        JOptionPane.showMessageDialog(parent,
                "Something went wrong while loading or saving data.\n\nDetails: " + e.getMessage(),
                "Data Error", JOptionPane.ERROR_MESSAGE);
        e.printStackTrace();
    }
}
