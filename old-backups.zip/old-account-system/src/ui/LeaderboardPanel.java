package ui;

import db.DataException;
import db.Repositories;
import db.StatsRepository;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.util.ArrayList;
import java.util.List;
import javax.swing.BorderFactory;
import javax.swing.DefaultListCellRenderer;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import model.LeaderboardEntry;
import model.LeaderboardFilter;
import ui.components.RoundedButton;
import ui.components.RoundedPanel;
import ui.components.Theme;
import util.Dialogs;
import util.Format;

/**
 * Top 10 leaderboard in a JTable, with a filter JComboBox.
 * The logged-in player's row is highlighted, and their rank is shown below
 * the table even if they are outside the Top 10.
 */
public class LeaderboardPanel extends JPanel {

    private static final String[] COLUMNS = {"Rank", "Player", "Highest Score", "Wins", "Fastest Win", "Date"};
    private static final int TOP_N = 10;

    private final int currentUserId;
    private final StatsRepository statsRepo = Repositories.stats();
    private final JComboBox<LeaderboardFilter> filterBox = new JComboBox<>(LeaderboardFilter.values());
    private final List<Integer> rowUserIds = new ArrayList<>();
    private final JLabel myRankLabel = Theme.label(" ", Theme.BODY_BOLD, Theme.TEXT);
    private final DefaultTableModel tableModel;
    private final JTable table;

    public LeaderboardPanel(int currentUserId) {
        super(new BorderLayout(0, 16));
        this.currentUserId = currentUserId;
        setOpaque(false);

        tableModel = new DefaultTableModel(COLUMNS, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // read-only table
            }
        };
        table = createTable();

        add(buildToolbar(), BorderLayout.NORTH);
        add(buildTableCard(), BorderLayout.CENTER);
        add(buildRankBar(), BorderLayout.SOUTH);
    }

    private JPanel buildToolbar() {
        JPanel bar = new JPanel(new BorderLayout());
        bar.setOpaque(false);

        JPanel titles = new JPanel(new BorderLayout(0, 4));
        titles.setOpaque(false);
        titles.add(Theme.label("Leaderboard", Theme.HEADING, Theme.TEXT), BorderLayout.NORTH);
        titles.add(Theme.label("Top " + TOP_N + " commanders across all departments", Theme.SMALL, Theme.TEXT_MUTED),
                BorderLayout.SOUTH);
        bar.add(titles, BorderLayout.WEST);

        JPanel controls = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        controls.setOpaque(false);
        controls.add(Theme.label("Sort by", Theme.SMALL_BOLD, Theme.TEXT_MUTED));

        filterBox.setPreferredSize(new Dimension(170, 38));
        filterBox.setBackground(Theme.BG_INPUT);
        filterBox.setForeground(Theme.TEXT);
        filterBox.setFont(Theme.BODY);
        filterBox.setBorder(BorderFactory.createLineBorder(Theme.BORDER));
        filterBox.setRenderer(new DefaultListCellRenderer() {
            @Override
            public Component getListCellRendererComponent(JList<?> list, Object value, int index,
                                                          boolean isSelected, boolean cellHasFocus) {
                super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
                setBorder(new EmptyBorder(6, 10, 6, 10));
                setBackground(isSelected ? Theme.ACCENT : Theme.BG_INPUT);
                setForeground(isSelected ? Color.WHITE : Theme.TEXT);
                return this;
            }
        });
        filterBox.addActionListener(e -> reload());
        controls.add(filterBox);

        RoundedButton refresh = new RoundedButton("Refresh", Theme.BG_INPUT);
        refresh.setPreferredSize(new Dimension(100, 38));
        refresh.addActionListener(e -> reload());
        controls.add(refresh);

        bar.add(controls, BorderLayout.EAST);
        return bar;
    }

    private JTable createTable() {
        JTable t = new JTable(tableModel);
        t.setRowHeight(40);
        t.setShowGrid(false);
        t.setIntercellSpacing(new Dimension(0, 0));
        t.setFillsViewportHeight(true);
        t.setBackground(Theme.BG_PANEL);
        t.setForeground(Theme.TEXT);
        t.setFont(Theme.BODY);
        t.setRowSelectionAllowed(false);
        t.setFocusable(false);
        t.setDefaultRenderer(Object.class, new LeaderboardCellRenderer());

        int[] widths = {70, 220, 140, 80, 110, 130};
        for (int i = 0; i < widths.length; i++) {
            t.getColumnModel().getColumn(i).setPreferredWidth(widths[i]);
        }

        JTableHeader header = t.getTableHeader();
        header.setReorderingAllowed(false);
        header.setResizingAllowed(false);
        header.setPreferredSize(new Dimension(0, 42));
        header.setDefaultRenderer(new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,
                                                           boolean hasFocus, int row, int column) {
                super.getTableCellRendererComponent(table, value, false, false, row, column);
                setBackground(Theme.BG_PANEL_ALT);
                setForeground(Theme.TEXT_MUTED);
                setFont(Theme.SMALL_BOLD);
                setText(value.toString().toUpperCase());
                setHorizontalAlignment(column == 1 ? SwingConstants.LEFT : SwingConstants.CENTER);
                setBorder(BorderFactory.createCompoundBorder(
                        BorderFactory.createMatteBorder(0, 0, 1, 0, Theme.BORDER),
                        new EmptyBorder(0, 14, 0, 14)));
                return this;
            }
        });
        return t;
    }

    private JPanel buildTableCard() {
        RoundedPanel card = new RoundedPanel(new BorderLayout(), Theme.BG_PANEL, 18);
        card.setBorder(new EmptyBorder(8, 8, 8, 8));
        JScrollPane scroll = new JScrollPane(table);
        scroll.setBorder(BorderFactory.createEmptyBorder());
        scroll.getViewport().setBackground(Theme.BG_PANEL);
        scroll.setOpaque(false);
        card.add(scroll, BorderLayout.CENTER);
        return card;
    }

    private JPanel buildRankBar() {
        RoundedPanel bar = new RoundedPanel(new BorderLayout(), Theme.ACCENT_SOFT, 14);
        bar.setBorder(new EmptyBorder(12, 18, 12, 18));
        bar.add(myRankLabel, BorderLayout.CENTER);
        return bar;
    }

    /** Loads the leaderboard again from the database (called when the filter changes). */
    public void reload() {
        LeaderboardFilter filter = (LeaderboardFilter) filterBox.getSelectedItem();
        try {
            List<LeaderboardEntry> entries = statsRepo.getLeaderboard(filter, TOP_N);
            int myRank = statsRepo.getPlayerRank(currentUserId, filter);

            tableModel.setRowCount(0);
            rowUserIds.clear();
            for (LeaderboardEntry e : entries) {
                tableModel.addRow(new Object[]{
                    e.getRank(),
                    e.getUsername(),
                    Format.number(e.getScore()),
                    e.getWins(),
                    Format.duration(e.getFastestWinSeconds()),
                    Format.date(e.getAchievedAt())
                });
                rowUserIds.add(e.getUserId());
            }

            if (myRank > 0) {
                String extra = myRank > TOP_N ? "   -   Keep playing to break into the Top " + TOP_N + "!" : "";
                myRankLabel.setText("Your rank (" + filter + "):  #" + myRank + extra);
            } else if (entries.isEmpty()) {
                myRankLabel.setText("No one is on this leaderboard yet. Win a match to be the first!");
            } else {
                myRankLabel.setText("You are not ranked in \"" + filter + "\" yet. Win a match to join the leaderboard!");
            }
        } catch (DataException ex) {
            Dialogs.showDataError(this, ex);
        }
    }

    /** Colors each cell: gold/silver/bronze for the Top 3, and highlights the logged-in player. */
    private class LeaderboardCellRenderer extends DefaultTableCellRenderer {

        @Override
        public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,
                                                       boolean hasFocus, int row, int column) {
            super.getTableCellRendererComponent(table, value, false, false, row, column);
            boolean isMe = row < rowUserIds.size() && rowUserIds.get(row) == currentUserId;

            setBorder(new EmptyBorder(0, 14, 0, 14));
            setHorizontalAlignment(column == 1 ? SwingConstants.LEFT : SwingConstants.CENTER);
            setBackground(isMe ? Theme.ACCENT_SOFT : (row % 2 == 0 ? Theme.BG_PANEL : Theme.BG_PANEL_ALT));
            setForeground(Theme.TEXT);
            setFont(isMe ? Theme.BODY_BOLD : Theme.BODY);

            if (column == 0) {
                int rank = (Integer) value;
                setText("#" + rank);
                setFont(Theme.BODY_BOLD);
                if (rank == 1) setForeground(Theme.GOLD);
                else if (rank == 2) setForeground(Theme.SILVER);
                else if (rank == 3) setForeground(Theme.BRONZE);
            } else if (column == 1 && isMe) {
                setText(value + "   (You)");
            }
            return this;
        }
    }
}
