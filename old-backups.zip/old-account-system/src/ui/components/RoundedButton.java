package ui.components;

import java.awt.Color;
import java.awt.Cursor;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JButton;
import javax.swing.border.EmptyBorder;

/**
 * A flat, rounded button with hover and press effects.
 * Inheritance: it IS-A JButton, so it works anywhere a JButton works
 * (addActionListener, setEnabled, ...). We only override how it is painted.
 */
public class RoundedButton extends JButton {

    private Color baseColor;
    private int arc = 14;
    private boolean hovered;

    public RoundedButton(String text) {
        this(text, Theme.ACCENT);
    }

    public RoundedButton(String text, Color baseColor) {
        super(text);
        this.baseColor = baseColor;
        setFont(Theme.BODY_BOLD);
        setForeground(Color.WHITE);
        setContentAreaFilled(false);
        setBorderPainted(false);
        setFocusPainted(false);
        setOpaque(false);
        setBorder(new EmptyBorder(10, 18, 10, 18));
        setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

        addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                hovered = true;
                repaint();
            }

            @Override
            public void mouseExited(MouseEvent e) {
                hovered = false;
                repaint();
            }
        });
    }

    public void setBaseColor(Color baseColor) {
        this.baseColor = baseColor;
        repaint();
    }

    public Color getBaseColor() {
        return baseColor;
    }

    public void setArc(int arc) {
        this.arc = arc;
        repaint();
    }

    @Override
    protected void paintComponent(Graphics g) {
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        Color fill;
        if (!isEnabled()) {
            fill = Theme.BORDER;
        } else if (getModel().isPressed()) {
            fill = Theme.blend(baseColor, Color.BLACK, 0.2f);
        } else if (hovered) {
            fill = Theme.blend(baseColor, Color.WHITE, 0.15f);
        } else {
            fill = baseColor;
        }
        g2.setColor(fill);
        g2.fillRoundRect(0, 0, getWidth(), getHeight(), arc, arc);
        g2.dispose();

        super.paintComponent(g); // draws the text on top
    }
}
