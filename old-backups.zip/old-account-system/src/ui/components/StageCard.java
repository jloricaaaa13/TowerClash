package ui.components;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.function.Consumer;
import javax.swing.JComponent;
import model.Stage;

/**
 * A clickable card for one stage in the Stage Select row.
 * Locked stages are dimmed, show a padlock, and cannot be clicked.
 */
public class StageCard extends JComponent {

    private static final Color[] DIFFICULTY_COLORS = {
        new Color(0x22C55E), new Color(0x84CC16), new Color(0xF59E0B),
        new Color(0xF97316), new Color(0xEF4444)
    };

    private final Stage stage;
    private final boolean locked;
    private boolean selected;
    private boolean hovered;
    private Consumer<Stage> onSelect;

    public StageCard(Stage stage, boolean locked) {
        this.stage = stage;
        this.locked = locked;
        setPreferredSize(new Dimension(150, 132));
        setToolTipText(locked
                ? "Win Stage " + (stage.getNumber() - 1) + " to unlock"
                : stage.getDescription());
        if (!locked) {
            setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        }

        addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (!StageCard.this.locked && onSelect != null) {
                    onSelect.accept(stage);
                }
            }

            @Override
            public void mouseEntered(MouseEvent e) {
                hovered = true;
                repaint();
            }

            @Override
            public void mouseExited(MouseEvent e) {
                hovered = false;
                repaint();
            }
        });
    }

    public Stage getStage() {
        return stage;
    }

    public boolean isLocked() {
        return locked;
    }

    public void setSelected(boolean selected) {
        this.selected = selected;
        repaint();
    }

    public void setOnSelect(Consumer<Stage> onSelect) {
        this.onSelect = onSelect;
    }

    @Override
    protected void paintComponent(Graphics g) {
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
        int w = getWidth();
        int h = getHeight();

        // Card background and outline
        g2.setColor(locked ? Theme.BG_PANEL_ALT : (hovered ? Theme.blend(Theme.BG_PANEL, Color.WHITE, 0.05f) : Theme.BG_PANEL));
        g2.fillRoundRect(0, 0, w, h, 18, 18);
        if (selected) {
            g2.setColor(Theme.ACCENT);
            g2.setStroke(new BasicStroke(3f));
            g2.drawRoundRect(2, 2, w - 5, h - 5, 18, 18);
        } else {
            g2.setColor(Theme.BORDER);
            g2.setStroke(new BasicStroke(1.2f));
            g2.drawRoundRect(1, 1, w - 3, h - 3, 18, 18);
        }

        Color textColor = locked ? Theme.blend(Theme.TEXT_MUTED, Theme.BG_PANEL, 0.4f) : Theme.TEXT;

        g2.setFont(Theme.font(Font.BOLD, 11));
        g2.setColor(selected ? new Color(0xA5B4FC) : Theme.TEXT_MUTED);
        g2.drawString("STAGE " + stage.getNumber(), 16, 26);

        g2.setFont(Theme.font(Font.BOLD, 15));
        g2.setColor(textColor);
        drawFittedString(g2, stage.getName(), 16, 50, w - 28);

        if (locked) {
            drawPadlock(g2, 16, h - 44);
            g2.setFont(Theme.font(Font.BOLD, 12));
            g2.setColor(Theme.TEXT_MUTED);
            g2.drawString("LOCKED", 40, h - 24);
        } else {
            // Difficulty pips (1 to 5)
            g2.setFont(Theme.font(Font.PLAIN, 11));
            g2.setColor(Theme.TEXT_MUTED);
            g2.drawString("Difficulty", 16, h - 46);
            Color pipColor = DIFFICULTY_COLORS[Math.max(0, Math.min(4, stage.getDifficulty() - 1))];
            for (int i = 0; i < 5; i++) {
                g2.setColor(i < stage.getDifficulty() ? pipColor : Theme.BORDER);
                g2.fillOval(16 + i * 16, h - 38, 11, 11);
            }
            g2.setFont(Theme.font(Font.BOLD, 11));
            g2.setColor(Theme.GOLD);
            g2.drawString("+" + stage.getRewardCoins() + " coins", 16, h - 12);
        }
        g2.dispose();
    }

    private void drawPadlock(Graphics2D g2, int x, int y) {
        g2.setColor(Theme.TEXT_MUTED);
        g2.setStroke(new BasicStroke(2.2f));
        g2.drawArc(x + 3, y, 12, 14, 0, 180);  // shackle
        g2.fillRoundRect(x, y + 7, 18, 14, 4, 4);  // body
        g2.setColor(Theme.BG_PANEL_ALT);
        g2.fillOval(x + 7, y + 11, 4, 5);          // keyhole
    }

    /** Draws text, cutting it with "..." if it is too wide. */
    private void drawFittedString(Graphics2D g2, String text, int x, int y, int maxWidth) {
        FontMetrics fm = g2.getFontMetrics();
        String shown = text;
        while (fm.stringWidth(shown) > maxWidth && shown.length() > 3) {
            shown = shown.substring(0, shown.length() - 4) + "...";
        }
        g2.drawString(shown, x, y);
    }
}
