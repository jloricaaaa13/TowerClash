package ui.components;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import javax.swing.JLabel;
import javax.swing.border.EmptyBorder;

/** A dashboard card showing one statistic, e.g. "WINS  12". */
public class StatCard extends RoundedPanel {

    private final JLabel valueLabel;
    private final Color accent;

    public StatCard(String title, Color accent) {
        super(new BorderLayout(0, 6), Theme.BG_PANEL, 18);
        this.accent = accent;
        setBorder(new EmptyBorder(16, 24, 16, 16));

        add(Theme.label(title.toUpperCase(), Theme.font(Font.BOLD, 11), Theme.TEXT_MUTED), BorderLayout.NORTH);
        valueLabel = Theme.label("--", Theme.font(Font.BOLD, 26), Theme.TEXT);
        add(valueLabel, BorderLayout.CENTER);
    }

    public void setValue(String value) {
        setValue(value, Theme.TEXT);
    }

    public void setValue(String value, Color color) {
        valueLabel.setText(value);
        valueLabel.setForeground(color);
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setColor(accent);
        g2.fillRoundRect(0, 16, 5, getHeight() - 32, 5, 5); // colored stripe on the left
        g2.dispose();
    }
}
