package ui.components;

import java.awt.Color;
import java.awt.Cursor;
import java.awt.Font;
import java.awt.GraphicsEnvironment;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.util.Arrays;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JLabel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.UIManager;
import javax.swing.border.Border;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.plaf.ColorUIResource;

/**
 * One place for all colors, fonts, and styled components.
 * Change a color here and the whole app updates.
 */
public final class Theme {

    // ---- Base palette (dark theme) ----
    public static final Color BG_DARK = new Color(0x0F172A);
    public static final Color BG_PANEL = new Color(0x1E293B);
    public static final Color BG_PANEL_ALT = new Color(0x172033);
    public static final Color BG_INPUT = new Color(0x273449);
    public static final Color BORDER = new Color(0x334155);
    public static final Color TEXT = new Color(0xF1F5F9);
    public static final Color TEXT_MUTED = new Color(0x94A3B8);
    public static final Color ACCENT = new Color(0x6366F1);
    public static final Color ACCENT_SOFT = new Color(0x3730A3);
    public static final Color SUCCESS = new Color(0x22C55E);
    public static final Color WARNING = new Color(0xF59E0B);
    public static final Color DANGER = new Color(0xEF4444);
    public static final Color GOLD = new Color(0xFACC15);
    public static final Color SILVER = new Color(0xCBD5E1);
    public static final Color BRONZE = new Color(0xF97316);
    public static final Color TRANSPARENT = new Color(0, 0, 0, 0);

    // ---- Department colors ----
    public static final Color HOSPITALITY_RED = new Color(0xDC2626);
    public static final Color EDUCATION_BLUE = new Color(0x2563EB);
    public static final Color COMPSCI_YELLOW = new Color(0xEAB308);

    // ---- Fonts ----
    private static final String FONT_FAMILY = pickFontFamily();

    public static final Font TITLE = font(Font.BOLD, 28);
    public static final Font HEADING = font(Font.BOLD, 18);
    public static final Font BODY = font(Font.PLAIN, 14);
    public static final Font BODY_BOLD = font(Font.BOLD, 14);
    public static final Font SMALL = font(Font.PLAIN, 12);
    public static final Font SMALL_BOLD = font(Font.BOLD, 12);

    private Theme() {
    }

    public static Font font(int style, int size) {
        return new Font(FONT_FAMILY, style, size);
    }

    private static String pickFontFamily() {
        String[] installed = GraphicsEnvironment.getLocalGraphicsEnvironment().getAvailableFontFamilyNames();
        for (String wanted : new String[]{"Segoe UI", "Helvetica Neue", "Arial"}) {
            if (Arrays.asList(installed).contains(wanted)) {
                return wanted;
            }
        }
        return Font.SANS_SERIF;
    }

    /** Mixes two colors. ratio 0 = all a, ratio 1 = all b. */
    public static Color blend(Color a, Color b, float ratio) {
        float r = 1 - ratio;
        return new Color(
                Math.round(a.getRed() * r + b.getRed() * ratio),
                Math.round(a.getGreen() * r + b.getGreen() * ratio),
                Math.round(a.getBlue() * r + b.getBlue() * ratio),
                Math.round(a.getAlpha() * r + 255 * ratio * (b.getAlpha() / 255f)));
    }

    /** Sets default colors for built-in Swing parts (dialogs, combo boxes, scroll bars). Call once at startup. */
    public static void installDefaults() {
        UIManager.put("OptionPane.background", new ColorUIResource(BG_PANEL));
        UIManager.put("OptionPane.messageForeground", new ColorUIResource(TEXT));
        UIManager.put("OptionPane.messageFont", BODY);
        UIManager.put("OptionPane.buttonFont", BODY_BOLD);
        UIManager.put("Panel.background", new ColorUIResource(BG_PANEL));
        UIManager.put("Button.background", new ColorUIResource(ACCENT));
        UIManager.put("Button.foreground", new ColorUIResource(Color.WHITE));
        UIManager.put("Button.select", new ColorUIResource(ACCENT_SOFT));
        UIManager.put("Button.focus", new ColorUIResource(ACCENT));
        UIManager.put("Button.gradient", null);
        UIManager.put("ComboBox.background", new ColorUIResource(BG_INPUT));
        UIManager.put("ComboBox.foreground", new ColorUIResource(TEXT));
        UIManager.put("ComboBox.selectionBackground", new ColorUIResource(ACCENT));
        UIManager.put("ComboBox.selectionForeground", new ColorUIResource(Color.WHITE));
        UIManager.put("ComboBox.buttonBackground", new ColorUIResource(BG_INPUT));
        UIManager.put("ComboBox.buttonHighlight", new ColorUIResource(BG_INPUT));
        UIManager.put("ComboBox.buttonShadow", new ColorUIResource(BORDER));
        UIManager.put("ComboBox.buttonDarkShadow", new ColorUIResource(TEXT)); // arrow color
        UIManager.put("ComboBox.font", BODY);
        UIManager.put("ScrollBar.background", new ColorUIResource(BG_PANEL));
        UIManager.put("ScrollBar.thumb", new ColorUIResource(BORDER));
        UIManager.put("ScrollBar.track", new ColorUIResource(BG_PANEL));
        UIManager.put("ToolTip.background", new ColorUIResource(BG_INPUT));
        UIManager.put("ToolTip.foreground", new ColorUIResource(TEXT));
    }

    // ---- Component factories ----

    public static JLabel label(String text, Font font, Color color) {
        JLabel label = new JLabel(text);
        label.setFont(font);
        label.setForeground(color);
        return label;
    }

    public static JTextField textField() {
        JTextField field = new JTextField();
        styleInput(field);
        return field;
    }

    public static JPasswordField passwordField() {
        JPasswordField field = new JPasswordField();
        styleInput(field);
        field.setEchoChar('•');
        return field;
    }

    /** Dark rounded input that glows with the accent color when focused. */
    public static void styleInput(JTextField field) {
        field.setFont(BODY);
        field.setBackground(BG_INPUT);
        field.setForeground(TEXT);
        field.setCaretColor(TEXT);
        field.setSelectionColor(ACCENT);
        field.setSelectedTextColor(Color.WHITE);
        field.setBorder(inputBorder(BORDER));
        field.addFocusListener(new FocusAdapter() {
            @Override
            public void focusGained(FocusEvent e) {
                field.setBorder(inputBorder(ACCENT));
            }

            @Override
            public void focusLost(FocusEvent e) {
                field.setBorder(inputBorder(BORDER));
            }
        });
    }

    private static Border inputBorder(Color color) {
        return BorderFactory.createCompoundBorder(
                new LineBorder(color, 2, true),
                new EmptyBorder(8, 12, 8, 12));
    }

    public static JCheckBox checkBox(String text) {
        JCheckBox box = new JCheckBox(text);
        box.setFont(SMALL);
        box.setForeground(TEXT_MUTED);
        box.setOpaque(false);
        box.setFocusPainted(false);
        box.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        return box;
    }

    /** A button that looks like a clickable text link. */
    public static JButton linkButton(String text) {
        JButton button = new JButton(text);
        button.setFont(SMALL_BOLD);
        button.setForeground(new Color(0xA5B4FC));
        button.setContentAreaFilled(false);
        button.setBorderPainted(false);
        button.setFocusPainted(false);
        button.setOpaque(false);
        button.setBorder(new EmptyBorder(0, 4, 0, 0));
        button.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        return button;
    }
}
