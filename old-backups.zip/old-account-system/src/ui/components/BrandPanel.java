package ui.components;

import java.awt.Color;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Polygon;
import java.awt.RenderingHints;
import java.util.Random;
import javax.swing.JPanel;

/**
 * The left side of the Login/Register screens: a night sky with the
 * three department towers, drawn entirely with Graphics2D shapes.
 */
public class BrandPanel extends JPanel {

    public BrandPanel() {
        setOpaque(true);
    }

    @Override
    protected void paintComponent(Graphics g) {
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
        int w = getWidth();
        int h = getHeight();

        // Sky
        g2.setPaint(new GradientPaint(0, 0, new Color(0x1E1B4B), 0, h, new Color(0x0F172A)));
        g2.fillRect(0, 0, w, h);

        // Stars (fixed seed so they do not move when the window repaints)
        Random random = new Random(7);
        for (int i = 0; i < 70; i++) {
            g2.setColor(new Color(255, 255, 255, 40 + random.nextInt(150)));
            int size = 1 + random.nextInt(2);
            g2.fillOval(random.nextInt(Math.max(1, w)), random.nextInt(Math.max(1, h * 2 / 3)), size, size);
        }

        // Title
        g2.setColor(Theme.TEXT_MUTED);
        g2.setFont(Theme.font(Font.BOLD, 16));
        drawCentered(g2, "D E P A R T M E N T", w, 92);
        g2.setColor(Theme.TEXT);
        g2.setFont(Theme.font(Font.BOLD, 44));
        drawCentered(g2, "TOWER CLASH", w, 142);
        g2.setColor(new Color(0xA5B4FC));
        g2.setFont(Theme.font(Font.PLAIN, 15));
        drawCentered(g2, "Defend your department. Destroy theirs.", w, 174);

        // Ground
        int groundY = h - 96;
        g2.setPaint(new GradientPaint(0, groundY, new Color(0x1E293B), 0, h, new Color(0x0B1120)));
        g2.fillRect(0, groundY, w, h - groundY);
        g2.setColor(new Color(0x334155));
        g2.fillRect(0, groundY, w, 3);

        // Three department towers
        drawTower(g2, w * 22 / 100, groundY, 62, 150, Theme.HOSPITALITY_RED, "HOSPITALITY");
        drawTower(g2, w / 2, groundY, 72, 200, Theme.EDUCATION_BLUE, "EDUCATION");
        drawTower(g2, w * 78 / 100, groundY, 62, 170, Theme.COMPSCI_YELLOW, "COMP SCI");

        g2.dispose();
    }

    private void drawTower(Graphics2D g2, int centerX, int groundY, int width, int height, Color color, String label) {
        int x = centerX - width / 2;
        int top = groundY - height;

        // Body with a light-to-dark gradient
        g2.setPaint(new GradientPaint(x, 0, Theme.blend(color, Color.WHITE, 0.15f),
                x + width, 0, Theme.blend(color, Color.BLACK, 0.35f)));
        g2.fillRect(x, top, width, height);

        // Battlements on top
        int block = width / 5;
        for (int i = 0; i < 5; i += 2) {
            g2.fillRect(x + i * block, top - 12, block, 12);
        }

        // Windows
        g2.setColor(new Color(255, 244, 200, 210));
        for (int wy = top + 22; wy < groundY - 50; wy += 34) {
            g2.fillRoundRect(centerX - 16, wy, 10, 14, 4, 4);
            g2.fillRoundRect(centerX + 6, wy, 10, 14, 4, 4);
        }

        // Door
        g2.setColor(Theme.blend(color, Color.BLACK, 0.6f));
        g2.fillRoundRect(centerX - 11, groundY - 30, 22, 30, 20, 20);

        // Flag
        g2.setColor(Theme.SILVER);
        g2.fillRect(centerX - 1, top - 42, 2, 30);
        g2.setColor(color);
        Polygon flag = new Polygon(
                new int[]{centerX + 1, centerX + 23, centerX + 1},
                new int[]{top - 42, top - 35, top - 28}, 3);
        g2.fillPolygon(flag);

        // Label
        g2.setFont(Theme.font(Font.BOLD, 11));
        g2.setColor(Theme.TEXT_MUTED);
        FontMetrics fm = g2.getFontMetrics();
        g2.drawString(label, centerX - fm.stringWidth(label) / 2, groundY + 26);
    }

    private void drawCentered(Graphics2D g2, String text, int width, int y) {
        FontMetrics fm = g2.getFontMetrics();
        g2.drawString(text, (width - fm.stringWidth(text)) / 2, y);
    }
}
