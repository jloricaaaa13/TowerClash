package ui.components;

import java.awt.Component;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import javax.swing.JPanel;

/**
 * Stacks components in one column, each stretched to the full width.
 * Makes forms (login, register, profile) short and easy to read.
 */
public class FormPanel extends JPanel {

    private int row = 0;

    public FormPanel() {
        super(new GridBagLayout());
        setOpaque(false);
    }

    /** Adds a component below the previous one, with a gap (in pixels) above it. */
    public <T extends Component> T addRow(T component, int gapAbove) {
        GridBagConstraints c = new GridBagConstraints();
        c.gridx = 0;
        c.gridy = row++;
        c.weightx = 1;
        c.fill = GridBagConstraints.HORIZONTAL;
        c.anchor = GridBagConstraints.WEST;
        c.insets = new Insets(gapAbove, 0, 0, 0);
        add(component, c);
        return component;
    }
}
