package ui;

import db.DataException;
import db.Repositories;
import db.UserRepository;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.util.Arrays;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import model.User;
import ui.components.BrandPanel;
import ui.components.FormPanel;
import ui.components.RoundedButton;
import ui.components.RoundedPanel;
import ui.components.Theme;
import util.Dialogs;
import util.Session;

/** The first screen: log in with username (or email) and password. */
public class LoginFrame extends JFrame {

    private final UserRepository users = Repositories.users();
    private final JTextField usernameField = Theme.textField();
    private final JPasswordField passwordField = Theme.passwordField();

    public LoginFrame() {
        this("");
    }

    /** @param prefillUsername shown in the username box (used right after registering) */
    public LoginFrame(String prefillUsername) {
        setTitle("Department Tower Clash - Login");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(980, 640);
        setResizable(false);
        setLocationRelativeTo(null);

        JPanel root = new JPanel(new GridLayout(1, 2));
        root.add(new BrandPanel());
        root.add(buildFormSide());
        setContentPane(root);

        usernameField.setText(prefillUsername);
        // Put the cursor in the right box when the window opens
        if (prefillUsername.isEmpty()) {
            usernameField.requestFocusInWindow();
        } else {
            passwordField.requestFocusInWindow();
        }
    }

    private JPanel buildFormSide() {
        JPanel side = new JPanel(new GridBagLayout()); // GridBagLayout centers the form
        side.setBackground(Theme.BG_DARK);

        FormPanel form = new FormPanel();
        form.addRow(Theme.label("Welcome back!", Theme.TITLE, Theme.TEXT), 0);
        form.addRow(Theme.label("Log in to continue your campaign.", Theme.BODY, Theme.TEXT_MUTED), 6);

        if (Repositories.isOfflineMode()) {
            form.addRow(buildOfflineNotice(), 18);
        }

        form.addRow(Theme.label("Username or Email", Theme.SMALL_BOLD, Theme.TEXT_MUTED), 22);
        usernameField.setPreferredSize(new Dimension(340, 44));
        form.addRow(usernameField, 6);

        form.addRow(Theme.label("Password", Theme.SMALL_BOLD, Theme.TEXT_MUTED), 16);
        passwordField.setPreferredSize(new Dimension(340, 44));
        form.addRow(passwordField, 6);

        char echo = passwordField.getEchoChar();
        JCheckBox showPassword = form.addRow(Theme.checkBox("Show password"), 8);
        showPassword.addActionListener(e -> passwordField.setEchoChar(showPassword.isSelected() ? (char) 0 : echo));

        RoundedButton loginButton = new RoundedButton("LOG IN");
        loginButton.setPreferredSize(new Dimension(340, 46));
        loginButton.addActionListener(e -> doLogin());
        form.addRow(loginButton, 22);
        getRootPane().setDefaultButton(loginButton); // pressing Enter = click LOG IN

        JPanel registerRow = new JPanel(new FlowLayout(FlowLayout.CENTER, 0, 0));
        registerRow.setOpaque(false);
        registerRow.add(Theme.label("Don't have an account?", Theme.SMALL, Theme.TEXT_MUTED));
        JButton registerLink = Theme.linkButton("Create one");
        registerLink.addActionListener(e -> openRegister());
        registerRow.add(registerLink);
        form.addRow(registerRow, 20);

        side.add(form);
        return side;
    }

    /** Small yellow box: no database yet, and a demo account to try. */
    private JPanel buildOfflineNotice() {
        RoundedPanel box = new RoundedPanel(new BorderLayout(0, 2), new Color(0x3F3A1D), 12);
        box.setBorder(new EmptyBorder(10, 14, 10, 14));
        box.add(Theme.label("OFFLINE MODE  -  no database yet", Theme.SMALL_BOLD, Theme.GOLD), BorderLayout.NORTH);
        box.add(Theme.label("Demo account:  demo  /  demo1234", Theme.SMALL, new Color(0xFDE68A)),
                BorderLayout.SOUTH);

        JButton fill = Theme.linkButton("Fill in");
        fill.addActionListener(e -> {
            usernameField.setText("demo");
            passwordField.setText("demo1234");
        });
        JPanel right = new JPanel(new GridBagLayout());
        right.setOpaque(false);
        right.add(fill);
        box.add(right, BorderLayout.EAST);
        return box;
    }

    private void doLogin() {
        String login = usernameField.getText().trim();
        char[] passwordChars = passwordField.getPassword();
        String password = new String(passwordChars);
        Arrays.fill(passwordChars, '\0'); // clear the copy from memory

        if (login.isEmpty()) {
            Dialogs.showError(this, "Login", "Please enter your username or email.");
            usernameField.requestFocus();
            return;
        }
        if (password.isEmpty()) {
            Dialogs.showError(this, "Login", "Please enter your password.");
            passwordField.requestFocus();
            return;
        }

        try {
            User user = users.login(login, password);
            if (user == null) {
                Dialogs.showError(this, "Login Failed", "Incorrect username/email or password.");
                passwordField.setText("");
                passwordField.requestFocus();
                return;
            }
            Session.login(user);
            dispose();
            DashboardFrame.open();
        } catch (DataException ex) {
            Dialogs.showDataError(this, ex);
        }
    }

    private void openRegister() {
        dispose();
        new RegisterFrame().setVisible(true);
    }
}
