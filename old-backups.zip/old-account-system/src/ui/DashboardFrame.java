package ui;

import db.DataException;
import db.Repositories;
import db.StageRepository;
import db.StatsRepository;
import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GridLayout;
import java.awt.RenderingHints;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;
import model.PlayerStats;
import model.Stage;
import model.User;
import ui.components.RoundedButton;
import ui.components.RoundedPanel;
import ui.components.StageCard;
import ui.components.StatCard;
import ui.components.Theme;
import util.Dialogs;
import util.Format;
import util.Session;

/**
 * The main menu after login: stats, stage select, leaderboard, and navigation.
 * Uses a CardLayout to switch between the "Home" and "Leaderboard" views
 * inside the same window.
 */
public class DashboardFrame extends JFrame {

    private static final String CARD_HOME = "HOME";
    private static final String CARD_LEADERBOARD = "LEADERBOARD";

    private final User user;
    private final StatsRepository statsRepo = Repositories.stats();
    private final StageRepository stageRepo = Repositories.stages();

    private final CardLayout cardLayout = new CardLayout();
    private final JPanel content = new JPanel(cardLayout);
    private final Map<String, RoundedButton> navButtons = new LinkedHashMap<>();
    private final List<StageCard> stageCards = new ArrayList<>();
    private final JPanel stageRow = new JPanel(new GridLayout(1, 0, 14, 0));
    private final JLabel coinsLabel = Theme.label("0", Theme.BODY_BOLD, Theme.GOLD);
    private final JLabel selectedStageLabel = Theme.label(" ", Theme.BODY, Theme.TEXT_MUTED);
    private final LeaderboardPanel leaderboardPanel;

    private StatCard matchesCard;
    private StatCard winsCard;
    private StatCard lossesCard;
    private StatCard winRateCard;
    private StatCard highScoreCard;
    private StatCard fastestWinCard;
    private StatCard towerCard;
    private StatCard progressCard;

    private PlayerStats stats = new PlayerStats();
    private Stage selectedStage;

    /**
     * The ONLY way to open the dashboard. It checks the session first,
     * so nobody can reach the dashboard without logging in.
     */
    public static void open() {
        if (!Session.isLoggedIn()) {
            Dialogs.showWarning(null, "Login Required", "Please log in first.");
            new LoginFrame().setVisible(true);
            return;
        }
        new DashboardFrame(Session.getCurrentUser()).setVisible(true);
    }

    private DashboardFrame(User user) {
        this.user = user;
        setTitle("Department Tower Clash - Dashboard");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1240, 780);
        setMinimumSize(new Dimension(1120, 720));
        setLocationRelativeTo(null);

        leaderboardPanel = new LeaderboardPanel(user.getUserId());

        JPanel root = new JPanel(new BorderLayout());
        root.setBackground(Theme.BG_DARK);
        root.add(buildSidebar(), BorderLayout.WEST);

        JPanel main = new JPanel(new BorderLayout(0, 22));
        main.setOpaque(false);
        main.setBorder(new EmptyBorder(26, 30, 26, 30));
        main.add(buildHeader(), BorderLayout.NORTH);

        content.setOpaque(false);
        content.add(buildHomeView(), CARD_HOME);
        content.add(leaderboardPanel, CARD_LEADERBOARD);
        main.add(content, BorderLayout.CENTER);

        root.add(main, BorderLayout.CENTER);
        setContentPane(root);

        refreshData();
        showView(CARD_HOME);
    }

    // ------------------------------------------------------------------
    //  Layout
    // ------------------------------------------------------------------

    private JPanel buildSidebar() {
        JPanel sidebar = new JPanel();
        sidebar.setLayout(new BoxLayout(sidebar, BoxLayout.Y_AXIS));
        sidebar.setBackground(Theme.BG_PANEL);
        sidebar.setPreferredSize(new Dimension(230, 0));
        sidebar.setBorder(new EmptyBorder(26, 18, 22, 18));

        JLabel small = Theme.label("DEPARTMENT", Theme.font(Font.BOLD, 11), Theme.TEXT_MUTED);
        JLabel big = Theme.label("TOWER CLASH", Theme.font(Font.BOLD, 22), Theme.TEXT);
        small.setAlignmentX(Component.LEFT_ALIGNMENT);
        big.setAlignmentX(Component.LEFT_ALIGNMENT);
        sidebar.add(small);
        sidebar.add(big);
        sidebar.add(Box.createVerticalStrut(8));
        sidebar.add(departmentStripe());
        sidebar.add(Box.createVerticalStrut(30));

        addNavButton(sidebar, "Home", () -> showView(CARD_HOME));
        addNavButton(sidebar, "Play", this::onPlay);
        addNavButton(sidebar, "Leaderboard", () -> showView(CARD_LEADERBOARD));
        addNavButton(sidebar, "Upgrades", this::onUpgrades);
        addNavButton(sidebar, "Profile", this::onProfile);

        sidebar.add(Box.createVerticalGlue());

        RoundedButton logout = sidebarButton("Logout");
        logout.setForeground(new Color(0xFCA5A5));
        logout.addActionListener(e -> onLogout());
        sidebar.add(logout);
        return sidebar;
    }

    /** Three small colored bars: red, blue, yellow (the three departments). */
    private JPanel departmentStripe() {
        JPanel stripe = new JPanel(new GridLayout(1, 3, 4, 0));
        stripe.setOpaque(false);
        stripe.setAlignmentX(Component.LEFT_ALIGNMENT);
        stripe.setPreferredSize(new Dimension(120, 5));
        stripe.setMaximumSize(new Dimension(120, 5));
        for (Color c : new Color[]{Theme.HOSPITALITY_RED, Theme.EDUCATION_BLUE, Theme.COMPSCI_YELLOW}) {
            RoundedPanel bar = new RoundedPanel(null, c, 4);
            stripe.add(bar);
        }
        return stripe;
    }

    private void addNavButton(JPanel sidebar, String text, Runnable action) {
        RoundedButton button = sidebarButton(text);
        button.addActionListener(e -> action.run());
        navButtons.put(text, button);
        sidebar.add(button);
        sidebar.add(Box.createVerticalStrut(6));
    }

    private RoundedButton sidebarButton(String text) {
        RoundedButton button = new RoundedButton(text, Theme.TRANSPARENT);
        button.setHorizontalAlignment(SwingConstants.LEFT);
        button.setForeground(Theme.TEXT);
        button.setFont(Theme.BODY_BOLD);
        button.setAlignmentX(Component.LEFT_ALIGNMENT);
        button.setMaximumSize(new Dimension(Integer.MAX_VALUE, 44));
        button.setBorder(new EmptyBorder(10, 16, 10, 16));
        return button;
    }

    private JPanel buildHeader() {
        JPanel header = new JPanel(new BorderLayout());
        header.setOpaque(false);

        JPanel greeting = new JPanel(new BorderLayout(0, 4));
        greeting.setOpaque(false);
        greeting.add(Theme.label("Welcome back, " + user.getUsername() + "!", Theme.TITLE, Theme.TEXT),
                BorderLayout.NORTH);
        greeting.add(Theme.label("Ready to defend your department?", Theme.BODY, Theme.TEXT_MUTED),
                BorderLayout.SOUTH);
        header.add(greeting, BorderLayout.WEST);

        RoundedPanel coinsPill = new RoundedPanel(new FlowLayout(FlowLayout.CENTER, 8, 0), new Color(0x3F3A1D), 30);
        coinsPill.setBorder(new EmptyBorder(10, 16, 10, 18));
        coinsPill.add(new CoinIcon());
        coinsPill.add(coinsLabel);
        coinsPill.add(Theme.label("coins", Theme.SMALL, new Color(0xFDE68A)));

        JPanel right = new JPanel(new FlowLayout(FlowLayout.RIGHT, 0, 6));
        right.setOpaque(false);
        right.add(coinsPill);
        header.add(right, BorderLayout.EAST);
        return header;
    }

    private JPanel buildHomeView() {
        JPanel home = new JPanel(new BorderLayout(0, 26));
        home.setOpaque(false);
        home.add(buildStatsSection(), BorderLayout.NORTH);
        home.add(buildStageSection(), BorderLayout.CENTER);
        return home;
    }

    private JPanel buildStatsSection() {
        matchesCard = new StatCard("Matches Played", Theme.ACCENT);
        winsCard = new StatCard("Wins", Theme.SUCCESS);
        lossesCard = new StatCard("Losses", Theme.DANGER);
        winRateCard = new StatCard("Win Rate", new Color(0x06B6D4));
        highScoreCard = new StatCard("Highest Score", Theme.GOLD);
        fastestWinCard = new StatCard("Fastest Win", new Color(0xA855F7));
        towerCard = new StatCard("Most Used Tower", Theme.HOSPITALITY_RED);
        progressCard = new StatCard("Stage Progress", Theme.EDUCATION_BLUE);

        JPanel grid = new JPanel(new GridLayout(2, 4, 16, 16));
        grid.setOpaque(false);
        for (StatCard card : new StatCard[]{matchesCard, winsCard, lossesCard, winRateCard,
                                            highScoreCard, fastestWinCard, towerCard, progressCard}) {
            card.setPreferredSize(new Dimension(0, 96));
            grid.add(card);
        }
        return section("Your Stats", grid);
    }

    private JPanel buildStageSection() {
        stageRow.setOpaque(false);

        RoundedButton playButton = new RoundedButton("PLAY");
        playButton.setFont(Theme.font(Font.BOLD, 16));
        playButton.setPreferredSize(new Dimension(170, 48));
        playButton.addActionListener(e -> onPlay());

        JPanel bottom = new JPanel(new BorderLayout());
        bottom.setOpaque(false);
        bottom.setBorder(new EmptyBorder(18, 0, 0, 0));
        bottom.add(selectedStageLabel, BorderLayout.CENTER);
        bottom.add(playButton, BorderLayout.EAST);

        JPanel stack = new JPanel(new BorderLayout());
        stack.setOpaque(false);
        stack.add(stageRow, BorderLayout.NORTH);
        stack.add(bottom, BorderLayout.SOUTH);

        JPanel wrapper = new JPanel(new BorderLayout());
        wrapper.setOpaque(false);
        wrapper.add(stack, BorderLayout.NORTH); // NORTH keeps the cards and button from stretching tall

        return section("Stage Select", wrapper);
    }

    private JPanel section(String title, JPanel body) {
        JPanel section = new JPanel(new BorderLayout(0, 12));
        section.setOpaque(false);
        section.add(Theme.label(title, Theme.HEADING, Theme.TEXT), BorderLayout.NORTH);
        section.add(body, BorderLayout.CENTER);
        return section;
    }

    // ------------------------------------------------------------------
    //  Data
    // ------------------------------------------------------------------

    /** Reloads stats and stages from the database. Call this again after every match. */
    public void refreshData() {
        List<Stage> stages;
        try {
            stats = statsRepo.getStats(user.getUserId());
            stages = stageRepo.getAllStages();
        } catch (DataException ex) {
            Dialogs.showDataError(this, ex);
            return;
        }

        matchesCard.setValue(String.valueOf(stats.getMatchesPlayed()));
        winsCard.setValue(String.valueOf(stats.getWins()));
        lossesCard.setValue(String.valueOf(stats.getLosses()));
        winRateCard.setValue(Format.percent(stats.getWinRate()));
        highScoreCard.setValue(Format.number(stats.getHighestScore()));
        fastestWinCard.setValue(Format.duration(stats.getFastestWinSeconds()));
        if (stats.getMostUsedTower() == null) {
            towerCard.setValue("None yet", Theme.TEXT_MUTED);
        } else {
            towerCard.setValue(stats.getMostUsedTower(), Color.decode(stats.getMostUsedTowerColor()));
        }
        int unlocked = Math.min(stats.getUnlockedStage(), stages.size());
        progressCard.setValue(unlocked + " / " + stages.size());
        coinsLabel.setText(Format.number(stats.getCoins()));

        buildStageCards(stages);
    }

    private void buildStageCards(List<Stage> stages) {
        stageRow.removeAll();
        stageCards.clear();

        Stage defaultStage = null;
        for (Stage stage : stages) {
            boolean locked = stage.getNumber() > stats.getUnlockedStage();
            StageCard card = new StageCard(stage, locked);
            card.setOnSelect(this::selectStage);
            stageCards.add(card);
            stageRow.add(card);
            if (!locked) {
                defaultStage = stage; // the highest unlocked stage
            }
        }

        // Keep the previous choice if it is still unlocked, otherwise pick the newest stage
        boolean keepPrevious = selectedStage != null && selectedStage.getNumber() <= stats.getUnlockedStage();
        Stage toSelect = keepPrevious ? findStage(stages, selectedStage.getNumber()) : defaultStage;
        if (toSelect != null) {
            selectStage(toSelect);
        }
        stageRow.revalidate();
        stageRow.repaint();
    }

    private Stage findStage(List<Stage> stages, int number) {
        for (Stage s : stages) {
            if (s.getNumber() == number) {
                return s;
            }
        }
        return null;
    }

    private void selectStage(Stage stage) {
        selectedStage = stage;
        for (StageCard card : stageCards) {
            card.setSelected(card.getStage().getNumber() == stage.getNumber());
        }
        selectedStageLabel.setText("<html>Selected: <b style='color:#F1F5F9'>Stage " + stage.getNumber()
                + " - " + stage.getName() + "</b>&nbsp;&nbsp;&middot;&nbsp;&nbsp;" + stage.getDescription() + "</html>");
    }

    // ------------------------------------------------------------------
    //  Navigation / button actions
    // ------------------------------------------------------------------

    private void showView(String card) {
        cardLayout.show(content, card);
        if (CARD_LEADERBOARD.equals(card)) {
            leaderboardPanel.reload(); // always show the latest scores
        }
        highlightNav(CARD_LEADERBOARD.equals(card) ? "Leaderboard" : "Home");
    }

    private void highlightNav(String active) {
        for (Map.Entry<String, RoundedButton> entry : navButtons.entrySet()) {
            entry.getValue().setBaseColor(entry.getKey().equals(active) ? Theme.ACCENT : Theme.TRANSPARENT);
        }
    }

    private void onPlay() {
        if (!Session.isLoggedIn()) {
            onLogout();
            return;
        }
        if (selectedStage == null) {
            Dialogs.showWarning(this, "Play", "Please select a stage first.");
            showView(CARD_HOME);
            return;
        }
        // PHASE 2: this will open TowerSelectFrame -> GameFrame, then call refreshData() after the match.
        Dialogs.showInfo(this, "Play",
                "Stage " + selectedStage.getNumber() + ": " + selectedStage.getName() + " selected.\n\n"
                + "Tower selection and the battle screen will be added in Phase 2 (Game Mechanics).");
    }

    private void onUpgrades() {
        // PHASE 3: this will open UpgradeFrame.
        Dialogs.showInfo(this, "Upgrades",
                "You have " + Format.number(stats.getCoins()) + " coins.\n\n"
                + "The Upgrades screen (Level 1 to 3 tower upgrades) will be added in Phase 3.");
    }

    private void onProfile() {
        new ProfileDialog(this, user).setVisible(true);
    }

    private void onLogout() {
        if (Session.isLoggedIn() && !Dialogs.confirm(this, "Logout", "Are you sure you want to log out?")) {
            return;
        }
        Session.logout();
        dispose();
        new LoginFrame().setVisible(true);
    }

    /** Small gold coin drawn with Graphics2D. */
    private static class CoinIcon extends JComponent {

        CoinIcon() {
            setPreferredSize(new Dimension(18, 18));
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(new Color(0xCA8A04));
            g2.fillOval(0, 0, 18, 18);
            g2.setColor(Theme.GOLD);
            g2.fillOval(2, 2, 14, 14);
            g2.setColor(new Color(0xCA8A04));
            g2.fillRect(8, 5, 2, 8);
            g2.dispose();
        }
    }
}
