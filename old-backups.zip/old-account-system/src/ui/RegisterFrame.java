package ui;

import db.DataException;
import db.Repositories;
import db.UserRepository;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import ui.components.BrandPanel;
import ui.components.FormPanel;
import ui.components.RoundedButton;
import ui.components.Theme;
import util.Dialogs;
import util.Validator;

/** Create a new account: username, email, password, confirm password. */
public class RegisterFrame extends JFrame {

    private static final int FIELD_WIDTH = 340;

    private final UserRepository users = Repositories.users();
    private final JTextField usernameField = Theme.textField();
    private final JTextField emailField = Theme.textField();
    private final JPasswordField passwordField = Theme.passwordField();
    private final JPasswordField confirmField = Theme.passwordField();
    private final JLabel strengthLabel = Theme.label(" ", Theme.SMALL_BOLD, Theme.TEXT_MUTED);

    public RegisterFrame() {
        setTitle("Department Tower Clash - Create Account");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(980, 680);
        setResizable(false);
        setLocationRelativeTo(null);

        JPanel root = new JPanel(new GridLayout(1, 2));
        root.add(new BrandPanel());
        root.add(buildFormSide());
        setContentPane(root);
    }

    private JPanel buildFormSide() {
        JPanel side = new JPanel(new GridBagLayout());
        side.setBackground(Theme.BG_DARK);

        FormPanel form = new FormPanel();
        form.addRow(Theme.label("Create your account", Theme.TITLE, Theme.TEXT), 0);
        form.addRow(Theme.label("Join the battle for your department.", Theme.BODY, Theme.TEXT_MUTED), 6);

        addField(form, "Username", usernameField, 26);
        addField(form, "Email", emailField, 12);
        addField(form, "Password", passwordField, 12);
        form.addRow(strengthLabel, 4);
        addField(form, "Confirm Password", confirmField, 14);

        char echo = passwordField.getEchoChar();
        JCheckBox showPassword = form.addRow(Theme.checkBox("Show passwords"), 8);
        showPassword.addActionListener(e -> {
            char c = showPassword.isSelected() ? (char) 0 : echo;
            passwordField.setEchoChar(c);
            confirmField.setEchoChar(c);
        });

        RoundedButton registerButton = new RoundedButton("CREATE ACCOUNT");
        registerButton.setPreferredSize(new Dimension(FIELD_WIDTH, 46));
        registerButton.addActionListener(e -> doRegister());
        form.addRow(registerButton, 20);
        getRootPane().setDefaultButton(registerButton);

        JPanel loginRow = new JPanel(new FlowLayout(FlowLayout.CENTER, 0, 0));
        loginRow.setOpaque(false);
        loginRow.add(Theme.label("Already have an account?", Theme.SMALL, Theme.TEXT_MUTED));
        JButton loginLink = Theme.linkButton("Log in");
        loginLink.addActionListener(e -> backToLogin(""));
        loginRow.add(loginLink);
        form.addRow(loginRow, 18);

        // Live password strength indicator
        passwordField.getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) {
                updateStrength();
            }

            @Override
            public void removeUpdate(DocumentEvent e) {
                updateStrength();
            }

            @Override
            public void changedUpdate(DocumentEvent e) {
                updateStrength();
            }
        });
        updateStrength();

        side.add(form);
        return side;
    }

    private void addField(FormPanel form, String labelText, JComponent field, int gapAbove) {
        form.addRow(Theme.label(labelText, Theme.SMALL_BOLD, Theme.TEXT_MUTED), gapAbove);
        field.setPreferredSize(new Dimension(FIELD_WIDTH, 42));
        form.addRow(field, 5);
    }

    private void updateStrength() {
        String password = new String(passwordField.getPassword());
        switch (Validator.passwordStrength(password)) {
            case 0 -> {
                strengthLabel.setText("At least 8 characters, with letters and numbers");
                strengthLabel.setForeground(Theme.TEXT_MUTED);
            }
            case 1 -> {
                strengthLabel.setText("Strength: Weak");
                strengthLabel.setForeground(Theme.DANGER);
            }
            case 2 -> {
                strengthLabel.setText("Strength: Medium");
                strengthLabel.setForeground(Theme.WARNING);
            }
            default -> {
                strengthLabel.setText("Strength: Strong");
                strengthLabel.setForeground(Theme.SUCCESS);
            }
        }
    }

    private void doRegister() {
        String username = usernameField.getText().trim();
        String email = emailField.getText().trim();
        String password = new String(passwordField.getPassword());
        String confirm = new String(confirmField.getPassword());

        // 1. Validate the inputs
        if (showIfInvalid(Validator.validateUsername(username), usernameField)) return;
        if (showIfInvalid(Validator.validateEmail(email), emailField)) return;
        if (showIfInvalid(Validator.validatePassword(password), passwordField)) return;
        if (!password.equals(confirm)) {
            showIfInvalid("Passwords do not match. Please type the same password twice.", confirmField);
            return;
        }

        // 2. Check for duplicates, then save
        try {
            if (users.usernameExists(username)) {
                showIfInvalid("The username \"" + username + "\" is already taken.", usernameField);
                return;
            }
            if (users.emailExists(email)) {
                showIfInvalid("This email is already registered. Try logging in instead.", emailField);
                return;
            }
            users.register(username, email, password);
            Dialogs.showInfo(this, "Account Created",
                    "Welcome, " + username + "! Your account was created.\nYou can now log in.");
            backToLogin(username);
        } catch (DataException ex) {
            Dialogs.showDataError(this, ex);
        }
    }

    /** Shows the error (if any) and moves the cursor to the field that needs fixing. */
    private boolean showIfInvalid(String error, JComponent field) {
        if (error == null) {
            return false;
        }
        Dialogs.showError(this, "Register", error);
        field.requestFocus();
        return true;
    }

    private void backToLogin(String username) {
        dispose();
        new LoginFrame(username).setVisible(true);
    }
}
