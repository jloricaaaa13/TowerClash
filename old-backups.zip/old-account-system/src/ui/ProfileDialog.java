package ui;

import db.DataException;
import db.Repositories;
import db.UserRepository;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import javax.swing.JComponent;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JSeparator;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;
import model.User;
import ui.components.FormPanel;
import ui.components.RoundedButton;
import ui.components.Theme;
import util.Dialogs;
import util.Format;
import util.Validator;

/** Shows the player's account info and lets them change their password. */
public class ProfileDialog extends JDialog {

    private final User user;
    private final UserRepository users = Repositories.users();
    private final JPasswordField currentField = Theme.passwordField();
    private final JPasswordField newField = Theme.passwordField();
    private final JPasswordField confirmField = Theme.passwordField();

    public ProfileDialog(JFrame owner, User user) {
        super(owner, "Profile", true); // true = modal (blocks the dashboard while open)
        this.user = user;
        setSize(440, 640);
        setResizable(false);
        setLocationRelativeTo(owner);

        JPanel root = new JPanel(new BorderLayout());
        root.setBackground(Theme.BG_DARK);
        root.setBorder(new EmptyBorder(24, 36, 24, 36));
        root.add(buildContent(), BorderLayout.NORTH);
        setContentPane(root);
    }

    private FormPanel buildContent() {
        FormPanel form = new FormPanel();

        Avatar avatar = new Avatar(user.getUsername());
        avatar.setPreferredSize(new Dimension(80, 80));
        form.addRow(avatar, 0);

        form.addRow(centered(Theme.label(user.getUsername(), Theme.font(Font.BOLD, 22), Theme.TEXT)), 10);
        form.addRow(centered(Theme.label(user.getEmail(), Theme.BODY, Theme.TEXT_MUTED)), 2);
        form.addRow(centered(Theme.label("Member since " + Format.date(user.getCreatedAt()), Theme.SMALL, Theme.TEXT_MUTED)), 4);

        JSeparator line = new JSeparator();
        line.setForeground(Theme.BORDER);
        line.setBackground(Theme.BG_DARK);
        form.addRow(line, 20);

        form.addRow(Theme.label("Change Password", Theme.HEADING, Theme.TEXT), 16);
        addPasswordField(form, "Current Password", currentField, 12);
        addPasswordField(form, "New Password", newField, 10);
        addPasswordField(form, "Confirm New Password", confirmField, 10);

        RoundedButton save = new RoundedButton("UPDATE PASSWORD");
        save.setPreferredSize(new Dimension(0, 42));
        save.addActionListener(e -> changePassword());
        form.addRow(save, 18);

        RoundedButton close = new RoundedButton("Close", Theme.BG_INPUT);
        close.setPreferredSize(new Dimension(0, 38));
        close.addActionListener(e -> dispose());
        form.addRow(close, 8);
        return form;
    }

    private void addPasswordField(FormPanel form, String label, JPasswordField field, int gapAbove) {
        form.addRow(Theme.label(label, Theme.SMALL_BOLD, Theme.TEXT_MUTED), gapAbove);
        field.setPreferredSize(new Dimension(0, 40));
        form.addRow(field, 4);
    }

    private JComponent centered(JLabel label) {
        label.setHorizontalAlignment(SwingConstants.CENTER);
        return label;
    }

    private void changePassword() {
        String current = new String(currentField.getPassword());
        String newPassword = new String(newField.getPassword());
        String confirm = new String(confirmField.getPassword());

        if (current.isEmpty()) {
            Dialogs.showError(this, "Change Password", "Please enter your current password.");
            currentField.requestFocus();
            return;
        }
        String error = Validator.validatePassword(newPassword);
        if (error != null) {
            Dialogs.showError(this, "Change Password", error);
            newField.requestFocus();
            return;
        }
        if (!newPassword.equals(confirm)) {
            Dialogs.showError(this, "Change Password", "The new passwords do not match.");
            confirmField.requestFocus();
            return;
        }
        if (newPassword.equals(current)) {
            Dialogs.showError(this, "Change Password", "The new password must be different from the current one.");
            newField.requestFocus();
            return;
        }

        try {
            if (users.changePassword(user.getUserId(), current, newPassword)) {
                Dialogs.showInfo(this, "Change Password", "Your password was updated.");
                currentField.setText("");
                newField.setText("");
                confirmField.setText("");
            } else {
                Dialogs.showError(this, "Change Password", "Your current password is incorrect.");
                currentField.requestFocus();
            }
        } catch (DataException ex) {
            Dialogs.showDataError(this, ex);
        }
    }

    /** A colored circle with the first letter of the username. */
    private static class Avatar extends JComponent {

        private final String initial;

        Avatar(String username) {
            this.initial = username.substring(0, 1).toUpperCase();
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
            int size = Math.min(getWidth(), getHeight());
            int x = (getWidth() - size) / 2;
            g2.setColor(Theme.ACCENT);
            g2.fillOval(x, 0, size, size);
            g2.setColor(Color.WHITE);
            g2.setFont(Theme.font(Font.BOLD, size / 2));
            FontMetrics fm = g2.getFontMetrics();
            g2.drawString(initial, x + (size - fm.stringWidth(initial)) / 2,
                    (size - fm.getHeight()) / 2 + fm.getAscent());
            g2.dispose();
        }
    }
}
