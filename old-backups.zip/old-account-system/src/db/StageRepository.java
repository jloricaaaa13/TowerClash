package db;

import java.util.List;
import model.Stage;

/** The list of campaign stages. */
public interface StageRepository {

    List<Stage> getAllStages();
}
