package db;

import db.memory.InMemoryStageRepository;
import db.memory.InMemoryStatsRepository;
import db.memory.InMemoryUserRepository;

/**
 * The ONE place that decides where data is stored.
 *
 * Right now: in memory (no database needed, data resets when the app closes).
 * Later: replace the three "new InMemory..." with the MySQL versions,
 * and every screen will automatically use the database.
 */
public final class Repositories {

    private static final UserRepository USERS = new InMemoryUserRepository();
    private static final StatsRepository STATS = new InMemoryStatsRepository();
    private static final StageRepository STAGES = new InMemoryStageRepository();

    private Repositories() {
    }

    public static UserRepository users() {
        return USERS;
    }

    public static StatsRepository stats() {
        return STATS;
    }

    public static StageRepository stages() {
        return STAGES;
    }

    /** Shown on the login screen so it is clear no database is connected yet. */
    public static boolean isOfflineMode() {
        return true;
    }
}
