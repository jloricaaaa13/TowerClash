package db;

import java.util.List;
import model.LeaderboardEntry;
import model.LeaderboardFilter;
import model.PlayerStats;

/** Player statistics and the leaderboard. */
public interface StatsRepository {

    PlayerStats getStats(int userId);

    /** Top players for the selected filter (e.g. limit = 10 for the Top 10). */
    List<LeaderboardEntry> getLeaderboard(LeaderboardFilter filter, int limit);

    /** The player's rank for the filter, or -1 if they are not on the leaderboard yet. */
    int getPlayerRank(int userId, LeaderboardFilter filter);
}
