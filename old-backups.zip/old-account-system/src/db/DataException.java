package db;

/**
 * Thrown when data cannot be loaded or saved.
 * The MySQL version (added later) will wrap SQLException in this,
 * so the screens only ever need to catch one kind of error.
 */
public class DataException extends RuntimeException {

    public DataException(String message) {
        super(message);
    }

    public DataException(String message, Throwable cause) {
        super(message, cause);
    }
}
