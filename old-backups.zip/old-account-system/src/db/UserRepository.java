package db;

import model.User;

/**
 * Everything the app can do with player accounts.
 *
 * Abstraction: the screens only know this interface, not HOW the data is stored.
 * Right now InMemoryUserRepository keeps accounts in memory; later a
 * MySqlUserRepository will save them in XAMPP MySQL, and no screen has to change.
 */
public interface UserRepository {

    boolean usernameExists(String username);

    boolean emailExists(String email);

    /** Creates a new account and returns it. */
    User register(String username, String email, String password);

    /** Returns the User if the username/email and password are correct, otherwise null. */
    User login(String usernameOrEmail, String password);

    /** Returns true if changed, false if the current password is wrong. */
    boolean changePassword(int userId, String currentPassword, String newPassword);
}
