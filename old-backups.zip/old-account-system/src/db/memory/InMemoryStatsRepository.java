package db.memory;

import db.StatsRepository;
import db.memory.MemoryDatabase.StatsRow;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import model.LeaderboardEntry;
import model.LeaderboardFilter;
import model.PlayerStats;

/** Stats and leaderboard computed from the in-memory lists. */
public class InMemoryStatsRepository implements StatsRepository {

    private final MemoryDatabase db = MemoryDatabase.get();

    @Override
    public PlayerStats getStats(int userId) {
        StatsRow row = db.findStats(userId);
        return row == null ? new PlayerStats() : row.stats;
    }

    @Override
    public List<LeaderboardEntry> getLeaderboard(LeaderboardFilter filter, int limit) {
        List<StatsRow> sorted = sortedRows(filter);
        List<LeaderboardEntry> entries = new ArrayList<>();
        for (int i = 0; i < sorted.size() && i < limit; i++) {
            StatsRow row = sorted.get(i);
            PlayerStats s = row.stats;
            entries.add(new LeaderboardEntry(
                    i + 1,
                    row.userId,
                    db.usernameOf(row.userId),
                    s.getHighestScore(),
                    s.getWins(),
                    s.getFastestWinSeconds(),
                    dateFor(filter, row)));
        }
        return entries;
    }

    @Override
    public int getPlayerRank(int userId, LeaderboardFilter filter) {
        List<StatsRow> sorted = sortedRows(filter);
        for (int i = 0; i < sorted.size(); i++) {
            if (sorted.get(i).userId == userId) {
                return i + 1;
            }
        }
        return -1;
    }

    /** Same rules as the SQL version: filter who qualifies, then sort. */
    private List<StatsRow> sortedRows(LeaderboardFilter filter) {
        List<StatsRow> rows = new ArrayList<>();
        Comparator<StatsRow> order;

        switch (filter) {
            case MOST_WINS -> {
                for (StatsRow r : db.statsRows) {
                    if (r.stats.getWins() > 0) rows.add(r);
                }
                order = Comparator.comparingInt((StatsRow r) -> r.stats.getWins()).reversed()
                        .thenComparing(Comparator.comparingInt((StatsRow r) -> r.stats.getHighestScore()).reversed());
            }
            case FASTEST_WIN -> {
                for (StatsRow r : db.statsRows) {
                    if (r.stats.getFastestWinSeconds() != null) rows.add(r);
                }
                order = Comparator.comparingInt((StatsRow r) -> r.stats.getFastestWinSeconds());
            }
            default -> {
                for (StatsRow r : db.statsRows) {
                    if (r.stats.getHighestScore() > 0) rows.add(r);
                }
                order = Comparator.comparingInt((StatsRow r) -> r.stats.getHighestScore()).reversed();
            }
        }
        rows.sort(order.thenComparingInt(r -> r.userId));
        return rows;
    }

    private LocalDateTime dateFor(LeaderboardFilter filter, StatsRow row) {
        return switch (filter) {
            case MOST_WINS -> row.lastPlayedAt;
            case FASTEST_WIN -> row.fastestWinDate;
            default -> row.highestScoreDate;
        };
    }
}
