package db.memory;

import db.StageRepository;
import java.util.List;
import model.Stage;

/** The 5 stages, hard-coded for now (same values as the stages table in the SQL script). */
public class InMemoryStageRepository implements StageRepository {

    private static final List<Stage> STAGES = List.of(
            new Stage(1, "Freshman Rush", "A slow enemy that is still learning the ropes.", 1, 1.00, 50),
            new Stage(2, "Sophomore Siege", "The enemy spawns units faster.", 2, 1.20, 75),
            new Stage(3, "Junior Clash", "The enemy starts upgrading its tower.", 3, 1.45, 100),
            new Stage(4, "Senior Showdown", "A smart enemy that saves energy for big pushes.", 4, 1.75, 150),
            new Stage(5, "Dean's Gauntlet", "The ultimate test. The enemy uses every trick it has.", 5, 2.10, 250));

    @Override
    public List<Stage> getAllStages() {
        return STAGES;
    }
}
