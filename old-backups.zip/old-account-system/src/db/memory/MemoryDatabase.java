package db.memory;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import model.PlayerStats;
import model.User;
import util.PasswordUtil;

/**
 * A pretend database that lives in memory (ArrayLists instead of tables).
 * Everything here is lost when the program closes - that is expected until
 * we connect MySQL.
 *
 * It starts with a few demo players so the Dashboard and Leaderboard have data.
 * Demo login:  demo / demo1234   (the other demo players also use demo1234)
 */
public final class MemoryDatabase {

    public static final String DEMO_PASSWORD = "demo1234";

    /** One row of the "users" table. */
    static class AccountRow {
        final User user;
        String passwordHash;
        String salt;

        AccountRow(User user, String passwordHash, String salt) {
            this.user = user;
            this.passwordHash = passwordHash;
            this.salt = salt;
        }
    }

    /** One row of the "player_stats" table (plus the dates the leaderboard shows). */
    static class StatsRow {
        final int userId;
        final PlayerStats stats;
        LocalDateTime highestScoreDate;
        LocalDateTime fastestWinDate;
        LocalDateTime lastPlayedAt;

        StatsRow(int userId, PlayerStats stats) {
            this.userId = userId;
            this.stats = stats;
        }
    }

    private static final MemoryDatabase INSTANCE = new MemoryDatabase();

    final List<AccountRow> accounts = new ArrayList<>();
    final List<StatsRow> statsRows = new ArrayList<>();
    private int nextUserId = 1;

    private MemoryDatabase() {
        seedDemoPlayers();
    }

    static MemoryDatabase get() {
        return INSTANCE;
    }

    /** Works like INSERT INTO users + INSERT INTO player_stats. */
    synchronized AccountRow addAccount(String username, String email, String password) {
        String salt = PasswordUtil.generateSalt();
        String hash = PasswordUtil.hashPassword(password, salt);
        User user = new User(nextUserId++, username, email, LocalDateTime.now());
        AccountRow account = new AccountRow(user, hash, salt);
        accounts.add(account);

        PlayerStats stats = new PlayerStats();
        stats.setCoins(100);       // starting coins
        stats.setUnlockedStage(1); // only Stage 1 is open for new players
        statsRows.add(new StatsRow(user.getUserId(), stats));
        return account;
    }

    AccountRow findAccount(String usernameOrEmail) {
        for (AccountRow a : accounts) {
            if (a.user.getUsername().equalsIgnoreCase(usernameOrEmail)
                    || a.user.getEmail().equalsIgnoreCase(usernameOrEmail)) {
                return a;
            }
        }
        return null;
    }

    AccountRow findAccount(int userId) {
        for (AccountRow a : accounts) {
            if (a.user.getUserId() == userId) {
                return a;
            }
        }
        return null;
    }

    StatsRow findStats(int userId) {
        for (StatsRow s : statsRows) {
            if (s.userId == userId) {
                return s;
            }
        }
        return null;
    }

    String usernameOf(int userId) {
        AccountRow a = findAccount(userId);
        return a == null ? "?" : a.user.getUsername();
    }

    // ------------------------------------------------------------------
    //  Demo data
    // ------------------------------------------------------------------

    private void seedDemoPlayers() {
        //        username    email              played wins losses score  fastest coins stage tower          color
        addDemo("demo",     "demo@school.edu",     18, 12, 6,  15420, 143, 1250, 3, "Comp Sci",    "#EAB308", 1);
        addDemo("alex_hm",  "alex@school.edu",     24, 19, 5,  18300, 121, 2100, 5, "Hospitality", "#DC2626", 2);
        addDemo("bea_educ", "bea@school.edu",      20, 15, 5,  16750, 158, 1500, 4, "Education",   "#2563EB", 3);
        addDemo("carlo_cs", "carlo@school.edu",    15, 9,  6,  12100, 137, 800,  3, "Comp Sci",    "#EAB308", 5);
        addDemo("mika",     "mika@school.edu",     10, 6,  4,  9800,  176, 520,  2, "Education",   "#2563EB", 6);
        addDemo("rj_22",    "rj@school.edu",       8,  4,  4,  7400,  199, 300,  2, "Hospitality", "#DC2626", 8);
        addDemo("sam",      "sam@school.edu",      5,  2,  3,  5200,  224, 180,  2, "Comp Sci",    "#EAB308", 9);
        addDemo("newbie",   "newbie@school.edu",   2,  0,  2,  1300,  0,   120,  1, "Education",   "#2563EB", 1);
    }

    private void addDemo(String username, String email, int played, int wins, int losses, int score,
                         int fastestSeconds, int coins, int stage, String tower, String color, int daysAgo) {
        AccountRow account = addAccount(username, email, DEMO_PASSWORD);
        StatsRow row = findStats(account.user.getUserId());
        PlayerStats s = row.stats;
        s.setMatchesPlayed(played);
        s.setWins(wins);
        s.setLosses(losses);
        s.setHighestScore(score);
        s.setFastestWinSeconds(wins > 0 ? fastestSeconds : null);
        s.setCoins(coins);
        s.setUnlockedStage(stage);
        s.setMostUsedTower(tower);
        s.setMostUsedTowerColor(color);

        LocalDateTime when = LocalDateTime.now().minusDays(daysAgo);
        row.highestScoreDate = when;
        row.fastestWinDate = wins > 0 ? when.minusDays(1) : null;
        row.lastPlayedAt = when;
    }
}
