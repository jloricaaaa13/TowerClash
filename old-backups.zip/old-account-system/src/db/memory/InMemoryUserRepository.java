package db.memory;

import db.DataException;
import db.UserRepository;
import db.memory.MemoryDatabase.AccountRow;
import model.User;
import util.PasswordUtil;

/**
 * Account system without a database.
 * Passwords are still hashed with SHA-256 + salt, exactly like the MySQL version will do.
 */
public class InMemoryUserRepository implements UserRepository {

    private final MemoryDatabase db = MemoryDatabase.get();

    @Override
    public boolean usernameExists(String username) {
        for (AccountRow a : db.accounts) {
            if (a.user.getUsername().equalsIgnoreCase(username)) {
                return true;
            }
        }
        return false;
    }

    @Override
    public boolean emailExists(String email) {
        for (AccountRow a : db.accounts) {
            if (a.user.getEmail().equalsIgnoreCase(email)) {
                return true;
            }
        }
        return false;
    }

    @Override
    public User register(String username, String email, String password) {
        if (usernameExists(username) || emailExists(email)) {
            throw new DataException("That username or email is already registered.");
        }
        return db.addAccount(username, email, password).user;
    }

    @Override
    public User login(String usernameOrEmail, String password) {
        AccountRow account = db.findAccount(usernameOrEmail);
        if (account == null) {
            return null; // no such user
        }
        if (!PasswordUtil.verifyPassword(password, account.salt, account.passwordHash)) {
            return null; // wrong password
        }
        return account.user;
    }

    @Override
    public boolean changePassword(int userId, String currentPassword, String newPassword) {
        AccountRow account = db.findAccount(userId);
        if (account == null || !PasswordUtil.verifyPassword(currentPassword, account.salt, account.passwordHash)) {
            return false;
        }
        account.salt = PasswordUtil.generateSalt();
        account.passwordHash = PasswordUtil.hashPassword(newPassword, account.salt);
        return true;
    }
}
