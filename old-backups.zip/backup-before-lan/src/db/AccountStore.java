package db;

import java.util.List;
import model.Match;
import model.PlayerProgress;

/**
 * Where accounts and progress are saved.
 *
 * There are two ways (both follow this same interface - polymorphism):
 *   MySqlAccountStore - the XAMPP MySQL database (the main way)
 *   LocalAccountStore - files on this computer, used automatically when MySQL is not running
 *
 * The rest of the game only talks to "AccountStore", so it does not care which one is used.
 */
public interface AccountStore {

    /** Shown on the Login screen and Dashboard, e.g. "MYSQL DATABASE". */
    String getName();

    /** true = MySQL database, false = files on this computer. */
    boolean isDatabase();

    Account register(String username, String email, String password) throws AccountException;

    Account login(String username, String password) throws AccountException;

    PlayerProgress loadProgress(Account account) throws AccountException;

    void saveProgress(Account account, PlayerProgress progress) throws AccountException;

    /** Remembers one finished match (match history). */
    void recordMatch(Account account, Match match) throws AccountException;

    /** The best players, best first. */
    List<LeaderboardEntry> getLeaderboard(LeaderboardType type, int limit) throws AccountException;

    /** The player's place on the leaderboard (1 = first), or 0 if they have no score yet. */
    int getRank(Account account, LeaderboardType type) throws AccountException;
}
