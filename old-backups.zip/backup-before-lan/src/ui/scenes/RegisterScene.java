package ui.scenes;

import db.AccountException;
import db.Validator;
import java.awt.Color;
import java.awt.Graphics2D;
import ui.GameWindow;
import ui.pixel.Landscape;
import ui.pixel.Palette;
import ui.pixel.PixelArt;
import ui.pixel.PixelButton;
import ui.pixel.PixelFont;
import ui.pixel.PixelTextField;

/**
 * Make a new account: username, email, password (typed twice).
 * Every field is checked before saving, and the reason is shown if something is wrong.
 */
public class RegisterScene extends PixelScene {

    private static final int BOX_X = 36;
    private static final int BOX_Y = 24;
    private static final int BOX_W = 248;
    private static final int BOX_H = 128;
    private static final int LABEL_X = BOX_X + 14;
    private static final int FIELD_X = BOX_X + 84;
    private static final int FIELD_W = BOX_W - 98;
    private static final int ROW = 19;

    private final Landscape landscape = new Landscape(162, new int[]{8, 310}, new int[]{});
    private final PixelTextField usernameField;
    private final PixelTextField emailField;
    private final PixelTextField passwordField;
    private final PixelTextField confirmField;
    private String message = "";

    public RegisterScene(GameWindow window) {
        super(window);
        int y = BOX_Y + 24;
        usernameField = addWidget(new PixelTextField(FIELD_X, y, FIELD_W, Validator.USERNAME_MAX, false)
                .withHint("3-16 LETTERS/NUMBERS"));
        emailField = addWidget(new PixelTextField(FIELD_X, y + ROW, FIELD_W, Validator.EMAIL_MAX, false)
                .withHint("JUAN@SCHOOL.EDU"));
        passwordField = addWidget(new PixelTextField(FIELD_X, y + ROW * 2, FIELD_W, Validator.PASSWORD_MAX, true)
                .withHint("6+ LETTERS AND NUMBERS"));
        confirmField = addWidget(new PixelTextField(FIELD_X, y + ROW * 3, FIELD_W, Validator.PASSWORD_MAX, true)
                .withHint("TYPE IT AGAIN"));
        usernameField.setOnSubmit(() -> setTypingField(emailField));
        emailField.setOnSubmit(() -> setTypingField(passwordField));
        passwordField.setOnSubmit(() -> setTypingField(confirmField));
        confirmField.setOnSubmit(this::create);

        addWidget(new PixelButton("CREATE ACCOUNT", BOX_X + 14, BOX_Y + BOX_H - 21, 100, 15, this::create));
        addWidget(new PixelButton("BACK", BOX_X + BOX_W - 78, BOX_Y + BOX_H - 21, 64, 15, window::showLogin));
    }

    @Override
    public void onShow() {
        usernameField.clear();
        emailField.clear();
        passwordField.clear();
        confirmField.clear();
        message = "";
        super.onShow();
        setTypingField(usernameField);
    }

    private void create() {
        String username = usernameField.getText().trim();
        String email = emailField.getText().trim();
        String password = passwordField.getText();

        // Check every box first; stop at the first problem and put the cursor there
        String problem = Validator.checkUsername(username);
        PixelTextField where = usernameField;
        if (problem == null) {
            problem = Validator.checkEmail(email);
            where = emailField;
        }
        if (problem == null) {
            problem = Validator.checkPassword(password);
            where = passwordField;
        }
        if (problem == null && !password.equals(confirmField.getText())) {
            problem = "THE TWO PASSWORDS ARE NOT THE SAME";
            where = confirmField;
        }
        if (problem != null) {
            message = problem;
            setTypingField(where);
            return;
        }
        try {
            window.register(username, email, password); // logs in and opens the Dashboard
        } catch (AccountException e) {
            message = e.getMessage();
            setTypingField(e.getMessage().contains("EMAIL") ? emailField : usernameField);
        }
    }

    @Override
    protected void onEscape() {
        window.showLogin();
    }

    @Override
    protected void paintScene(Graphics2D g) {
        landscape.draw(g, tick);
        PixelFont.drawCentered(g, "NEW PLAYER", W / 2, 6, 2, Palette.TEXT_WHITE, Palette.TEXT_DARK);

        PixelArt.board(g, BOX_X, BOX_Y, BOX_W, BOX_H);
        PixelFont.drawCentered(g, "CREATE YOUR ACCOUNT", W / 2, BOX_Y + 8, 1, Palette.TEXT_GOLD, Palette.TEXT_DARK);
        String[] labels = {"USERNAME", "EMAIL", "PASSWORD", "CONFIRM"};
        for (int i = 0; i < labels.length; i++) {
            PixelFont.draw(g, labels[i], LABEL_X, BOX_Y + 27 + ROW * i, 1, Palette.TEXT_DARK);
        }
        if (!message.isEmpty()) {
            PixelFont.drawCentered(g, message, W / 2, BOX_Y + 98, 1, Palette.HP_LOW, null);
        } else {
            PixelFont.drawCentered(g, "YOUR PROGRESS WILL BE SAVED TO THIS ACCOUNT", W / 2, BOX_Y + 98, 1,
                    Palette.WOOD_OUTLINE, null);
        }
        boolean db = window.getAccounts().isDatabase();
        PixelFont.drawCentered(g, "SAVING TO: " + window.getAccounts().getName(), W / 2, 158, 1,
                db ? Palette.TEXT_ON : Palette.TEXT_OFF, Palette.TEXT_DARK);
    }
}
