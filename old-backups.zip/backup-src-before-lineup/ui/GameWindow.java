package ui;

import audio.SoundManager;
import db.FileProgressStore;
import db.ProgressStore;
import java.awt.CardLayout;
import java.awt.Dimension;
import java.awt.GraphicsEnvironment;
import java.awt.Insets;
import java.awt.Rectangle;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.HashMap;
import java.util.Map;
import javax.swing.JFrame;
import javax.swing.JPanel;
import model.Department;
import model.GameSettings;
import model.PlayerProgress;
import model.Stage;
import ui.pixel.Palette;
import ui.pixel.PixelArt;
import ui.scenes.BattleScene;
import ui.scenes.CreditsScene;
import ui.scenes.HowToPlayScene;
import ui.scenes.MainMenuScene;
import ui.scenes.OptionsScene;
import ui.scenes.PixelScene;
import ui.scenes.StageSelectScene;
import ui.scenes.TowerSelectScene;
import ui.scenes.UpgradeScene;

/**
 * The one and only game window. Every screen is a PixelScene inside a CardLayout,
 * so switching screens is instant and there is never more than one window open.
 * It also holds the player's progress (saved through a ProgressStore) and the sound.
 */
public final class GameWindow extends JFrame {

    public static final String MAIN_MENU = "MAIN_MENU";
    public static final String TOWER_SELECT = "TOWER_SELECT";
    public static final String STAGE_SELECT = "STAGE_SELECT";
    public static final String BATTLE = "BATTLE";
    public static final String UPGRADES = "UPGRADES";
    public static final String HOW_TO_PLAY = "HOW_TO_PLAY";
    public static final String OPTIONS = "OPTIONS";
    public static final String CREDITS = "CREDITS";

    private final CardLayout cards = new CardLayout();
    private final JPanel root = new JPanel(cards);
    private final Map<String, PixelScene> scenes = new HashMap<>();
    private final GameSettings settings = new GameSettings();
    private final SoundManager sound = new SoundManager(settings);
    private final ProgressStore progressStore = new FileProgressStore();
    private final BattleScene battleScene;
    private PlayerProgress progress;
    private PixelScene currentScene;
    private Department selectedDepartment;
    private Rectangle windowedBounds;

    public GameWindow() {
        super("Department Tower Clash");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        root.setBackground(Palette.LETTERBOX);
        progress = progressStore.load();

        // Pick the biggest zoom (x2 to x4) that fits the screen, e.g. 1280x720 on a big monitor
        Rectangle usable = GraphicsEnvironment.getLocalGraphicsEnvironment().getMaximumWindowBounds();
        int zoom = Math.max(2, Math.min(4, Math.min(
                (usable.width - 40) / PixelArt.WIDTH, (usable.height - 60) / PixelArt.HEIGHT)));
        root.setPreferredSize(new Dimension(PixelArt.WIDTH * zoom, PixelArt.HEIGHT * zoom));

        battleScene = new BattleScene(this);
        addScene(MAIN_MENU, new MainMenuScene(this));
        addScene(TOWER_SELECT, new TowerSelectScene(this));
        addScene(STAGE_SELECT, new StageSelectScene(this));
        addScene(BATTLE, battleScene);
        addScene(UPGRADES, new UpgradeScene(this));
        addScene(HOW_TO_PLAY, new HowToPlayScene(this));
        addScene(OPTIONS, new OptionsScene(this));
        addScene(CREDITS, new CreditsScene(this));

        setContentPane(root);
        pack();
        Insets in = getInsets();
        setMinimumSize(new Dimension(PixelArt.WIDTH * 2 + in.left + in.right,
                PixelArt.HEIGHT * 2 + in.top + in.bottom));
        setLocationRelativeTo(null);
        if (zoom < 3) {
            setExtendedState(JFrame.MAXIMIZED_BOTH); // small screen: use all of it so the text is bigger
        }

        // Pause the battle when the player alt-tabs or minimizes the game
        addWindowFocusListener(new WindowAdapter() {
            @Override
            public void windowLostFocus(WindowEvent e) {
                if (currentScene != null) {
                    currentScene.onWindowFocusLost();
                }
            }
        });
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowIconified(WindowEvent e) {
                if (currentScene != null) {
                    currentScene.onWindowFocusLost();
                }
            }
        });

        showScene(MAIN_MENU);
    }

    private void addScene(String name, PixelScene scene) {
        scenes.put(name, scene);
        root.add(scene, name);
    }

    public void showScene(String name) {
        if (currentScene != null) {
            currentScene.onHide();
        }
        currentScene = scenes.get(name);
        cards.show(root, name);
        sound.playMusic(BATTLE.equals(name) ? SoundManager.Music.BATTLE : SoundManager.Music.MENU);
        currentScene.onShow();
    }

    public void showMainMenu() {
        showScene(MAIN_MENU);
    }

    public void showTowerSelect() {
        showScene(TOWER_SELECT);
    }

    public void showStageSelect() {
        showScene(STAGE_SELECT);
    }

    public void showUpgrades() {
        showScene(UPGRADES);
    }

    public void showHowToPlay() {
        showScene(HOW_TO_PLAY);
    }

    public void showOptions() {
        showScene(OPTIONS);
    }

    public void showCredits() {
        showScene(CREDITS);
    }

    /** Starts a match on the given stage with the department chosen on the Tower Select screen.
     * @param stage */
    public void startBattle(Stage stage) {
        battleScene.start(selectedDepartment, stage);
        showScene(BATTLE);
    }

    // ---- Progress (save file) ----

    public PlayerProgress getProgress() {
        return progress;
    }

    public boolean hasSavedGame() {
        return progressStore.exists();
    }

    /** NEW GAME: erase the save and start over. */
    public void startNewGame() {
        progressStore.delete();
        progress = new PlayerProgress();
        showTowerSelect();
    }

    public void saveProgress() {
        progressStore.save(progress);
    }

    // ---- Settings and sound ----

    public GameSettings getSettings() {
        return settings;
    }

    public SoundManager getSound() {
        return sound;
    }

    public Department getSelectedDepartment() {
        return selectedDepartment;
    }

    public void setSelectedDepartment(Department selectedDepartment) {
        this.selectedDepartment = selectedDepartment;
    }

    /** Switches between a normal window and borderless fullscreen. */
    public void setFullscreen(boolean fullscreen) {
        if (fullscreen == isUndecorated()) {
            return;
        }
        if (fullscreen) {
            windowedBounds = getBounds();
        }
        dispose(); // a window must be hidden before its border can be removed or added
        setUndecorated(fullscreen);
        if (fullscreen) {
            setExtendedState(JFrame.MAXIMIZED_BOTH);
        } else {
            setExtendedState(JFrame.NORMAL);
            if (windowedBounds != null) {
                setBounds(windowedBounds);
            }
        }
        setVisible(true);
        currentScene.requestFocusInWindow();
    }
}
