package model.units;

import java.awt.Color;
import model.Role;
import model.Side;
import model.Unit;
import ui.pixel.SpritePen;

/** Education - the cheapest and fastest unit. Comes in big groups. */
public class Student extends Unit {

    public Student(Side side) {
        super("Student", Role.FAST, side, 60, 10, 0.7, 10, 32);
    }

    @Override
    protected void drawBody(SpritePen p, int frame, int tick) {
        legs(p, frame, 3, new Color(0x3B5B8C));
        p.rect(-2, 7, 4, 4, new Color(0x2563EB));       // blue uniform
        p.rect(-4, 8, 2, 5, new Color(0xF2B33D));       // backpack
        p.rect(2, 6, 1, 2, SKIN);                       // arm
        head(p, 11, SKIN, new Color(0x1E140C));
    }

    @Override
    public int getHeight() {
        return 12;
    }
}
