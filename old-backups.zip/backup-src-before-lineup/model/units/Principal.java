package model.units;

import java.awt.Color;
import model.Role;
import model.Side;
import model.Unit;
import ui.pixel.SpritePen;

/** Education - the tank. Very high HP, slow. */
public class Principal extends Unit {

    public Principal(Side side) {
        super("Principal", Role.TANK, side, 330, 15, 1.3, 12, 11);
    }

    @Override
    protected void drawBody(SpritePen p, int frame, int tick) {
        Color navy = new Color(0x1E3A8A);
        if (frame == 0) {
            p.rect(-2, 4, 2, 4, navy);
            p.rect(1, 4, 2, 4, navy);
        } else {
            p.rect(-1, 4, 2, 4, navy);
            p.rect(0, 4, 2, 4, navy);
        }
        p.rect(-3, 11, 7, 7, navy);                     // suit
        p.rect(-1, 11, 3, 1, Color.WHITE);              // collar
        p.rect(0, 10, 1, 5, new Color(0x60A5FA));       // tie
        p.rect(-2, 16, 5, 5, SKIN);                     // head
        p.rect(-2, 16, 5, 1, new Color(0xBDBDBD));      // grey hair
        p.rect(2, 14, 1, 1, EYE);
        p.rect(1, 12, 2, 1, new Color(0x9E9E9E));       // mustache
    }

    @Override
    public int getHeight() {
        return 17;
    }
}
