package model.units;

import java.awt.Color;
import model.Projectile;
import model.Role;
import model.Side;
import model.Unit;
import ui.pixel.SpritePen;

/** Computer Science - ranged attacker that shoots lines of code from a laptop. */
public class Programmer extends Unit {

    public Programmer(Side side) {
        super("Programmer", Role.RANGED, side, 85, 12, 0.8, 55, 17);
    }

    @Override
    public String getAbilityText() {
        return "SHOOTS CODE VERY FAST";
    }

    @Override
    protected Projectile.Kind projectileKind() {
        return Projectile.Kind.CODE;
    }

    @Override
    protected void drawBody(SpritePen p, int frame, int tick) {
        legs(p, frame, 3, new Color(0x1F2937));
        p.rect(-2, 9, 4, 6, new Color(0xEAB308));       // yellow hoodie
        p.rect(-3, 12, 1, 4, new Color(0xCA8A04));      // hood
        p.rect(2, 6, 4, 1, new Color(0x6B7280));        // laptop base
        p.rect(4, 9, 1, 3, new Color(0x6B7280));        // laptop screen
        p.rect(3, 8, 1, 1, new Color(0x4ADE80));        // screen glow
        head(p, 13, SKIN_DARK, new Color(0x1E140C));
        p.rect(-2, 14, 4, 1, new Color(0x111827));      // headphones band
        p.rect(-2, 12, 1, 2, new Color(0x111827));      // headphone
    }

    @Override
    public int getHeight() {
        return 15;
    }
}
