package model;

import java.awt.Color;
import model.towers.ComputerScienceTower;
import model.towers.EducationTower;
import model.towers.HospitalityTower;

/**
 * The three school departments. Each one becomes a tower in the game.
 * To add a new department later: add a line here, create its Tower subclass,
 * and add it to createTower().
 */
public enum Department {

    HOSPITALITY("Hospitality Management", "Hospitality", "Grand Hotel", new Color(0xDC2626), "Burn + Heal"),
    EDUCATION("Education", "Education", "Academy", new Color(0x2563EB), "Slow + Range"),
    COMPUTER_SCIENCE("Computer Science", "Comp Sci", "Server", new Color(0xEAB308), "Fast + Chain");

    private final String fullName;
    private final String shortName;
    private final String towerShortName;
    private final Color color;
    private final String style;

    Department(String fullName, String shortName, String towerShortName, Color color, String style) {
        this.fullName = fullName;
        this.shortName = shortName;
        this.towerShortName = towerShortName;
        this.color = color;
        this.style = style;
    }

    /**
     * Creates this department's tower.
     * Polymorphism: the caller gets a plain "Tower" but it is really a
     * HospitalityTower, EducationTower, or ComputerScienceTower.
     */
    public Tower createTower(Side side, int permanentLevel, double hpMultiplier) {
        return switch (this) {
            case HOSPITALITY -> new HospitalityTower(side, permanentLevel, hpMultiplier);
            case EDUCATION -> new EducationTower(side, permanentLevel, hpMultiplier);
            case COMPUTER_SCIENCE -> new ComputerScienceTower(side, permanentLevel, hpMultiplier);
        };
    }

    public String getFullName() {
        return fullName;
    }

    public String getShortName() {
        return shortName;
    }

    /** e.g. "Grand Hotel" */
    public String getTowerShortName() {
        return towerShortName;
    }

    /** e.g. "Grand Hotel Tower" */
    public String getTowerName() {
        return towerShortName + " Tower";
    }

    public Color getColor() {
        return color;
    }

    /** Short description of how the tower plays, e.g. "Burn + Heal". */
    public String getStyle() {
        return style;
    }
}
